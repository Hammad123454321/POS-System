﻿Configuration 
compileSdkVersion 25
minSdkVersion     19
targetSdkVersion  21
jdk 1.7

Permissions 
/**Basic permission**/
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.MOUNT_UNMOUNT_FILESYSTEMS" />
<uses-permission android:name="android.permission.INTERNET" />

/**Permission for Bluetooth**/
<uses-permission android:name="android.permission.BLUETOOTH" />
<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" />

<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>

<uses-feature
        android:name="android.hardware.usb.host"
        android:required="true" />

Note: Some permissions need to apply for runtime permissions if on Android OS v6.0+;


Usage:
1. Add compile fileTree(include: ['*.jar'], dir: 'libs') and compile 'com.google.code.gson:gson:2.8.5' since version 'V2.01.00_20190612' and 'com.android.support:support-annotations:25.1.0'in build.gradle (Module:app)
2. Copy the updated EasyLink SDK jar and .so file(if any)to libs and delete the old one(such as:GLBaiFuTong),  then synchronized project;
3. Please create thread to do the time-consuming operations, like receiving data by WIFI; 
4. Please invoke disconnect API, then invoke connect API to switch communication mode;

ProGuard:
Please add the following lines in your proguard file, such as proguard-rule.pro
#####EasylinkSdk
-keep class com.paxsz.easylink.** { *;}
#####GL_Comm
-keep class com.pax.gl.** { *;}
-keep class com.pax.serialport.** { *;}
#####EcrProtocol
-keep class pax.ecr.protocol.** { *;}

==================== EasyLinkSdk_V2.02.03_20210920 =====================
1. [EASYLINK-34]EasyLink Lite - showPage issue on R20.
2. Add BroadPOS-Lite feature

==================== EasyLinkSdk_V2.02.02_20210617 =====================
1.Merge support serial port communication for R20 from Easylink common version


==================== EasyLinkSdk_V2.02.01_20210115 =====================
1.fix bug:some android device can not connect lower device (Upgrade GL_Comm to V1.07.00_20201015).
2. Add support get parameter file version through tag012B;

==================== EasyLinkSdk_V2.02.01_20200820 =====================
1.Support US features,as below
  a. Support RKI function in D135;
  b. Support CYBS P2PE function;
  c. Add AID info for app select response
  d. Add get key information function

==================== EasyLinkSdk_V2.02.00_20190916 =====================
1.Add new feature to support update timeout dynamically during startTransaction.(For PineLabs)
2.Optimize to reduce the consuming time of fileDownload.
 
==================== EasyLinkSdk_V2.01.00_20190612 =====================
1.add new feature to support set terminal parameters during startTransaction.(Tr-Sy and InterPay requirements)
2.fix bug
3.gradle remove fastjson, add gson.

==================== EasyLinkSdk_V2.01.00_20190306 =====================
1.fix bug of setData when value length > 1024

==================== EasyLinkSdk_V2.01.00_20190221 =====================
1. Support report for the multi acquirer feature while IPC startTransacion
2. update EcrProtocol (close log)
3. fix bug of setData return 5002
4. fix bug of getData will crash when the value length > 127
5. fix timeout issues of onReportStatusListener (onSelectApp/onSetParamToPinPad)

==================== EasyLinkSdk_V2.00.00_20190110 =====================
1.add writeKey

==================== EasyLinkSdk_V2.00.00_20190107 =====================
1. add interface registerDisconnectStateListener, to get the notifications of USB or Bluetooth disconnected state.
2. IReportStatusListener add onSetParamToPinPad to support set parameter from smart device while startTransaction.
3. AppSelectResponse update the status:"ERROR" to "NO_APP", status:"NORMAL" to "SUCCESS", add appIndex.
4. remove SearchMode.INSERT_SWIPE_FALLBACK

==================== EasyLinkSdk_V2.00.00_20181203 =====================
1. Change the report status type from enum to int
2. Optimize the connection
3. Fix bug of sendCancel while connect type is USB Virtual dual channels/WIFI/BT 

==================== EasyLinkSdk_V2.00.00_20181029 =====================
1.add report function by registerReportStatusListener or registerReportListener interface to get the status of transaction processing during startTransaction/getPinBlock/completeTransaction.
2.add sendCancel interface to cancel the transaction of startTransaction/getPinBlock/completeTransaction
3.startTransaction(IReportListener listener) has deprecated

==================== EasyLinkSdk_V1.02.00_20180828 =====================
1. Increase the size of each download in the fileDownload interface from 1024 to 4096, reduce the number of reads and transfers.


==================== EasyLinkSdk_V1.02.00_20180824 =====================
1. fix bug of packageSize of the interface filedownload
2. fix bug of dual channel communication


==================== EasyLinkSdk_V1.02.00_20180808 =====================
1. Support receiving Reports data from POS terminal

==================== EasyLinkSdk_V1.01.00_20180713 =====================
1.exclude GLComm,GLUtils,GLBaiFuTong

==================== EasyLinkSdk_V1.00.03_20180508 =====================
1. Virtual dual channels has been supported for usb
2. The fileDownload interface who need to the parameters of fileName  has deprecated
3. Update the jar of GLComm��GLBaiFuTong��GLUtils
4. fix bug of the showpage retutned error actionType
5. fix bug of the showpage whose parameters of showpageInfo is not utf-8
6. modify the timeOut unit from ms to s of showpage   

==================== EasyLinkSdk_V1.00.02_20180309 =====================
1. Add increaseKSN API;
2. Add calculateMac API;
3. Update completeTransaction API: extend timeout from 20 seconds to 130 seconds;
4. Update fileDownload API;
5. Modify descriptions for APIs;


==================== EasyLinkSdk_V1.00.02_20180116 =====================
1. Add communication mode: IPC, usage:
	DeviceInfo deviceInfo = new DeviceInfo(DeviceInfo.CommType.IPC);
	int ret = EasyLinkSdkManager.getInstance(context).connect(deviceInfo);

	success if returned 0;

	
==================== EasyLinkSdk_V1.00.01_20171211 =====================
1. Update return code for connect;

==================== EasyLinkSdk_V1.00.01_20171130 =====================
1. Update: setData/getData, output raw data to parameter "ByteArrayOutputStream resultData";
2. Fix bug for USB connection;

==================== EasyLinkSdk_V1.00.01_20171117 =====================
1. Fix bug: returned 9001 if not set identifier in WIFI communication;
2. Fix bug: cause crash if re-connect WIFI after disconnect;

==================== EasyLinkSdk_V1.00.01_20171109 =====================
1. Fix bug: USB can't connect if unplug USB while transaction processing;
2. Fix bug: Application crashes if the returned value if null in setData;
3. Fix bug: Application crashes if connect by new an invalid USB device;
4. Fix bug: Return the responed failedTags if EL_PARAM_RET_PARTIAL_FAILED returned in setData/getData API;

==================== EasyLinkSdk_V1.00.01_20171109 =====================
1. Add TLVDataObject;
2. Add isConnected() API;
3. Overload getData API:
	getData(final DataType datatype, List<byte[]> tagList, List<TLVDataObject> tlvDataObjects)��
4. Add stopSearchingDevice() while searching Bluetooth;
5. Update response code for startTransaction/completeTransaciton API;
6. Add getConnectedDevice();
7. Add timeout for connection;
8. Add getUsbDevice();
9. Add setDebugMode(boolean isDebugMode), default: false;

Variable updates:
DeviceInfo class��
blueName --> deviceName
getBlueName() --> getDeviceName() 
setBlueName() --> setDeviceName()



