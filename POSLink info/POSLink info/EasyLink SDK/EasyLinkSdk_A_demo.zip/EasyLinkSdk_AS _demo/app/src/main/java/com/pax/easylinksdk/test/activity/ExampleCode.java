package com.pax.easylinksdk.test.activity;

import com.pax.gl.utils.impl.Convert;
import com.paxsz.easylink.listener.ReportConstant;
import com.paxsz.easylink.model.KcvMode;
import com.paxsz.easylink.model.KeyType;
import com.paxsz.easylink.model.TLVDataObject;
import com.paxsz.easylink.model.report.BaseReportedData;
import com.paxsz.easylink.model.report.BaseRunCmdModel;
import com.paxsz.easylink.model.report.EmvAidParam;
import com.paxsz.easylink.model.report.ICSParam;
import com.paxsz.easylink.model.report.KeyParam;
import com.paxsz.easylink.model.report.ReportedData;
import com.paxsz.easylink.model.report.SetDataModel;
import com.paxsz.easylink.model.report.SetEmvAidParamModel;
import com.paxsz.easylink.model.report.SetICSParamModel;
import com.paxsz.easylink.model.report.TikKeyParam;
import com.paxsz.easylink.model.report.WriteKeyModel;
import com.paxsz.easylink.model.report.WriteTikKeyModel;

import java.util.ArrayList;

public class ExampleCode {

    public ArrayList<BaseRunCmdModel> onRunCmd(ArrayList<? extends BaseReportedData> reportedParamList, int timeout) {
        ArrayList<BaseRunCmdModel> rspList = new ArrayList<>();
        for (BaseReportedData baseReportedParam : reportedParamList) {
            if (baseReportedParam.getStatus().equals(ReportConstant.STATUS_SET_EMV_AID_PARAM)) {
                ReportedData<EmvAidParam> emvAidParamReportedParam = (ReportedData<EmvAidParam>) baseReportedParam;

                // TODO list:
                // 1. Get EmvAidParam OBJECT
                //Example code:
                EmvAidParam emvAidParamOBJ = emvAidParamReportedParam.getParamBean();
                // 2. Update EmvAidParam OBJECT according to the business requirement.
                // For example, update the floorLimit to 0 if transaction type is 0x20
                //Example code:
                emvAidParamOBJ.setFloorLimit(0);
                // 3. Set the updated EmvAidParam OBJECT to set SetEmvAidParamModel
                //Example code:
                SetEmvAidParamModel emvAidParamModel = new SetEmvAidParamModel();
                emvAidParamModel.setEmvAidParam(emvAidParamOBJ);
                // 4. Apply the changes to the response result
                //Example code:
                rspList.add(emvAidParamModel);


            } else if (baseReportedParam.getStatus().equals(ReportConstant.STATUS_SET_ICS_PARAM)) {
                ReportedData<ICSParam> icsParamReportedParam = (ReportedData<ICSParam>) baseReportedParam;
                // TODO list:
                // 1. Get ICSParam OBJECT
                //Example code:
                ICSParam iCSParamOBJ = icsParamReportedParam.getParamBean();
                // 2. Update ICSParam OBJECT according to the business requirement.
                //    For example,update the pinByPass to 0 and forcedOnline to 1 if transaction type is 0x20
                //Example code:
                iCSParamOBJ.setBypassPinEntry(0);
                iCSParamOBJ.setForcedOnlineCapability(1);
                // 3. Set the updated ICSParam OBJECT to the SetICSParamModel
                //Example code:
                SetICSParamModel icsParamModel = new SetICSParamModel();
                icsParamModel.setICSParam(iCSParamOBJ);
                // 4. Apply the changes to the response result
                //Example code:
                rspList.add(icsParamModel);


            } else if (baseReportedParam.getStatus().equals(ReportConstant.STATUS_READ_CARD_OK)) {
                BaseReportedData readCardOKReportedData = baseReportedParam;

                // TODO:
                // 1. Update TAG by setData COMMAND according to the business requirement
                //    For example, set pinKeyType(TAG 0202) and pinKeyIndex(TAG 0203) according to PAN range and transaction type
                //Example code:
                TLVDataObject pinKeyTypeTlv = new TLVDataObject();
                pinKeyTypeTlv.setTag(new byte[]{0x02, 0x02});
                pinKeyTypeTlv.setValue(new byte[]{0x01});

                TLVDataObject pinKeyIndexTlv = new TLVDataObject();
                pinKeyIndexTlv.setTag(new byte[]{0x02, 0x03});
                pinKeyIndexTlv.setValue(new byte[]{0x09});

                ArrayList<TLVDataObject> setDataTlvList = new ArrayList<>();
                setDataTlvList.add(pinKeyTypeTlv);
                setDataTlvList.add(pinKeyIndexTlv);
                // 2. Add the list of TLVDataObject to SetDataModel
                //Example code:
                SetDataModel setDataModel = new SetDataModel();
                setDataModel.setConfigTlv(setDataTlvList);
                // 3. Apply the changes to the response result
                //Example code:
                rspList.add(setDataModel);


                // TODO:(optional)
                // 1. writeKey/writeTIK for corresponding host according to the business requirement if writeKey/writeTIK supported
                //    For example, write tpk
                //Example code:
                byte[] tpkValue = new byte[]{0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33};
                KeyParam tpkParam = new KeyParam();
                tpkParam.setSrcKeyType(KeyType.PED_TMK);
                tpkParam.setSrcKeyIndex(0x30);
                tpkParam.setDstKeyType(KeyType.PED_TPK);
                tpkParam.setDstKeyIndex(0x40);
                tpkParam.setDstKeyValue(tpkValue);
                tpkParam.setCheckMode(KcvMode.KCV_NONE);
                // 2. Add the KeyParam OBJECT to WriteKeyModel
                //Example code:
                WriteKeyModel writeKeyModel = new WriteKeyModel();
                writeKeyModel.setKeyParam(tpkParam);
                // 3. Apply the changes to the response result
                //Example code:
                rspList.add(writeKeyModel);

                // TODO:(optional)
                // 1. writeTIK for corresponding host according to the business requirement if writeTIK supported
                //    For example, write TIK
                //Example code:
                byte[] ipek = Convert.strToBcd("6AC292FAA1315B4D858AB3A3D7D5933A", Convert.EPaddingPosition.PADDING_RIGHT);
                byte[] ksn = Convert.strToBcd("FFFF9876543210E00000", Convert.EPaddingPosition.PADDING_RIGHT);
                TikKeyParam tikParam = new TikKeyParam();
                tikParam.setSrcKeyIndex(0x30);
                tikParam.setGroupIndex(5);
                tikParam.setKeyValue(ipek);
                tikParam.setKsn(ksn);
                tikParam.setCheckMode(KcvMode.KCV_NONE);
                // 2. Add the TikKeyParam OBJECT to WriteTikKeyModel
                //Example code:
                WriteTikKeyModel writeTikKeyModel = new WriteTikKeyModel();
                writeTikKeyModel.setTikKeyParam(tikParam);
                // 3. Apply the changes to the response result
                //Example code:
                rspList.add(writeTikKeyModel);

            }
        }

        return rspList;
    }
}
