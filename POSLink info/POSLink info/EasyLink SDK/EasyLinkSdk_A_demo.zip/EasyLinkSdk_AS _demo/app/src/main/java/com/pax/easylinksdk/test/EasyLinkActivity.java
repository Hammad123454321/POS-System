package com.pax.easylinksdk.test;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.ConditionVariable;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.pax.easylinksdk.test.EasyLinkParam.EasyLinkConfigParam;
import com.pax.easylinksdk.test.activity.BluetoothActivity;
import com.pax.easylinksdk.test.activity.ConnectActivity;
import com.pax.easylinksdk.test.activity.SetConfigParamActivity;
import com.pax.easylinksdk.test.activity.TestResultActivity;
import com.pax.easylinksdk.test.activity.UsbActivity;
import com.pax.easylinksdk.test.manage.ConfigManager;
import com.pax.easylinksdk.test.utils.CloneUtil;
import com.pax.easylinksdk.test.utils.StringUtils;
import com.pax.easylinksdk.test.utils.Tools;
import com.pax.gl.img.ImgProcessing;
import com.paxsz.easylink.api.EasyLinkSdkManager;
import com.paxsz.easylink.api.ResponseCode;
import com.paxsz.easylink.device.DeviceInfo;
import com.paxsz.easylink.device.DeviceInfo.CommType;
import com.paxsz.easylink.listener.FileDownloadListener;
import com.paxsz.easylink.listener.IRKIStatusListener;
import com.paxsz.easylink.listener.IReportListener;
import com.paxsz.easylink.listener.IReportStatusListener;
import com.paxsz.easylink.listener.ReportConstant;
import com.paxsz.easylink.model.AppSelectResponse;
import com.paxsz.easylink.model.AppSelectResponse.AppList;
import com.paxsz.easylink.model.DataModel;
import com.paxsz.easylink.model.DataModel.DataType;
import com.paxsz.easylink.model.DataModel.ProtocolType;
import com.paxsz.easylink.model.KcvInfo;
import com.paxsz.easylink.model.KeyInfo;
import com.paxsz.easylink.model.KeyType;
import com.paxsz.easylink.model.ShowPageInfo;
import com.paxsz.easylink.model.TLVDataObject;
import com.paxsz.easylink.model.UIRespInfo;
import com.paxsz.easylink.model.report.BaseReportedData;
import com.paxsz.easylink.model.report.BaseRunCmdModel;
import com.paxsz.easylink.model.report.EmvAidParam;
import com.paxsz.easylink.model.report.ICSParam;
import com.paxsz.easylink.model.report.KeyParam;
import com.paxsz.easylink.model.report.ReportedData;
import com.paxsz.easylink.model.report.SetDataModel;
import com.paxsz.easylink.model.report.SetEmvAidParamModel;
import com.paxsz.easylink.model.report.SetICSParamModel;
import com.paxsz.easylink.model.report.TikKeyParam;
import com.paxsz.easylink.model.report.WriteKeyModel;
import com.paxsz.easylink.model.report.WriteTikKeyModel;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.calcMAC;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.cashbackAndApprove;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.emvfun1;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.emvfun2;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.emvfun3;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.encryptData1;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.fileDownload1;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.getConfigData;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.getKeyInfo;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.getPinblock1;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.getTransData;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.increaseKSN;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.refundWithSetMultiAcq;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.saleAndApprove;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.saleAndDecline;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.saleAndnoScript;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.saleWithReport;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.saleWithReportCancel;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.saleWithReportStatus;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.saleWithSetMultiAcq;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.setConfigData;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.setDataAbnormal2;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.setFixedConfigData;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.setTransData;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.showpage1;
import static com.pax.easylinksdk.test.entity.EasyLinkFuncNum.showpage2;

public class EasyLinkActivity extends Activity {

    private static final int NORMALRESULT = 1;
    private static final int EXCEPTRESULT = 2;
    private static final int SELECT_APP = 3;
    private static final int SELECT_APP_TIMEOUT = 4;
    private static final int SEND_CANCEL = 5;
    private static final int SHOW_SIGNATURE_VIEW = 6;
    private static final int MSG_IPC_CONNECT_RET = 7;
    private static final int MSG_SET_PARAM_RSP = 8;
    private static final int MSG_SET_PARAM_RSP_TIMEOUT = 9;
    private static final int MSG_RUN_CMD_SET_EMVAID_PARAM_RSP_TIMEOUT = 0x101;
    private static final int MSG_RUN_CMD_SET_ICS_PARAM_RSP_TIMEOUT = 0x102;
    private static final int MSG_RUN_CMD_READ_CARD_OK_PARAM_RSP_TIMEOUT = 0x103;
    private static final int MSG_RUN_CMD_SET_EMV_AID_PARAM = 11;
    private static final int MSG_RUN_CMD_SET_ICS_PARAM = 12;
    private static final int MSG_READ_CARD_OK_STATUS = 13;
    private static final String TAG = "EasyLinkActivity";
    public static boolean iscancelfiledownload = false;
    public EasyLinkSdkManager easyLink;
    public IReportStatusListener reportStatusListener;
    public boolean reportWithCancel = false;
    public boolean enterPinReportWithCancel = false;
    public boolean supportSetMultiAcq = false;
    public ConfigManager cfgm;
    public byte[] emvpa;
    public String startTransactionStatue = "";
    int transRet = -1;
    ConditionVariable appSelectCv = new ConditionVariable();
    ConditionVariable setParamRspCV = new ConditionVariable();
    ConditionVariable runCmdSetEmvAidCv = new ConditionVariable();
    ConditionVariable runCmdSetICSCv = new ConditionVariable();
    ConditionVariable runCmdReadCardOKCv = new ConditionVariable();
    private String mInterface;
    private String mNo;
    private TextView text;
    private ImageView signatureView;
    private ProgressDialog progressDialog;
    private List<String> selectAppLabel = new ArrayList<>();
    private List<Integer> selectAppIndex = new ArrayList<>();
    private AlertDialog appSelectDlg = null;
    private AlertDialog allowCancelDlg = null;
    private AlertDialog setRspParamDlg = null;
    private AlertDialog setEmvAidParamDlg = null;
    private AlertDialog setICSParamDlg = null;
    private String setRspParamStr = null;
    private boolean userCancel;

    private EmvAidParam newEmvAidParam;
    private ICSParam newICSParam;

    private int cmdListSize = 1;
    private int setDataSize = 0;
    private ArrayList<TLVDataObject> configTlvList;
    private ArrayList<TLVDataObject> emvTlvList;


    private EmvAidParam orgAidParam;
    private ICSParam orgICSParam;

    private ArrayList<TLVDataObject> setDataConfigTlvList;
    private ArrayList<TLVDataObject> setDataEmvTlvList;
    private KeyParam writeKeyParam1;
    private KeyParam writeKeyParam2;
    private TikKeyParam writeTikKeyParam;

    private boolean isNewANullEmvAidParam;
    private boolean isNewANullICSParam;


    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case NORMALRESULT:
                case EXCEPTRESULT:
                    Bundle bundle = msg.getData();
                    String result = bundle.getString("result");
                    text.setText(result);
                    break;
                case SELECT_APP:
                    Bundle bundle1 = msg.getData();
                    String prompts = bundle1.getString("prompts");
                    int timeout = bundle1.getInt("timeout");
                    ArrayList<String> apps = bundle1.getStringArrayList("appList");
                    ArrayList<String> aids = bundle1.getStringArrayList("aidList");
                    showAppSelect(prompts, timeout, apps, aids);
                    break;
                case SELECT_APP_TIMEOUT:
                    if (selectAppLabel == null || selectAppLabel.size() == 0) {
                        userCancel = false;
                        if (appSelectDlg != null && appSelectDlg.isShowing()) {
                            appSelectDlg.dismiss();
                        }
                        Log.d(TAG, "handleMessage: Select App has Timeout");
                        appSelectCv.open();
                    }
                    break;
                case SEND_CANCEL:
                    showAllowCancelDlg();
                    break;

                case SHOW_SIGNATURE_VIEW:
                    Bundle bundle2 = msg.getData();
                    byte[] viewData = bundle2.getByteArray("signData");
                    Bitmap signatureBitmap = ImgProcessing.getInstance(EasyLinkActivity.this).jbigToBitmap(viewData);
                    signatureView.setImageBitmap(signatureBitmap);
                    break;
                case MSG_IPC_CONNECT_RET:
                    int ret = msg.arg1;
                    Intent intent = new Intent(EasyLinkActivity.this, TestResultActivity.class);
                    intent.putExtra(TestResultActivity.KEY_RESULT, "ret: " + ret);
                    startActivity(intent);
                    EasyLinkActivity.this.finish();
                    break;
                case MSG_SET_PARAM_RSP:
                    showSetRspParamDlg(msg.arg1);
                    break;
                case MSG_SET_PARAM_RSP_TIMEOUT:
                    setRspParamStr = null;
                    if (setRspParamDlg != null && setRspParamDlg.isShowing()) {
                        setRspParamDlg.dismiss();
                    }
                    setParamRspCV.open();

                    break;
                case MSG_RUN_CMD_SET_EMV_AID_PARAM:
                    Bundle emvAidData = msg.getData();
                    showSetEmvAIDParamPage(emvAidData, MSG_RUN_CMD_SET_EMVAID_PARAM_RSP_TIMEOUT);
                    break;
                case MSG_RUN_CMD_SET_ICS_PARAM:
                    Bundle icsParmaData = msg.getData();
                    showSetEmvAIDParamPage(icsParmaData, MSG_RUN_CMD_SET_ICS_PARAM_RSP_TIMEOUT);
                    break;
                case MSG_RUN_CMD_SET_EMVAID_PARAM_RSP_TIMEOUT:
                    newEmvAidParam = orgAidParam;

                    configTlvList = null;
                    emvTlvList = null;
                    Log.e(TAG, " runCmd:set emv aid param timeout");
                    runCmdSetEmvAidCv.open();
                    break;
                case MSG_RUN_CMD_SET_ICS_PARAM_RSP_TIMEOUT:
                    newICSParam = orgICSParam;
                    configTlvList = null;
                    emvTlvList = null;

                    Log.e(TAG, " runCmd: set ics param timeout");
                    runCmdSetICSCv.open();
                    break;
                case MSG_RUN_CMD_READ_CARD_OK_PARAM_RSP_TIMEOUT:
                    setDataConfigTlvList = null;
                    setDataEmvTlvList = null;
                    writeKeyParam1 = null;
                    writeKeyParam2 = null;
                    writeTikKeyParam = null;
                    Log.e(TAG, " runCmd: read card ok timeout");
                    runCmdReadCardOKCv.open();
                    break;
                case MSG_READ_CARD_OK_STATUS:
                    Bundle readCardOKData = msg.getData();
                    showReadCardOKStatusParamPage(readCardOKData);
                    break;
            }
        }

    };

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 2 && resultCode == 0) {
            Bundle bundle = data.getExtras();
            int paramType = bundle.getInt("paramType");

            cmdListSize = bundle.getInt("cmdListSize", 1);
            setDataSize = bundle.getInt("setDataSize", 0);
            if (setDataSize > 0) {
                configTlvList = bundle.getParcelableArrayList("configTlvList");
                emvTlvList = bundle.getParcelableArrayList("emvTlvList");
            }
            if (paramType == 1) {
                newEmvAidParam = (EmvAidParam) bundle.getSerializable("param");
                runCmdSetEmvAidCv.open();
            } else if (paramType == 2) {
                newICSParam = (ICSParam) bundle.getSerializable("param");
                runCmdSetICSCv.open();
            }

        } else if (requestCode == 3 && resultCode == 0) {
            Bundle bundle = data.getExtras();
            setDataConfigTlvList = bundle.getParcelableArrayList("configTlvList");
            setDataEmvTlvList = bundle.getParcelableArrayList("emvTlvList");
            writeKeyParam1 = (KeyParam) bundle.getSerializable("writeKey1");
            writeKeyParam2 = (KeyParam) bundle.getSerializable("writeKey2");
            writeTikKeyParam = (TikKeyParam) bundle.getSerializable("writeTikKey");
            isNewANullEmvAidParam = bundle.getBoolean("newANullEmvAidParam", false);
            isNewANullICSParam = bundle.getBoolean("newANullICSParam", false);
            runCmdReadCardOKCv.open();
        } else {
            switch (resultCode) {
                case RESULT_OK:
                    int func = data.getIntExtra("FUNC", 0);
                    String idx = data.getStringExtra("index");
                    String idx2 = data.getStringExtra("index2");


                    Bundle bundle = new Bundle();
                    bundle.putString("index", idx);

                    bundle.putInt("func", func);
                    Message msg = handler.obtainMessage();
                    msg.what = 1234;
                    msg.setData(bundle);
                    handler.sendMessage(msg);

                    switch (func) {
                        case getPinblock1:
                            getPinBlock(idx);
                            break;
                        case getTransData:
                            cfgm.saveTagValue("getTransData", idx);
                            getTransData(idx);
                            break;
                        case showpage1:
                            showPage(idx);
                            break;
                        case showpage2:
                            showBarcodePage(idx);
                            break;
                        case fileDownload1:
                            fileDownLoad(idx);
                            break;
                        case setTransData:
                            cfgm.saveTagValue("setTransData", idx);
                            setTransData(idx);
                            break;
                        case encryptData1:
                            encryptData(idx);
                            break;
                        case setConfigData:
                            cfgm.saveTagValue("setConfigData", idx);
                            setConfigData(idx);
                            break;
                        case getConfigData:
                            cfgm.saveTagValue("getConfigData", idx);
                            getConfigData(idx);
                            break;
                        case emvfun1:
                            EMVFUN1(idx);
                            break;
                        case emvfun2:
                            EMVFUN2(idx);
                            break;
                        case emvfun3:
                            EMVFUN3(idx);
                            break;
                        case saleAndApprove:
                            cfgm.saveTagValue("amount", idx);
                            startTransationSaleAndAprrove(idx);
                            break;
                        case saleAndnoScript:
                            cfgm.saveTagValue("amount", idx);
                            startTransationSaleAnNoSript(idx);
                            break;
                        case refundWithSetMultiAcq:
                            startTransationRefundAnNoSript(idx);
                            break;
                        case saleWithReport:
                            cfgm.saveTagValue("amount", idx);
                            saleWithReport(idx);
                            break;
                        case saleWithReportStatus:
                            cfgm.saveTagValue("amount", idx);
                            startTransaction_report(idx);
                            break;
                        case saleWithReportCancel:
                            cfgm.saveTagValue("amount", idx);
                            startTransaction_with_cancel(idx);
                            break;
                        case saleWithSetMultiAcq:
                            cfgm.saveTagValue("amount", idx);
                            startTransaction_Multi_Acq(idx);
                            break;
                        case saleAndDecline:
                            cfgm.saveTagValue("amount", idx);
                            startTransationSaleAndDecline(idx);
                            break;
                        case setFixedConfigData:
                            setConfigData();
                            break;
                        case cashbackAndApprove:
                            cfgm.saveTagValue("amount", idx);
                            cashBackAndApprove(idx);
                            break;
                        case increaseKSN:
                            testIncreaseKsn(idx);
                            break;
                        case calcMAC:
                            testCalcMac(idx);
                            break;
                        case getKeyInfo:
                            testGetKeyInfo(idx);


                            break;
                    }
                    break;
                default:
                    break;
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base);

        Intent intent = getIntent();
        mInterface = intent.getStringExtra("Interface");
        mNo = intent.getStringExtra("No");

        TextView tv = (TextView) findViewById(R.id.base_title);
        tv.setText(mInterface + "_FUN" + mNo);
        easyLink = EasyLinkSdkManager.getInstance(this);
        cfgm = ConfigManager.getInstance(getApplicationContext());
        startSelectFileActivity();
        //startRKIFuncActivity();
        startProcess();

        reportStatusListener = new IReportStatusListener() {
            @Override
            public void onReportSearchMode(String prompts, int mode) {
                updateResult("searchMode:" + mode + ", prompts:" + prompts);
                Log.w(TAG, "searchMode:" + mode + ", prompts:" + prompts);
                //read card success prompt whether cancel?
                if (reportWithCancel) {
                    updatePromptAllowCancel();
                }
            }


            @Override
            public void onReadCard(String prompts, int detectType, int readCardStatus) {
                Log.w(TAG, "onReadCard:" + prompts + ", detectType:" + detectType + ", status:" + readCardStatus);
                updateResult("onReadCard:" + prompts + ", detectType:" + detectType + ", status:" + readCardStatus);
            }


            @Override
            public AppSelectResponse onSelectApp(String prompts, int timeout, List<String> appList) {
                Log.w(TAG, "onSelectApp:" + prompts + ", timeout:" + timeout + ", appList:" + appList);
                updateResult("onSelectApp:" + prompts + ", timeout:" + timeout + ", appList:" + appList);
                ArrayList<String> arrayList = new ArrayList<>();
                AppSelectResponse appSelectResponse = new AppSelectResponse();
                if (appList != null && appList.size() > 0) {
                    arrayList.addAll(appList);
                    updateResultWithWhat(arrayList, null, timeout, prompts, SELECT_APP);
                    appSelectCv.block();

                    if (selectAppLabel==null || selectAppLabel.size()==0) {
                        if (userCancel) {
                            appSelectResponse.setStatus(AppSelectResponse.CANCEL);//cancel
                        } else {
                            appSelectResponse.setStatus(AppSelectResponse.TIMEOUT);//timeout
                        }
                    } else {//normal
                        appSelectResponse.setStatus(AppSelectResponse.SUCCESS);
                        List<AppList> appLists = new ArrayList<>();
                        for(int idx=0; idx< selectAppLabel.size(); idx++) {
                            AppList selApp = new AppList();
                            selApp.setAppLabel(selectAppLabel.get(idx));
                            selApp.setAppIndex(selectAppIndex.get(idx));
                            appLists.add(selApp);
                        }
                        appSelectResponse.setAppList(appLists);
                    }
                    return appSelectResponse;

                } else {
                    appSelectResponse.setStatus(AppSelectResponse.NO_APP);
                    return appSelectResponse;

                }
            }

            @Override
            public AppSelectResponse onSelectApp(String prompts, int timeout, List<String> appList, List<String> aidList) {
                Log.w(TAG, "onSelectApp:" + prompts + ", timeout:" + timeout + ", appList:" + appList);
                updateResult("onSelectApp:" + prompts + ", timeout:" + timeout + ", appList:" + appList + ", aidList:" + aidList);
                ArrayList<String> arrayList = new ArrayList<>();
                ArrayList<String> arrayAidList = new ArrayList<>();

                AppSelectResponse appSelectResponse = new AppSelectResponse();
                if (appList != null && appList.size() > 0) {
                    arrayList.addAll(appList);
                    arrayAidList.addAll(aidList);
                    updateResultWithWhat(arrayList, arrayAidList, timeout, prompts, SELECT_APP);
                    appSelectCv.block();

                    if (selectAppLabel==null || selectAppLabel.size()==0) {
                        if (userCancel) {
                            appSelectResponse.setStatus(AppSelectResponse.CANCEL);//cancel
                        } else {
                            appSelectResponse.setStatus(AppSelectResponse.TIMEOUT);//timeout
                        }
                    } else {//normal
                        appSelectResponse.setStatus(AppSelectResponse.SUCCESS);
                        List<AppList> appLists = new ArrayList<>();
                        for(int idx=0; idx< selectAppLabel.size(); idx++) {
                            AppList selApp = new AppList();
                            selApp.setAppLabel(selectAppLabel.get(idx));
                            selApp.setAppIndex(selectAppIndex.get(idx));
                            appLists.add(selApp);
                        }
                        appSelectResponse.setAppList(appLists);
                    }
                    return appSelectResponse;

                } else {
                    appSelectResponse.setStatus(AppSelectResponse.NO_APP);
                    return appSelectResponse;

                }
            }

            @Override
            public void onEnterPin(String prompts, int pinLen, String enterPinEvent) {
                Log.w(TAG, "onEnterPin:" + prompts + ", pinLen:" + pinLen + ", pinStatus:" + enterPinEvent);
                updateResult("onEnterPin:" + prompts + ", pinLen:" + pinLen + ", pinStatus:" + enterPinEvent);
                if (enterPinReportWithCancel && "INIT".equals(enterPinEvent)) {
                    updatePromptAllowCancel();
                }
            }


            @Override
            public ArrayList<TLVDataObject> onSetParamToPinPad(String prompts, ArrayList<TLVDataObject> configTLVs, ArrayList<TLVDataObject> emvTLVs, int timeout) {
                Log.w(TAG, "onGetParamFromPinPed:" + prompts + ", timeout:" + timeout);
                if (supportSetMultiAcq) {
                    StringBuilder configs = new StringBuilder("configTlv:\n");
                    if (configTLVs != null && configTLVs.size() > 0) {
                        for (TLVDataObject configTLV : configTLVs) {
                            configs.append("tag:" + Tools.bcd2Str(configTLV.getTag()) + ", value:" + Tools.bcd2Str(configTLV.getValue()) + "\n");
                        }
                    }
                    StringBuilder emvTLVStr = new StringBuilder("\nemvTLVs:\n");
                    if (emvTLVs != null && emvTLVs.size() > 0) {
                        for (TLVDataObject emvTLV : emvTLVs) {
                            emvTLVStr.append("tag:" + Tools.bcd2Str(emvTLV.getTag()) + ", value:" + Tools.bcd2Str(emvTLV.getValue()) + "\n");
                        }
                    }

                    Log.d(TAG, "report configTLV and emvTLV data:\n" + configs.toString() + emvTLVStr.toString());
                    if (easyLink.getConnectedDevice().getCommType() != CommType.IPC) {
                        updateResult(configs.toString() + emvTLVStr.toString());
                        updateSetParamResult(timeout);
                        setParamRspCV.block();
                    }
                }
                ArrayList<TLVDataObject> responseConfigTlvs = new ArrayList<>();
                //test ipc
                if (easyLink.getConnectedDevice().getCommType() == CommType.IPC) {
                    responseConfigTlvs.add(new TLVDataObject(new byte[]{0x02, 0x02}, new byte[]{0x01}));//pinKeyType:01
                    responseConfigTlvs.add(new TLVDataObject(new byte[]{0x02, 0x03}, new byte[]{0x02}));//pinKeyIndex:01
                    responseConfigTlvs.add(new TLVDataObject(new byte[]{0x02, 0x04}, new byte[]{0x00}));//pinBlockMode:00 - ISO9564 format 0
                } else {
                    Log.w(TAG, "setRspParamStr:" + setRspParamStr);
                    if (!TextUtils.isEmpty(setRspParamStr)) {
                        responseConfigTlvs.addAll(Utils.unpackTLVs(DataType.CONFIGURATION_DATA, Tools.str2Bcd(setRspParamStr)));
                    }
                }

                return responseConfigTlvs;
            }

            @Override
            public ArrayList<BaseRunCmdModel> onRunCmd(ArrayList<? extends BaseReportedData> reportedParamList, int timeout) {
                ArrayList<BaseRunCmdModel> rspList = new ArrayList<>();
                for (BaseReportedData baseReportedParam : reportedParamList) {
                    if (baseReportedParam.getStatus().equals(ReportConstant.STATUS_SET_EMV_AID_PARAM)) {
                        ReportedData<EmvAidParam> emvAidParamReportedParam = (ReportedData<EmvAidParam>) baseReportedParam;

                        processShowEmvAidParam(emvAidParamReportedParam, timeout);
                        runCmdSetEmvAidCv.block();
                        SetEmvAidParamModel emvAidParamModel = null;
                        Log.i(TAG, "cmdListSize:" + cmdListSize);
                        if (cmdListSize >= 1) {
                            for (int i = 0; i < cmdListSize; i++) {
                                Log.i(TAG, "add:" + i);
                                emvAidParamModel = new SetEmvAidParamModel();
                                EmvAidParam tempEmvAidParam = CloneUtil.clone(newEmvAidParam);
                                Log.w(TAG, "tempEmvAidParam: " + tempEmvAidParam.toString());
                                emvAidParamModel.setEmvAidParam(tempEmvAidParam);
                                rspList.add(emvAidParamModel);
                            }
                        }
                        Log.i(TAG, "setDataSize:" + setDataSize);
                        if (setDataSize > 0) {
                            for (int i = 0; i < setDataSize; i++) {
                                SetDataModel setDataModel = new SetDataModel();
                                setDataModel.setConfigTlv(configTlvList);
                                setDataModel.setEmvTlv(emvTlvList);
                                rspList.add(setDataModel);
                            }

                        }

                    } else if (baseReportedParam.getStatus().equals(ReportConstant.STATUS_SET_ICS_PARAM)) {
                        ReportedData<ICSParam> icsParamReportedParam = (ReportedData<ICSParam>) baseReportedParam;
                        processShowICSParam(icsParamReportedParam, timeout);
                        runCmdSetICSCv.block();
                        SetICSParamModel icsParamResponse = new SetICSParamModel(newICSParam);
                        rspList.add(icsParamResponse);
                        Log.i(TAG, "setDataSize:" + setDataSize);
                        if (setDataSize > 0) {
                            for (int i = 0; i < setDataSize; i++) {
                                SetDataModel setDataModel = new SetDataModel();
                                setDataModel.setConfigTlv(configTlvList);
                                setDataModel.setEmvTlv(emvTlvList);
                                rspList.add(setDataModel);
                            }

                        }
                    } else if (baseReportedParam.getStatus().equals(ReportConstant.STATUS_READ_CARD_OK)) {
                        BaseReportedData readCardOKReportedData = baseReportedParam;
                        processShowReadCardOKParam(readCardOKReportedData, timeout);

                        runCmdReadCardOKCv.block();

                        SetDataModel setDataCmdRsp = new SetDataModel();
                        if (setDataConfigTlvList != null) {
                            setDataCmdRsp.setConfigTlv(setDataConfigTlvList);
                        }
                        if (setDataEmvTlvList != null) {
                            setDataCmdRsp.setEmvTlv(setDataEmvTlvList);
                        }

                        if (setDataConfigTlvList != null || setDataEmvTlvList != null) {
                            rspList.add(setDataCmdRsp);
                        }
                        WriteKeyModel keyModel = new WriteKeyModel();
                        WriteKeyModel keyMode2 = new WriteKeyModel();
                        if (writeKeyParam1 != null) {
                            KeyParam keyParam1 = CloneUtil.clone(writeKeyParam1);
                            keyModel.setKeyParam(keyParam1);
                            rspList.add(keyModel);
                        }
                        if (writeKeyParam2 != null) {
                            KeyParam keyParam2 = CloneUtil.clone(writeKeyParam2);
                            keyMode2.setKeyParam(keyParam2);
                            rspList.add(keyMode2);
                        }

                        if (writeTikKeyParam != null) {
                            WriteTikKeyModel writeTikKeyModel = new WriteTikKeyModel();
                            TikKeyParam tikKeyParam = CloneUtil.clone(writeTikKeyParam);
                            writeTikKeyModel.setTikKeyParam(tikKeyParam);
                            rspList.add(writeTikKeyModel);
                        }

                        if (isNewANullEmvAidParam) {
                            SetEmvAidParamModel model = new SetEmvAidParamModel(new EmvAidParam());
                            rspList.add(model);
                        }

                        if (isNewANullICSParam) {
                            SetICSParamModel model = new SetICSParamModel(new ICSParam());
                            rspList.add(model);
                        }

                    }
                }
                Log.e(TAG, "onRunCmd: return ");
                return rspList;
            }
        };


    }

    private void processShowReadCardOKParam(BaseReportedData readCardOKReportedParam, int timeout) {
        Log.w(TAG, "processShowReadCardOKParam: ");
        ArrayList<TLVDataObject> configTlvList = readCardOKReportedParam.getConfigTlvList();
        ArrayList<TLVDataObject> emvTlvList = readCardOKReportedParam.getEmvTlvList();
        Message message = new Message();
        message.what = MSG_READ_CARD_OK_STATUS;
        Bundle bundle = new Bundle();
        bundle.putInt("timeout", timeout);
        bundle.putParcelableArrayList("configTlv", configTlvList);
        bundle.putParcelableArrayList("emvTlv", emvTlvList);
        message.setData(bundle);
        handler.sendMessage(message);
    }

    private void processShowEmvAidParam(ReportedData<EmvAidParam> emvAidParamReportedParam, int timeout) {
        EmvAidParam emvAidParam = emvAidParamReportedParam.getParamBean();
        ArrayList<TLVDataObject> configTlvList = emvAidParamReportedParam.getConfigTlvList();
        ArrayList<TLVDataObject> emvTlvList = emvAidParamReportedParam.getEmvTlvList();
        orgAidParam = emvAidParam;
        Message message = new Message();
        message.what = MSG_RUN_CMD_SET_EMV_AID_PARAM;
        Bundle bundle = new Bundle();
        bundle.putInt("timeout", timeout);
        bundle.putInt("paramType", 1);//1 emvaidparam 2 icsparam
        bundle.putParcelableArrayList("configTlv", configTlvList);
        bundle.putParcelableArrayList("emvTlv", emvTlvList);
        bundle.putSerializable("param", emvAidParam);
        message.setData(bundle);
        handler.sendMessage(message);
    }

    private void processShowICSParam(ReportedData<ICSParam> icsParamReportedData, int timeout) {
        Log.w(TAG, "processShowICSParam: ");
        ICSParam icsParam = icsParamReportedData.getParamBean();
        ArrayList<TLVDataObject> configTlvList = icsParamReportedData.getConfigTlvList();
        ArrayList<TLVDataObject> emvTlvList = icsParamReportedData.getEmvTlvList();
        orgICSParam = icsParam;
        Message message = new Message();
        message.what = MSG_RUN_CMD_SET_ICS_PARAM;
        Bundle bundle = new Bundle();
        bundle.putInt("timeout", timeout);
        bundle.putInt("paramType", 2);//1 emvaidparam 2 icsparam
        bundle.putParcelableArrayList("configTlv", configTlvList);
        bundle.putParcelableArrayList("emvTlv", emvTlvList);
        bundle.putSerializable("param", icsParam);
        message.setData(bundle);
        handler.sendMessage(message);
    }

    private void startProcess() {
        text = (TextView) findViewById(R.id.textViewBase);
        signatureView = (ImageView) findViewById(R.id.iv_signature);
        progressDialog = new ProgressDialog(EasyLinkActivity.this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Processing");
        progressDialog.setIndeterminate(true);
        iscancelfiledownload = false;
        new Thread(new Runnable() {
            public void run() {
                Looper.prepare();
                if (mInterface.equals("connect")) {

                    if (mNo.equals("1")) {
                        Intent bluetoothIntent = new Intent(EasyLinkActivity.this, BluetoothActivity.class);
                        startActivity(bluetoothIntent);
                        EasyLinkActivity.this.finish();
                    }
                    if (mNo.equals("2")) {
                        startActivity(new Intent(EasyLinkActivity.this, ConnectActivity.class));
                        EasyLinkActivity.this.finish();
                    }
                    if (mNo.equals("3")) {
                        startActivity(new Intent(EasyLinkActivity.this, UsbActivity.class));
                        EasyLinkActivity.this.finish();
                    }
                    if (mNo.equals("4")) {
                        final DeviceInfo deviceInfo = new DeviceInfo(DeviceInfo.CommType.IPC);
                        int result = EasyLinkSdkManager.getInstance(EasyLinkActivity.this).connect(deviceInfo);
                        Message message = new Message();
                        message.what = MSG_IPC_CONNECT_RET;
                        message.arg1 = result;
                        handler.sendMessage(message);
                    }

                }


                if (mInterface.equals("startTransaction")) {

                    if (mNo.equals("1")) {
                        String val = cfgm.getValueByTag("amount", "1000");
                        getIndex(saleAndnoScript, val);
                    }
                    if (mNo.equals("2")) {
                        String val = cfgm.getValueByTag("amount", "1000");
                        getIndex(saleWithReport, val);
                    }
                    if (mNo.equals("3")) {
                        String val = cfgm.getValueByTag("amount", "1000");
                        getIndex(saleAndApprove, val);
                    }
                    if (mNo.equals("4")) {
                        String val = cfgm.getValueByTag("amount", "1000");
                        getIndex(saleAndDecline, val);
                    }
                    if (mNo.equals("5")) {
                        String val = cfgm.getValueByTag("amount", "1000");
                        getIndex(cashbackAndApprove, val);
                    }
                    if (mNo.equals("6")) {
                    }
                    if (mNo.equals("7")) {
                        String val = cfgm.getValueByTag("amount", "1000");
                        getIndex(saleWithReportStatus, val);
                    }
                    if (mNo.equals("8")) {
                        String val = cfgm.getValueByTag("amount", "1000");
                        getIndex(saleWithReportCancel, val);

                    }

                    if ("9".equals(mNo)) {
                        String val = cfgm.getValueByTag("amount", "1000");
                        getIndex(saleWithSetMultiAcq, val);
                    }
                    if ("10".equals(mNo)) {
                        String val = cfgm.getValueByTag("amount", "1000");
                        getIndex(refundWithSetMultiAcq, val);
                    }
                    if ("11".equals(mNo)) {
                        startTransactionWithNoDefaultData();
                    }
                }
                if (mInterface.equals("completeTransaction")) {

                    if (mNo.equals("1")) {
                        completeTransationFUN1();
                    }
                    if (mNo.equals("2")) {
                        completeTransactionWithReport();

                    }
                    if (mNo.equals("3")) {
                        completeTransactionWithCancel();
                    }

                }
                if (mInterface.equals("getPinBlock")) {

                    if (mNo.equals("1")) {
                        ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                        String val = cfg.getValueByTag(mInterface, "6225776765463826");
                        getIndex(getPinblock1, val);
                    } else if (mNo.equals("2")) {
                        getPinBlockWithReport();
                    } else if (mNo.equals("3")) {
                        getPinBlockWithCancel();
                    }

                }
                if (mInterface.equals("encryptData")) {

                    if (mNo.equals("1")) {

                        ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                        String val = cfg.getValueByTag(mInterface, "35343534353435343534353435343534");
                        getIndex(encryptData1, val);
                    }

                }
                if (mInterface.equals("setData")) {

                    if (mNo.equals("1")) {
                        ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                        String val = cfg.getValueByTag("setTransData", "0201021000");
                        getIndex(setTransData, val);
                    }

                    if (mNo.equals("2")) {
                        ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                        String val = cfg.getValueByTag("setConfigData", "0201021000");
                        getIndex(setConfigData, val);
                    }
                    if (mNo.equals("3")) {
                        setConfigDataAcitivity(setFixedConfigData);
                    }
                    if (mNo.equals("4")) {
                        setFixTrans();
                    }
                    if (mNo.equals("5")) {
                        setCompleteTransData();
                    }

                    if (mNo.equals("14")) {
                        ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                        String val = cfg.getValueByTag(mInterface, "1");
                        getIndex(setDataAbnormal2, val);
                    }

                }
                if (mInterface.equals("getData")) {

                    if (mNo.equals("1")) {
                        ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                        String val = cfg.getValueByTag("getTransData", "0201");
                        getIndex(getTransData, val);
                    }
                    if (mNo.equals("2")) {
                        ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                        String val = cfg.getValueByTag("getConfigData", "0201");
                        getIndex(getConfigData, val);
                    }
                    if (mNo.equals("3")) {
                        getAllConfigData();
                    }
                    if ("4".equals(mNo)) {
                        getAllTermInfo();
                    }


                }
                if (mInterface.equals("showPage")) {

                    if (mNo.equals("1")) {
                        showSignaturePage();
                    }
                    if("2".equals(mNo)){
                        ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                        String val = cfg.getValueByTag("showPage_barcode", "hello world,hello world,hello world,hello world,hello world,64");
                        getIndex(showpage2, val);
                    }

                    if (mNo.equals("3")) {
                        ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                        String val = cfg.getValueByTag(mInterface, "pageReqStar.xml");
                        getIndex(showpage1, val);
                    }


                }
                if (mInterface.equals("fileDownLoad")) {

                    if (mNo.equals("1")) {

                        ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                        String val = cfg.getValueByTag(mInterface, "EasyLink_UI.ui");
                        getIndex(fileDownload1, val);
                    }
                    if (mNo.equals("2")) {
                        downloadD180UI();
                    }
                    if (mNo.equals("3")) {
                        downloadEasylinkBin();
                    }
                    if (mNo.equals("4")) {
                        downloadBmp();
                    }
                    if (mNo.equals("5")) {
                        downloadClssParam();
                    }
                    if (mNo.equals("6")) {
                        downloadEmvParam();
                    }
                    if (mNo.equals("7")) {
                        downloadFontFile();
                    }
                    if (mNo.equals("8")) {
                        downloadMonitorFile();
                    }
                }
                if (mInterface.equals("switchCommMode")) {

                    if (mNo.equals("1")) {
                        switchCommModeFUN1("1");

                    }
                    if (mNo.equals("2")) {
                        switchCommModeFUN1("0");
                    }

                }
                if (mInterface.equals("EMV")) {

                    if (mNo.equals("1")) {
                        ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                        String val = cfg.getValueByTag(mInterface, "9F0206000000000001");
                        getIndex(emvfun1, val);
                    }
                    if (mNo.equals("2")) {
                        ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                        String val = cfg.getValueByTag(mInterface, "9F0206000000000001");
                        getIndex(emvfun2, val);
                    }
                    if (mNo.equals("3")) {
                        ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                        String val = cfg.getValueByTag(mInterface, "9F0206000000000001");
                        getIndex(emvfun3, val);
                    }
                    if (mNo.equals("4")) {
                        EMVFUN4();
                    }

                }
                if (mInterface.equals("searchDevices")) {
                }
                if (mInterface.equals("cancelFileDownload")) {
                    if (mNo.equals("1")) {
                        cancelFileDownload();
                    }
                }
                if (mInterface.equals("calcMac")) {
                    if (mNo.equals("1")) {
                        ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                        String val = cfg.getValueByTag(mInterface, "343031323334353637383930394439383700000000000000");
                        getIndex(calcMAC, val);
                    }
                }
                 if (mInterface.equals("IncreaseKsn")) {
                    if (mNo.equals("1")) {
                        ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                        String val = cfg.getValueByTag(mInterface, "5");
                        getIndex(increaseKSN, val);
                    }
                }

                if (mInterface.equals("GetKeyInfo")) {
                    if (mNo.equals("1")) {
                        ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                        String val = cfg.getValueByTag(mInterface, "10");
                        getIndex(getKeyInfo, val);
                    }
                }


                if (mInterface.equals("WriteKey")) {
                    if (mNo.equals("1")) {
                        testWriteTWK();
                    } else if (mNo.equals("2")) {
                        testWriteTIK();
                    } else if (mNo.equals("3")) {
                        testCalPlainTPK();
                    } else if (mNo.equals("4")) {
                        testCalEncryptTPK();
                    } else if (mNo.equals("5")) {
                        testCalPlainTAK();
                    } else if (mNo.equals("6")) {
                        testCalEncryptTAK();
                    } else if (mNo.equals("7")) {
                        testCalPlainTDK();
                    } else if (mNo.equals("8")) {
                        testCalEncryptTDK();
                    } else if (mNo.equals("9")) {
                        testCalEncryptTDKKcv();
                    } else if (mNo.equals("10")) {
                        testWriteErrKey();
                    } else if (mNo.equals("11")) {
                        testCalPINByNoKCVTIK();
                    } else if (mNo.equals("12")) {
                        testCalPINByKCVTIK();
                    }
                }

//                if (mInterface.equals("RKI")){
//                    startRKIFuncActivity();
//                    if (mNo.equals("1")) {
//                        testRKIRemoteDownloadKey();
//                    } else if (mNo.equals("2")){
//                        testRKIUnbid();
//                    } else if (mNo.equals("3")){
//                        testRKIDebug();
//                    }
//                }

            }
        }).start();
    }

//    private void startRKIFuncActivity() {
//        if (mInterface.equals("RKI")){
//            Intent intent = new Intent(EasyLinkActivity.this, RKIFuncActivity.class);
//            startActivity(intent);
//        }
//    }
    public void getIndex(int func, String index) {
        Intent it = new Intent();
        Intent intent = getIntent();
        String mInterface1 = intent.getStringExtra("Interface");
        it.putExtra("Interface", mInterface1);
        it.putExtra("FUNC", func);
        it.putExtra("index", index);
        it.setClass(getApplicationContext(), InputActivity.class);
        startActivityForResult(it, 0);
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
        }
        return false;
    }

    public void testWriteTIK() {
        testWriteTIKNoKcvCheck();
        testWriteTIKKcvCheck();
    }

    public void testCalPlainTPK() {
        byte data[] = {0x02, 0x02, 0x01, 0x01,    //tpk
                0x02, 0x03, 0x01, 0x1f};           //  tpk index 31
        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        int ret = easyLink.setData(DataModel.DataType.CONFIGURATION_DATA, data, failedTags);
        Log.d(TAG, "testCalPlainTPK setData ret = " + ret);

        String PAN = "1234012345678901";
        ByteArrayOutputStream pinBlock = new ByteArrayOutputStream();
        ByteArrayOutputStream ksn = new ByteArrayOutputStream();
        ret = easyLink.getPinBlock(PAN, pinBlock, ksn);
        Log.d(TAG, "testCalPlainTPK getPinBlock:" + ret + "\npinBlock:" + bcd2Str(pinBlock.toByteArray())
                + "\nksn:" + bcd2Str(ksn.toByteArray()));
        updateResult("testCalPlainTPK getPinBlock:" + ret + "\npinBlock:" + bcd2Str(pinBlock.toByteArray())
                + "\nksn:" + bcd2Str(ksn.toByteArray()) + "\npin:1234,expect pinblock:" + "44D4B20DDBF8DD15");

        //enter pin:1234,the expect pinblock is :44 D4 B2 0D DB F8 DD 15, this is calc by tool
    }

    private void testWriteTWK() {
        testWriteKey_TMK();
        testWriteKey_PlainTPK();
        testWriteKey_EncryptTPK();
        testWriteKey_PlainTAK();
        testWriteKey_EncryptTAK();
        testWriteKey_PlainTDK();
        testWriteKey_EncryptTDK();
        testWriteKey_EncryptTDKWithKCV();

    }

    private void testWriteKey_TMK() {
        byte[] tmk = new byte[]{0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33};

        KeyInfo keyInfo = new KeyInfo();
        keyInfo.setSrcKeyIndex((byte) 0);
        keyInfo.setSrcKeyType((byte) KeyType.PED_NONE);
        keyInfo.setDstKeyIndex((byte) 30);
        keyInfo.setDstKeyLen((byte) tmk.length);
        keyInfo.setDstKeyType((byte) KeyType.PED_TMK);
        keyInfo.setDstKeyValue(tmk);

        KcvInfo kcvInfo = new KcvInfo();
        kcvInfo.setCheckMode((byte) 0);

        int ret = easyLink.writeKey(keyInfo, kcvInfo, 60);
        Log.d(TAG, "testWriteKey_TMK = " + ret);
        updateResult("write key:" + ret);
    }

    private void testWriteKey_PlainTPK() {
        byte[] tpk = new byte[]{0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33};
        KeyInfo keyInfo = new KeyInfo();
        keyInfo.setSrcKeyIndex((byte) 0);
        keyInfo.setSrcKeyType((byte) KeyType.PED_NONE);
        keyInfo.setDstKeyIndex((byte) 31);
        keyInfo.setDstKeyLen((byte) tpk.length);
        keyInfo.setDstKeyType((byte) KeyType.PED_TPK);
        keyInfo.setDstKeyValue(tpk);

        KcvInfo kcvInfo = new KcvInfo();
        kcvInfo.setCheckMode((byte) 0);
        int ret = easyLink.writeKey(keyInfo, kcvInfo, 60);
        Log.d(TAG, "testWriteKey_PlainTPK = " + ret);
        updateResult("testWriteKey_PlainTPK key:" + ret);
    }

    private void testWriteKey_EncryptTPK() {
        byte[] tpk = new byte[]{0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33};
        KeyInfo keyInfo = new KeyInfo();
        keyInfo.setSrcKeyIndex((byte) 30);
        keyInfo.setSrcKeyType((byte) KeyType.PED_TMK);
        keyInfo.setDstKeyIndex((byte) 32);
        keyInfo.setDstKeyLen((byte) (byte) tpk.length);
        keyInfo.setDstKeyType((byte) KeyType.PED_TPK);
        keyInfo.setDstKeyValue(tpk);

        KcvInfo kcvInfo = new KcvInfo();
        kcvInfo.setCheckMode((byte) 0);
        int ret = easyLink.writeKey(keyInfo, kcvInfo, 60);
        Log.d(TAG, "testWriteKey_EncryptTPK = " + ret);
        updateResult("testWriteKey_EncryptTPK key:" + ret);
    }

    private void testWriteKey_PlainTAK() {
        byte[] tak = new byte[]{0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33};

        KeyInfo keyInfo = new KeyInfo();
        keyInfo.setSrcKeyIndex((byte) 0);
        keyInfo.setSrcKeyType((byte) KeyType.PED_NONE);
        keyInfo.setDstKeyIndex((byte) 34);
        keyInfo.setDstKeyLen((byte) tak.length);
        keyInfo.setDstKeyType((byte) KeyType.PED_TAK);
        keyInfo.setDstKeyValue(tak);

        KcvInfo kcvInfo = new KcvInfo();
        kcvInfo.setCheckMode((byte) 0);
        int ret = easyLink.writeKey(keyInfo, kcvInfo, 60);
        Log.d(TAG, "testWriteKey_PlainTAK = " + ret);
        updateResult("testWriteKey_PlainTAK key:" + ret);
    }

    private void testWriteKey_EncryptTAK() {
        byte[] tak = new byte[]{0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33};

        KeyInfo keyInfo = new KeyInfo();
        keyInfo.setSrcKeyIndex((byte) 30);
        keyInfo.setSrcKeyType((byte) KeyType.PED_TMK);
        keyInfo.setDstKeyIndex((byte) 35);
        keyInfo.setDstKeyLen((byte) tak.length);
        keyInfo.setDstKeyType((byte) KeyType.PED_TAK);
        keyInfo.setDstKeyValue(tak);

        KcvInfo kcvInfo = new KcvInfo();
        kcvInfo.setCheckMode((byte) 0);
        int ret = easyLink.writeKey(keyInfo, kcvInfo, 60);
        Log.d(TAG, "testWriteKey_EncryptTAK = " + ret);
        updateResult("testWriteKey_EncryptTAK key:" + ret);
    }

    private void testWriteKey_PlainTDK() {
        byte[] tdk = new byte[]{0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33};

        KeyInfo keyInfo = new KeyInfo();
        keyInfo.setSrcKeyIndex((byte) 0);
        keyInfo.setSrcKeyType((byte) KeyType.PED_NONE);
        keyInfo.setDstKeyIndex((byte) 36);
        keyInfo.setDstKeyLen((byte) tdk.length);
        keyInfo.setDstKeyType((byte) KeyType.PED_TDK);
        keyInfo.setDstKeyValue(tdk);

        KcvInfo kcvInfo = new KcvInfo();
        kcvInfo.setCheckMode((byte) 0);
        int ret = easyLink.writeKey(keyInfo, kcvInfo, 60);
        Log.d(TAG, "testWriteKey_PlainTDK = " + ret);
        updateResult("testWriteKey_PlainTDK key:" + ret);
    }

    private void testWriteKey_EncryptTDK() {
        byte[] tak = new byte[]{0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33};

        KeyInfo keyInfo = new KeyInfo();
        keyInfo.setSrcKeyIndex((byte) 30);
        keyInfo.setSrcKeyType((byte) KeyType.PED_TMK);
        keyInfo.setDstKeyIndex((byte) 37);
        keyInfo.setDstKeyLen((byte) tak.length);
        keyInfo.setDstKeyType((byte) KeyType.PED_TDK);
        keyInfo.setDstKeyValue(tak);

        KcvInfo kcvInfo = new KcvInfo();
        kcvInfo.setCheckMode((byte) 0);
        int ret = easyLink.writeKey(keyInfo, kcvInfo, 60);
        Log.d(TAG, "testWriteKey_EncryptTDK = " + ret);
        updateResult("testWriteKey_EncryptTDK key:" + ret);
    }

    private void testWriteKey_EncryptTDKWithKCV() {
        byte[] tak = new byte[]{0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33};

        KeyInfo keyInfo = new KeyInfo();
        keyInfo.setSrcKeyIndex((byte) 30);
        keyInfo.setSrcKeyType((byte) KeyType.PED_TMK);
        keyInfo.setDstKeyIndex((byte) 38);
        keyInfo.setDstKeyLen((byte) tak.length);
        keyInfo.setDstKeyType((byte) KeyType.PED_TDK);
        keyInfo.setDstKeyValue(tak);

        KcvInfo kcvInfo = new KcvInfo();
        kcvInfo.setCheckMode((byte) 0x01);
        //9E23AE2406347C53
        byte[] checkBuf = new byte[]{(byte) 0x04, (byte) 0x9e, (byte) 0x23, (byte) 0xae, (byte) 0x24}; //checkBuf[0]:the kcv Data Length, checkBuf + 1: kcv Data [(byte) 0x9e, (byte) 0x23, (byte) 0xae,(byte)0x24]
//        byte[] checkBuf = new byte[]{(byte) 0x03,(byte) 0x9e, (byte) 0x23, (byte) 0xae};
//        byte[] checkBuf = new byte[]{(byte) 0x9e, (byte) 0x23, (byte) 0xae,(byte)0x24};
        kcvInfo.setCheckBuf(checkBuf);
        int ret = easyLink.writeKey(keyInfo, kcvInfo, 60);
        Log.d(TAG, "testWriteKey_EncryptTDKWithKCV = " + ret);
        updateResult("testWriteKey_EncryptTDKWithKCV key:" + ret);
    }

    private void testWriteErrKey() {
        byte[] tak = new byte[]{0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33};

        KeyInfo keyInfo = new KeyInfo();
        keyInfo.setSrcKeyIndex((byte) 0);
        keyInfo.setSrcKeyType((byte) KeyType.PED_NONE);
        keyInfo.setDstKeyIndex((byte) 101);
        keyInfo.setDstKeyLen((byte) tak.length);
        keyInfo.setDstKeyType((byte) KeyType.PED_TPK);
        keyInfo.setDstKeyValue(tak);

        KcvInfo kcvInfo = new KcvInfo();
        kcvInfo.setCheckMode((byte) 0);
        int ret = easyLink.writeKey(keyInfo, kcvInfo, 60);
        Log.d(TAG, "testWriteErrKey = " + ret);
        updateResult("testWriteErrKey key:" + ret);
    }



    private void testCalEncryptTPK() {
        byte data[] = {0x02, 0x02, 0x01, 0x01,
                0x02, 0x03, 0x01, 0x20};// encrypt tpk index 32
        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        int ret = easyLink.setData(DataType.CONFIGURATION_DATA, data, failedTags);
        Log.d(TAG, "testCalEncryptTPK setData ret = " + ret);

        String PAN = "1234012345678901";
        ByteArrayOutputStream pinBlock = new ByteArrayOutputStream();
        ByteArrayOutputStream ksn = new ByteArrayOutputStream();
        ret = easyLink.getPinBlock(PAN, pinBlock, ksn);
        Log.d(TAG, "testCalEncryptTPK getPinBlock:" + ret + "\npinBlock:" + bcd2Str(pinBlock.toByteArray())
                + "\nksn:" + bcd2Str(ksn.toByteArray()));
        updateResult("testCalEncryptTPK getPinBlock:" + ret + "\npinBlock:" + bcd2Str(pinBlock.toByteArray())
                + "\nksn:" + bcd2Str(ksn.toByteArray()) + "\npin:1234, expect pinblock:" + "77104B29C8C6F3DA");
        //enter pin:1234,the expect pinblock is :77104B29C8C6F3DA, this is calc by tool

    }

    private void testCalPlainTAK() {
        byte data[] = {
                0x02, 0x12, 0x01, 0x01,
                0x02, 0x13, 0x01, 0x00,    // mode
                0x02, 0x10, 0x01, 0x22};    //tdk key index 34
        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        int ret = easyLink.setData(DataType.CONFIGURATION_DATA, data, failedTags);
        Log.d(TAG, "testCalPlainTDK setData ret = " + ret);

        String plainData = "33333333333333333333333333333333";
        int length = plainData.length() / 2;
        if (length == 0) {
            return;
        }

        byte[] databy = StringUtils.hexString2Bytes(plainData, length);

        ByteArrayOutputStream mac = new ByteArrayOutputStream();
        ret = easyLink.calcMAC(databy, mac);
        updateResult("calcMac:ret=" + ret + "\ncalcMac:" + bcd2Str(mac.toByteArray()) + "\nexpect mac:" + "C791FFA366706230");
        //expect data is:C791FFA366706230
    }

    private void testCalEncryptTAK() {
        byte data[] = {
                0x02, 0x12, 0x01, 0x01,
                0x02, 0x13, 0x01, 0x00,
                0x02, 0x10, 0x01, 0x23};    //key index 35
        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        int ret = easyLink.setData(DataType.CONFIGURATION_DATA, data, failedTags);
        Log.d(TAG, "testCalEncryptTAK setData ret = " + ret);

        String plainData = "33333333333333333333333333333333";
        int length = plainData.length() / 2;
        if (length == 0) {
            return;
        }

        byte[] databy = StringUtils.hexString2Bytes(plainData, length);

        ByteArrayOutputStream mac = new ByteArrayOutputStream();
        ret = easyLink.calcMAC(databy, mac);
        updateResult("calcMac:ret=" + ret + "\ncalcMac:" + bcd2Str(mac.toByteArray()) + "\nexpect mac:" + "5276A900457B0932");
        //expect data is:5276A900457B0932
    }

    private void testCalPlainTDK() {
        byte data[] = {
                0x02, 0x05, 0x01, 0x01,
                0x02, 0x06, 0x01, 0x24};    //tdk key index 36
        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        int ret = easyLink.setData(DataType.CONFIGURATION_DATA, data, failedTags);
        Log.d(TAG, "testCalPlainTDK setData ret = " + ret);

        String plainData = "33333333333333333333333333333333";
        int length = plainData.length() / 2;
        if (length == 0) {
            return;
        }

        byte[] databy = StringUtils.hexString2Bytes(plainData, length);

        ByteArrayOutputStream respData = new ByteArrayOutputStream();

        ret = easyLink.encryptData(databy, respData);

        updateResult("encryptData:ret=" + ret + "\nrespData:" + bcd2Str(respData.toByteArray()) + "\nexpect data:" +
                "0432ED386F2DE3280432ED386F2DE328");
        //expect data is :0432ED386F2DE3280432ED386F2DE328
    }

    private void testCalEncryptTDK() {
        byte data[] = {
                0x02, 0x05, 0x01, 0x01,
                0x02, 0x06, 0x01, 0x25};    //key index 37
        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        int ret = easyLink.setData(DataType.CONFIGURATION_DATA, data, failedTags);
        Log.d(TAG, "testCalEncryptTDK setData ret = " + ret);

        String plainData = "33333333333333333333333333333333";
        int length = plainData.length() / 2;
        if (length == 0) {
            return;
        }

        byte[] databy = StringUtils.hexString2Bytes(plainData, length);

        ByteArrayOutputStream respData = new ByteArrayOutputStream();

        ret = easyLink.encryptData(databy, respData);

        updateResult("encryptData:" + ret + "\nrespData:" + bcd2Str(respData.toByteArray()) + "\nexpect data:" +
                "2B6AE2215C2B04EC2B6AE2215C2B04EC");
        //expect data is :2B6AE2215C2B04EC2B6AE2215C2B04EC
    }

    private void testCalEncryptTDKKcv() {
        byte data[] = {
                0x02, 0x05, 0x01, 0x01,
                0x02, 0x06, 0x01, 0x26};    //key index 38
        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        int ret = easyLink.setData(DataType.CONFIGURATION_DATA, data, failedTags);
        Log.d(TAG, "testCalEncryptTDKKcv setData ret = " + ret);

        String plainData = "33333333333333333333333333333333";
        int length = plainData.length() / 2;
        if (length == 0) {
            return;
        }

        byte[] databy = StringUtils.hexString2Bytes(plainData, length);

        ByteArrayOutputStream respData = new ByteArrayOutputStream();

        ret = easyLink.encryptData(databy, respData);

        updateResult("encryptData:" + ret + "\nrespData:" + bcd2Str(respData.toByteArray()) + "\nexpect data:" +
                "2B6AE2215C2B04EC2B6AE2215C2B04EC");
        //expect data is :2B6AE2215C2B04EC2B6AE2215C2B04EC
    }

    private void testWriteTIKNoKcvCheck() {
        int ret = 0;
        String ipek = "950D1A0F06CD9C078136A5725ADBE5F1";
        String ksn = "88888851400018400000";

        int length = ipek.length() / 2;
        if (length == 0) {
            return;
        }
        byte[] ipekData = StringUtils.hexString2Bytes(ipek, length);

        length = ksn.length() / 2;
        if (length == 0) {
            return;
        }
        byte[] ksnData = StringUtils.hexString2Bytes(ksn, length);

        KcvInfo kcvInfo = new KcvInfo();
        kcvInfo.setCheckMode((byte) 0x00);

        ret = easyLink.writeTIK((byte) 5, (byte) 0, ipekData, ksnData, kcvInfo, 60);
        Log.d(TAG, "testWriteTIKNoKcvCheck = " + ret);
        updateResult("testWriteTIKNoKcvCheck key:" + ret);
    }

    private void testWriteTIKKcvCheck() {
        int ret = 0;
        String ipek = "6AC292FAA1315B4D858AB3A3D7D5933A";
        String ksn = "FFFF9876543210E00000";

        int length = ipek.length() / 2;
        if (length == 0) {
            return;
        }
        byte[] ipekData = StringUtils.hexString2Bytes(ipek, length);

        length = ksn.length() / 2;
        if (length == 0) {
            return;
        }
        byte[] ksnData = StringUtils.hexString2Bytes(ksn, length);

        KcvInfo kcvInfo = new KcvInfo();
        kcvInfo.setCheckMode((byte) 0x01);
//        byte[] checkBuf = new byte[]{(byte) 0x03, (byte) 0xaf, (byte) 0x8c, (byte) 0x07};
        //AF8C074A692A3666
        byte[] checkBuf = new byte[]{(byte) 0x04, (byte) 0xaf, (byte) 0x8c, (byte) 0x07, (byte) 0x4A};//checkBuf[0]:the kcv Data Length, checkBuf + 1: kcv Data [ (byte) 0xaf, (byte) 0x8c, (byte) 0x07,(byte)0x4A]
        kcvInfo.setCheckBuf(checkBuf);

        ret = easyLink.writeTIK((byte) 6, (byte) 0, ipekData, ksnData, kcvInfo, 60);
        Log.d(TAG, "testWriteTIKKcvCheck = " + ret);
        updateResult("testWriteTIKKcvCheck key:" + ret);
    }



    private void testCalPINByNoKCVTIK() {
        byte data[] = {0x02, 0x02, 0x01, 0x02,
                0x02, 0x03, 0x01, 0x05};//dukpt index
        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        int ret = easyLink.setData(DataType.CONFIGURATION_DATA, data, failedTags);
        Log.d(TAG, "testCalPINByNoKCVTIK setData ret = " + ret);

        String PAN = "4012345678909";
        ByteArrayOutputStream pinBlock = new ByteArrayOutputStream();
        ByteArrayOutputStream ksn = new ByteArrayOutputStream();
        ret = easyLink.getPinBlock(PAN, pinBlock, ksn);
        Log.d(TAG, "testCalPINByNoKCVTIK getPinBlock:" + ret + "\npinBlock:" + bcd2Str(pinBlock.toByteArray())
                + "\nksn:" + bcd2Str(ksn.toByteArray()));
        updateResult("testCalPINByNoKCVTIK getPinBlock:" + ret + "\npinBlock:" + bcd2Str(pinBlock.toByteArray())
                + "\nksn:" + bcd2Str(ksn.toByteArray()) + "\nexpect pinblock:" + "1B9C1845EB993A7A");
        //enter pin:1234,the expect pinblock is :1B9C1845EB993A7A, this is calc by tool
    }

    private void testCalPINByKCVTIK() {
        byte data[] = {0x02, 0x02, 0x01, 0x02,
                0x02, 0x03, 0x01, 0x06};//dukpt index
        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        int ret = easyLink.setData(DataType.CONFIGURATION_DATA, data, failedTags);
        Log.d(TAG, "testCalPINByNoKCVTIK setData ret = " + ret);

        String PAN = "4012345678909";
        ByteArrayOutputStream pinBlock = new ByteArrayOutputStream();
        ByteArrayOutputStream ksn = new ByteArrayOutputStream();
        ret = easyLink.getPinBlock(PAN, pinBlock, ksn);
        Log.d(TAG, "testCalPINByNoKCVTIK getPinBlock:" + ret + "\npinBlock:" + bcd2Str(pinBlock.toByteArray())
                + "\nksn:" + bcd2Str(ksn.toByteArray()));
        updateResult("testCalPINByNoKCVTIK getPinBlock:" + ret + "\npinBlock:" + bcd2Str(pinBlock.toByteArray())
                + "\nksn:" + bcd2Str(ksn.toByteArray()) + "\nexpect pinblock:" + "1B9C1845EB993A7A");
        //enter pin:1234,the expect pinblock is :1B9C1845EB993A7A, this is calc by tool
    }

    private void saleWithReport(final String amount) {
        Log.d(TAG, "report data start");
        new Thread(new Runnable() {
            @Override
            public void run() {
                setSaleData(amount);
                int transRet = easyLink.startTransaction(new IReportListener() {
                    @Override
                    public byte[] onReport(final byte[] reportedData) {
                        if (reportedData != null) {
                            Log.d("TAG", "report data = " + new String(reportedData));
                            updateResult("startTransaction:" + new String(reportedData));
                        }
                        Log.d("TAG", "report data return");
                        return new byte[0];
                    }
                });
                updateResult("startTransaction:" + transRet);
                Log.d("TAG", "startTransaction return:" + transRet);
            }
        }).start();

    }

    private void setRefundData(String amount) {
        Log.d(TAG, "setSaleData amout:" + amount + "len :" + Tools.str2Bcd(amount).length);
        byte[] amountData = new byte[6];
        System.arraycopy(Tools.str2Bcd(amount), 0, amountData, 6 - Tools.str2Bcd(amount).length, Tools.str2Bcd(amount).length);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");// HH:mm:ss

        Date date = new Date(System.currentTimeMillis());
        Log.d(TAG, "setSaleData date:" + simpleDateFormat.format(date));

        String dataString = "9C01205F2A0200005F360102" +
                "9a03" + simpleDateFormat.format(date).substring(2, 8) +
                "9f2103" + simpleDateFormat.format(date).substring(8, 14) +
                "9f0206" + Tools.bcd2Str(amountData);
        Log.d(TAG, "setSaleData date:" + dataString);

        byte[] data = Tools.str2Bcd(dataString);

        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        int ret = easyLink.setData(DataType.TRANSACTION_DATA, data, failedTags);
        updateResult("setSaleData setData:" + ret + "\n" + dataString);
    }

    private void setSaleData(String amount) {
        Log.d(TAG, "setSaleData amout:" + amount + "len :" + Tools.str2Bcd(amount).length);
        byte[] amountData = new byte[6];
        System.arraycopy(Tools.str2Bcd(amount), 0, amountData, 6 - Tools.str2Bcd(amount).length, Tools.str2Bcd(amount).length);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");// HH:mm:ss

        Date date = new Date(System.currentTimeMillis());
        Log.d(TAG, "setSaleData date:" + simpleDateFormat.format(date));

//        String dataString = "9C01005F3601025F2A020826" +
        String dataString = "9C0100" +
                "9a03" + simpleDateFormat.format(date).substring(2, 8) +
                "9f2103" + simpleDateFormat.format(date).substring(8, 14) +
                "9f0206" + Tools.bcd2Str(amountData);
        Log.d(TAG, "setSaleData date:" + dataString);

        byte[] data = Tools.str2Bcd(dataString);

        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        int ret = easyLink.setData(DataType.TRANSACTION_DATA, data, failedTags);
        updateResult("setSaleData setData:" + ret + "\n" + dataString);
    }

    private void getData(int retCode, int onlineResult) {
        String data = "RetCode:" + retCode + "\n";
        ByteArrayOutputStream cvm = new ByteArrayOutputStream();
        int ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x03, 0x1a}, cvm);
        data += "cvm ret:" + ret + "\ndata:" + Tools.bcd2Str(cvm.toByteArray()) + "\n";

        ByteArrayOutputStream cardResult = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x03, 0x1b}, cardResult);
        data += "card Proecess ret:" + ret + "\ndata:" + Tools.bcd2Str(cardResult.toByteArray()) + "\n";

        ByteArrayOutputStream clssType = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x03, 0x02}, clssType);
        data += "clssType ret:" + ret + "\ndata:" + Tools.bcd2Str(clssType.toByteArray()) + "\n";

        ByteArrayOutputStream currentPathType = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x03, 0x03}, currentPathType);
        data += "currentPathType ret:" + ret + "\ndata:" + Tools.bcd2Str(currentPathType.toByteArray()) + "\n";

        ByteArrayOutputStream amount = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.TRANSACTION_DATA, new byte[]{(byte) 0x9f, 0x02}, amount);
        data += "amount ret:" + ret + "\ndata:" + Tools.bcd2Str(amount.toByteArray()) + "\n";

        ByteArrayOutputStream tvr = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.TRANSACTION_DATA, new byte[]{(byte) 0x95}, tvr);
        data += "tvr ret:" + ret + "\ndata:" + Tools.bcd2Str(tvr.toByteArray()) + "\n";

        ByteArrayOutputStream tsi = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.TRANSACTION_DATA, new byte[]{(byte) 0x9b}, tsi);
        data += "tsi ret:" + ret + "\ndata:" + Tools.bcd2Str(tsi.toByteArray()) + "\n";

        String resp = null;
        //online req
        if (cardResult.toByteArray()[4] == 1 && cardResult.toByteArray()[5] == 0x02) {
            //dpas
            if ((clssType.toByteArray()[4] == 1 && clssType.toByteArray()[5] == 0x06)
                    && (currentPathType.toByteArray()[4] == 1 && currentPathType.toByteArray()[5] == 15)) {
                //resp ="910ae344ee82e00ca876303072219F1804AABBCCDD860984DA00CB04AABBCCDD860D841E000008AABBCCDDAABBCCDD8a0230308906313233343536";
                //resp ="910ae344ee82e00ca8763030720f860d841e0000080e59fd2135d7cc288a0230308906313233343536";
                resp = "910ae344ee82e00ca87630307224860d841e0000080e59fd2135d7cc28861384da00CB0E000000030D406B923E72FED3E7D88a0230358906313233343536";
            } else {
                resp = "910ae344ee82e00ca876303072289F1804AABBCCDD86098424000004ABBBCCDD86098418000004BBBBCCDD86098416000004CCBBCCDD8a0230308906313233343536";
            }

            if (onlineResult == 0x03) {
                ByteArrayOutputStream online = new ByteArrayOutputStream();
                ret = easyLink.setData(DataType.CONFIGURATION_DATA, new byte[]{(byte) 0x03, 0x08, 0x01, 0x00}, online);
                data += "set online result ret:" + ret + "\ndata:" + "03080100" + "\n";
            } else {
                ByteArrayOutputStream online = new ByteArrayOutputStream();
                ret = easyLink.setData(DataType.CONFIGURATION_DATA, new byte[]{(byte) 0x03, 0x08, 0x01, 0x01}, online);
                data += "set online result ret:" + ret + "\ndata:" + "03080101" + "\n";
            }
            //M-TIP05.Test.04.Scenario.01
            //Uses Cards
            //String resp ="910ae344ee82e00ca876303072289F1804AABBCCDD86098424000004AABBCCDD86098418000004AABBCCDD86098416000004AABBCCDD72289F1804AABBCCDD86098416000004AABBCCDD86098418000004AABBCCDD86098416000004AABBCCDD72289F1804AABBCCDD86098424000004AABBCCDD86098418000004AABBCCDD86098416000004AABBCCDD72289F1804AABBCCDD86098C24000004AABBCCDD86098418000004AABBCCDD86098416000004AABBCCDD72289F1804AABBCCDD86098424000004AABBCCDD86098418000004AABBCCDD86098416000004AABBCCDD8a0230308906313233343536";
            byte[] respdata = Tools.str2Bcd(resp);
            ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
            ret = easyLink.setData(DataType.TRANSACTION_DATA, respdata, failedTags);
            data += "auth scrpit ret:" + ret + "\ndata:" + resp + "\n";

            ret = easyLink.completeTransaction();
            data += "completeTransaction ret:" + ret;
        }


        updateResult("startTransaction result:" + data);
    }

    private void getCompleteTransData(int onlineResult, boolean withCancel) {
        String data = " ";
        ByteArrayOutputStream cvm = new ByteArrayOutputStream();
        int ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x03, 0x1a}, cvm);
        data += "cvm ret:" + ret + "\ndata:" + Tools.bcd2Str(cvm.toByteArray()) + "\n";

        ByteArrayOutputStream cardResult = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x03, 0x1b}, cardResult);
        data += "card Proecess ret:" + ret + "\ndata:" + Tools.bcd2Str(cardResult.toByteArray()) + "\n";

        ByteArrayOutputStream clssType = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x03, 0x02}, clssType);
        data += "clssType ret:" + ret + "\ndata:" + Tools.bcd2Str(clssType.toByteArray()) + "\n";

        ByteArrayOutputStream currentPathType = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x03, 0x03}, currentPathType);
        data += "currentPathType ret:" + ret + "\ndata:" + Tools.bcd2Str(currentPathType.toByteArray()) + "\n";

        ByteArrayOutputStream amount = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.TRANSACTION_DATA, new byte[]{(byte) 0x9f, 0x02}, amount);
        data += "amount ret:" + ret + "\ndata:" + Tools.bcd2Str(amount.toByteArray()) + "\n";

        ByteArrayOutputStream tvr = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.TRANSACTION_DATA, new byte[]{(byte) 0x95}, tvr);
        data += "tvr ret:" + ret + "\ndata:" + Tools.bcd2Str(tvr.toByteArray()) + "\n";

        ByteArrayOutputStream tsi = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.TRANSACTION_DATA, new byte[]{(byte) 0x9b}, tsi);
        data += "tsi ret:" + ret + "\ndata:" + Tools.bcd2Str(tsi.toByteArray()) + "\n";

        String resp = null;
        //online req
        if (cardResult.toByteArray()[4] == 1 && cardResult.toByteArray()[5] == 0x02) {
            //dpas
            if ((clssType.toByteArray()[4] == 1 && clssType.toByteArray()[5] == 0x06)
                    && (currentPathType.toByteArray()[4] == 1 && currentPathType.toByteArray()[5] == 15)) {
                //resp ="910ae344ee82e00ca876303072219F1804AABBCCDD860984DA00CB04AABBCCDD860D841E000008AABBCCDDAABBCCDD8a0230308906313233343536";
                //resp ="910ae344ee82e00ca8763030720f860d841e0000080e59fd2135d7cc288a0230308906313233343536";
                resp = "910ae344ee82e00ca87630307224860d841e0000080e59fd2135d7cc28861384da00CB0E000000030D406B923E72FED3E7D88a0230358906313233343536";
            } else {
                resp = "910ae344ee82e00ca876303072289F1804AABBCCDD86098424000004AABBCCDD86098418000004AABBCCDD86098416000004AABBCCDD8a0230308906313233343536";
            }

            if (onlineResult == 0x03) {
                ByteArrayOutputStream online = new ByteArrayOutputStream();
                ret = easyLink.setData(DataType.CONFIGURATION_DATA, new byte[]{(byte) 0x03, 0x08, 0x01, 0x00}, online);
                data += "set online result ret:" + ret + "\ndata:" + "03080100" + "\n";
            } else {
                ByteArrayOutputStream online = new ByteArrayOutputStream();
                ret = easyLink.setData(DataType.CONFIGURATION_DATA, new byte[]{(byte) 0x03, 0x08, 0x01, 0x01}, online);
                data += "set online result ret:" + ret + "\ndata:" + "03080101" + "\n";
            }
            //M-TIP05.Test.04.Scenario.01
            //Uses Cards
            //String resp ="910ae344ee82e00ca876303072289F1804AABBCCDD86098424000004AABBCCDD86098418000004AABBCCDD86098416000004AABBCCDD72289F1804AABBCCDD86098416000004AABBCCDD86098418000004AABBCCDD86098416000004AABBCCDD72289F1804AABBCCDD86098424000004AABBCCDD86098418000004AABBCCDD86098416000004AABBCCDD72289F1804AABBCCDD86098C24000004AABBCCDD86098418000004AABBCCDD86098416000004AABBCCDD72289F1804AABBCCDD86098424000004AABBCCDD86098418000004AABBCCDD86098416000004AABBCCDD8a0230308906313233343536";
            byte[] respdata = Tools.str2Bcd(resp);
            ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
            ret = easyLink.setData(DataType.TRANSACTION_DATA, respdata, failedTags);
            data += "auth scrpit ret:" + ret + "\ndata:" + resp + "\n";

            if (withCancel) {
                reportWithCancel = true;
            } else {
                reportWithCancel = false;
            }
            enterPinReportWithCancel = false;
            easyLink.registerReportStatusListener(reportStatusListener);
            ret = easyLink.completeTransaction();
            data += "completeTransaction ret:" + ret;
        }
        updateResult("completeTransaction with " + (withCancel ? "Cancel" : "Report") + ", result:\n" + data);
    }

    private void startTransationSaleAndAprrove(final String amount) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                setSaleData(amount);
                int ret = easyLink.startTransaction();
                getData(ret, 0x03);
            }
        }).start();

    }

    private void getDataNoScropt(int retCode, int onlineResult) {
        String data = "RetCode:" + retCode + "\n";
        ByteArrayOutputStream cvm = new ByteArrayOutputStream();
        int ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x03, 0x1a}, cvm);
        data += "cvm ret:" + ret + "\ndata:" + Tools.bcd2Str(cvm.toByteArray()) + "\n";

        ByteArrayOutputStream cardResult = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x03, 0x1b}, cardResult);
        data += "card Proecess ret:" + ret + "\ndata:" + Tools.bcd2Str(cardResult.toByteArray()) + "\n";

        ByteArrayOutputStream amount = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.TRANSACTION_DATA, new byte[]{(byte) 0x9f, 0x02}, amount);
        data += "amount ret:" + ret + "\ndata:" + Tools.bcd2Str(amount.toByteArray()) + "\n";

        ByteArrayOutputStream tag9F06 = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.TRANSACTION_DATA, new byte[]{(byte) 0x9f, 0x06, 0x4f, 0x5f, 0x28}, tag9F06);
        data += "tag9F06 ret:" + ret + "\ndata:" + Tools.bcd2Str(tag9F06.toByteArray()) + "\n";

        ByteArrayOutputStream tvr = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.TRANSACTION_DATA, new byte[]{(byte) 0x95}, tvr);
        data += "tvr ret:" + ret + "\ndata:" + Tools.bcd2Str(tvr.toByteArray()) + "\n";

        ByteArrayOutputStream tsi = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.TRANSACTION_DATA, new byte[]{(byte) 0x9b}, tsi);
        data += "tsi ret:" + ret + "\ndata:" + Tools.bcd2Str(tsi.toByteArray()) + "\n";

        ByteArrayOutputStream trk1 = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{ 0x03, 0x04}, trk1);
        data += "trk1 ret:" + ret + "\ndata:" + Tools.bcd2Str(trk1.toByteArray()) + "\n";


        ByteArrayOutputStream trk2 = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{ 0x03, 0x05}, trk2);
        data += "trk2 ret:" + ret + "\ndata:" + Tools.bcd2Str(trk2.toByteArray()) + "\n";

        ByteArrayOutputStream pan = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x03, (byte)0x1C}, pan);
        data += "pan ret:" + ret + "\ndata:" + Tools.bcd2Str(pan.toByteArray()) + "\n";

        ByteArrayOutputStream ksn = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x03, (byte)0x17}, ksn);
        data += "ksn ret:" + ret + "\ndata:" + Tools.bcd2Str(ksn.toByteArray()) + "\n";

        ByteArrayOutputStream panMask = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x03, (byte)0x19}, panMask);
        if (panMask != null && panMask.size()>5) {
            byte[] mask = new byte[panMask.size() - 5];
            System.arraycopy(panMask.toByteArray(), 5, mask, 0, panMask.size() - 5);
            data += "panMask ret:" + ret + "\ndata:" + new String(mask) + "\n";
        }

        updateResult("startTransaction result:" + data);
    }

    private void startTransactionWithNoDefaultData() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                int ret = easyLink.startTransaction();
                getDataNoScropt(ret, 0x00);
            }
        }).start();

    }

    private void startTransationSaleAnNoSript(final String amount) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                setSaleData(amount);
                int ret = easyLink.startTransaction();
                getDataNoScropt(ret, 0x00);
            }
        }).start();

    }

    private void startTransationRefundAnNoSript(final String amount) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                setRefundData(amount);
                int ret = easyLink.startTransaction();
                getDataNoScropt(ret, 0x00);
            }
        }).start();

    }

    private void startTransationSaleAndDecline(final String amount) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                setSaleData(amount);
                int ret = easyLink.startTransaction();
                getData(ret, 0x04);
            }
        }).start();
    }

    private void setCashBackData(String amount, String back) {
        Log.d(TAG, "setSaleData amout:" + amount + "len :" + Tools.str2Bcd(amount).length);
        byte[] amountData = new byte[6];
        System.arraycopy(Tools.str2Bcd(amount), 0, amountData, 6 - Tools.str2Bcd(amount).length, Tools.str2Bcd(amount).length);

        byte[] amountBackData = new byte[6];
        System.arraycopy(Tools.str2Bcd(back), 0, amountBackData, 6 - Tools.str2Bcd(back).length, Tools.str2Bcd(back).length);

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");// HH:mm:ss

        Date date = new Date(System.currentTimeMillis());
        Log.d(TAG, "setSaleData date:" + simpleDateFormat.format(date));

        String dataString = "9C01095F360102" +
                "9a03" + simpleDateFormat.format(date).substring(2, 8) +
                "9f2103" + simpleDateFormat.format(date).substring(8, 14) +
                "9f0206" + Tools.bcd2Str(amountData) +
                "9f0306" + Tools.bcd2Str(amountBackData);
        Log.d(TAG, "setCashBackData data:" + dataString);

        byte[] data = Tools.str2Bcd(dataString);

        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        int ret = easyLink.setData(DataType.TRANSACTION_DATA, data, failedTags);
        updateResult("setSaleData setData:" + ret + "\n" + dataString);
    }

    private void cashBackAndApprove(final String amount) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                setCashBackData(amount, "10");
                int ret = easyLink.startTransaction();
                updateResult("cashBackAndApprove startTransaction:" + ret);
            }
        }).start();
    }

    private void startTransaction_report(final String amount) {
        reportWithCancel = false;
        enterPinReportWithCancel = false;
        easyLink.registerReportStatusListener(reportStatusListener);

        new Thread(new Runnable() {
            @Override
            public void run() {
                setSaleData(amount);
                transRet = easyLink.startTransaction();
                Log.d(TAG, "startTransaction_report,transRet: " + transRet);
                updateResult("startTransaction_report:" + transRet);
            }
        }).start();
    }

    private void startTransaction_with_cancel(final String amount) {
        reportWithCancel = true;
        enterPinReportWithCancel = false;
        easyLink.registerReportStatusListener(reportStatusListener);

        new Thread(new Runnable() {
            @Override
            public void run() {
                setSaleData(amount);
                transRet = easyLink.startTransaction();
                Log.d(TAG, "startTransaction_report,transRet: " + transRet);
                updateResult("startTransaction_with_cancel:" + transRet);
            }
        }).start();

    }

    private void startTransaction_Multi_Acq(final String amount) {
        supportSetMultiAcq = true;
        reportWithCancel = false;
        enterPinReportWithCancel = false;
        easyLink.registerReportStatusListener(reportStatusListener);

        new Thread(new Runnable() {
            @Override
            public void run() {
                setSaleData(amount);
                transRet = easyLink.startTransaction();
                Log.d(TAG, "startTransaction_Multi_Acq,transRet: " + transRet);
                updateResult("startTransaction_Multi_Acq:" + transRet);
            }
        }).start();

    }

    private void completeTransationFUN1() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                setCompleteTransData();
                int ret = easyLink.completeTransaction();
                updateResult("completeTransaction:" + ret);
            }
        }).start();

    }

    private void completeTransactionWithReport() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                setCompleteTransData();
                getCompleteTransData(0x03, false);
            }
        }).start();

    }

    private void completeTransactionWithCancel() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                setCompleteTransData();
                getCompleteTransData(0x03, true);
            }
        }).start();
    }

    private void getPinBlock(final String PAN) {

        final ByteArrayOutputStream pinBlock = new ByteArrayOutputStream();
        final ByteArrayOutputStream ksn = new ByteArrayOutputStream();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.w(TAG, "getPinBlock,start ");
                    int ret = easyLink.getPinBlock(PAN, pinBlock, ksn);
                    Log.w(TAG, "getPinBlock,end:ret=" + ret);
                    updateResult("getPinBlock:" + ret + "\npinBlock:" + bcd2Str(pinBlock.toByteArray()) +
                            "\nksn:" + bcd2Str(ksn.toByteArray()));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void getPinBlockWithReport() {
        enterPinReportWithCancel = false;
        easyLink.registerReportStatusListener(reportStatusListener);
        new Thread(new Runnable() {
            @Override
            public void run() {
                String PAN = "6225776765463826";
                ByteArrayOutputStream pinBlock = new ByteArrayOutputStream();
                ByteArrayOutputStream ksn = new ByteArrayOutputStream();
                int ret = easyLink.getPinBlock(PAN, pinBlock, ksn);
                updateResult("getPinBlockWithReport:" + ret + "pinBlock:" + bcd2Str(pinBlock.toByteArray())
                        + "\nksn:" + bcd2Str(ksn.toByteArray()));

            }
        }).start();
    }

    private void getPinBlockWithCancel() {
        enterPinReportWithCancel = true;
        easyLink.registerReportStatusListener(reportStatusListener);
        new Thread(new Runnable() {
            @Override
            public void run() {
                String PAN = "6225776765463826";
                ByteArrayOutputStream pinBlock = new ByteArrayOutputStream();
                ByteArrayOutputStream ksn = new ByteArrayOutputStream();
                int ret = easyLink.getPinBlock(PAN, pinBlock, ksn);
                updateResult("getPinBlockWithCancel:" + ret + "pinBlock:" + bcd2Str(pinBlock.toByteArray())
                        + "\nksn:" + bcd2Str(ksn.toByteArray()));

            }
        }).start();
    }

    private void encryptData(String data) {
        int length = data.length() / 2;
        if (length == 0) {
            return;
        }

        byte[] databy = StringUtils.hexString2Bytes(data, length);

        ByteArrayOutputStream respData = new ByteArrayOutputStream();

        int ret = easyLink.encryptData(databy, respData);

        updateResult("encryptData:" + ret + "\nrespData:" + bcd2Str(respData.toByteArray()));
    }


    private void setTransData(String data) {


        int length = data.length() / 2;
        if (length == 0) {
            return;
        }

        final byte[] databy = StringUtils.hexString2Bytes(data, length);

        final ByteArrayOutputStream failedTags = new ByteArrayOutputStream();

        new Thread(new Runnable() {
            @Override
            public void run() {
                int ret = easyLink.setData(DataType.TRANSACTION_DATA, databy, failedTags);

                updateResult("setData:" + ret + "\nfailedTags:" + bcd2Str(failedTags.toByteArray()));
            }
        }).start();


    }

    private void setConfigData(final String data) {

        final int length = data.length() / 2;
        if (length == 0) {
            return;
        }


        byte[] databy = StringUtils.hexString2Bytes(data, length);
        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        int ret = easyLink.setData(DataType.CONFIGURATION_DATA, databy, failedTags);

        updateResult("setData:" + ret + "\nfailedTags:" + bcd2Str(failedTags.toByteArray()));

    }


    //9F02	TxnAmount	M	N…12	Transaction Amount
    //9C	TransactionType	M	Hex 2	Transaction type
    //5F2A	TxnCurcyCode	M	Hex 4	Transaction Currency Code
    //5F36	TxnCurcyExp	M	Hex 2	Transaction Currency Exponent
    //9A	TxnDate	M	N 6	Transaction Date (YYMMDD)
    //9F21	TxnTime	M	N 6	Transaction Time (hhmmss)

    //FallbackAllowFlag=0
    private void setCompleteTransData() {
        String resp = "0308010003090230300310010003110c910ae344ee82e00ca876303003132a72289F1804AABBCCDD86098424000004AABBCCDD86098418000004AABBCCDD86098416000004AABBCCDD";
        byte[] data = Tools.str2Bcd(resp);
//        byte data[] = {0x03, 0x08, 0x01, 0x00,
//                0x03, 0x09, 0x02, 0x30, 0x30,
//                0x03, 0x11, 0x02, 0x12, 0x34,
//                0x03, 0x13, 0x08, 0x72, 0x02, 0x12, 0x34, 0x72, 0x02, 0x56, 0x78};
        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        int ret = easyLink.setData(DataType.CONFIGURATION_DATA, data, failedTags);
        updateResult("setData:" + ret + "\nfailedTags:" + bcd2Str(failedTags.toByteArray()));
    }


    private void setConfigDataAcitivity(int func) {
        Intent it = new Intent();
        Intent intent = getIntent();
        String mInterface1 = intent.getStringExtra("Interface");
        it.putExtra("Interface", mInterface1);
        it.putExtra("FUNC", func);
        it.setClass(getApplicationContext(), SetConfigParamActivity.class);
        startActivityForResult(it, 0);
    }

    private void setConfigData() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                String stringData = EasyLinkConfigParam.getSleepModeTimeout(getApplicationContext());
                stringData += EasyLinkConfigParam.getEncryptType(getApplicationContext());
                stringData += EasyLinkConfigParam.getPinEncIndex(getApplicationContext());
                stringData += EasyLinkConfigParam.getPinblockMode(getApplicationContext());
                stringData += EasyLinkConfigParam.getDataEncryptTypeMode(getApplicationContext());
                stringData += EasyLinkConfigParam.getDataEncIndex(getApplicationContext());
                stringData += EasyLinkConfigParam.getFallbackAllow(getApplicationContext());
                stringData += EasyLinkConfigParam.getPanMaskStartPos(getApplicationContext());
                stringData += EasyLinkConfigParam.getTransMode(getApplicationContext());
                stringData += EasyLinkConfigParam.getDukptDesModeMode(getApplicationContext());
                stringData += EasyLinkConfigParam.getMacCalcIndex(getApplicationContext());
                //stringData += EasyLinkConfigParam.getLanguage(getApplicationContext());
                stringData += EasyLinkConfigParam.getMacCalcType(getApplicationContext());
                stringData += EasyLinkConfigParam.getMacCalcMode(getApplicationContext());
                stringData += EasyLinkConfigParam.getCardEntryMode(getApplicationContext());
                stringData += EasyLinkConfigParam.getMsrReqPinAuto(getApplicationContext());
                stringData += EasyLinkConfigParam.getSupportReport(getApplicationContext());
                stringData += EasyLinkConfigParam.getEmvRefundNeedAuthorize(getApplicationContext());
                //stringData += EasyLinkConfigParam.getContactlessLightStandard(getApplicationContext());
                //stringData += EasyLinkConfigParam.getReportTimeout(getApplicationContext());

                Log.d(TAG, "setConfigData stringData = " + stringData);

                ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
                int ret = easyLink.setData(DataType.CONFIGURATION_DATA, Tools.str2Bcd(stringData), failedTags);
                updateResult("setData:" + stringData + "\nret:" + ret + "\nfailedTags:" + bcd2Str(failedTags.toByteArray()));
            }
        }).start();

    }

    private void setFixTrans() {

        byte data[] = {(byte) 0x9F, 0x02, 0x06, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00,
                (byte) 0x9C, 0x01, 0x00,
                0x5F, 0x2A, 0x02, 0x00, 0x00,
                0x5F, 0x36, 0x01, 0x01,
                (byte) 0x9A, 0x03, 0x17, 0x12, 0x28,
                (byte) 0x9F, 0x21, 0x03, 0x11, 0x15, 0x59};
        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        int ret = easyLink.setData(DataType.TRANSACTION_DATA, data, failedTags);
        updateResult("setData:" + ret + "\nfailedTags:" + bcd2Str(failedTags.toByteArray()));
    }


    //获取所有默认的参数
    private void getTransData(String data) {

        int length = data.length() / 2;
        if (length == 0) {
            return;
        }
        byte[] databy = StringUtils.hexString2Bytes(data, length);
        ByteArrayOutputStream dataList = new ByteArrayOutputStream();
        int ret = easyLink.getData(DataType.TRANSACTION_DATA, databy, dataList);
        updateResult("getData:" + ret + "\ndataList:" + bcd2Str(dataList.toByteArray()));

    }

    private void getConfigData(String data) {

        int length = data.length() / 2;
        if (length == 0) {
            return;
        }
        byte[] databy = StringUtils.hexString2Bytes(data, length);
        ByteArrayOutputStream dataList = new ByteArrayOutputStream();
        int ret = easyLink.getData(DataType.CONFIGURATION_DATA, databy, dataList);
        updateResult("getData:" + ret + "\ndataList:" + bcd2Str(dataList.toByteArray()));
    }

    private void getAllTermInfo() {
        final List<TLVDataObject> valueList = new ArrayList<>();
        final List<byte[]> termTagList = new ArrayList<>();
        termTagList.add(new byte[]{(byte) 0x01, 0x01});//SN
        termTagList.add(new byte[]{(byte) 0x01, 0x02});//
        termTagList.add(new byte[]{(byte) 0x01, 0x03});
        termTagList.add(new byte[]{(byte) 0x01, 0x04});
        termTagList.add(new byte[]{(byte) 0x01, 0x05});
        termTagList.add(new byte[]{(byte) 0x01, 0x06});
        termTagList.add(new byte[]{(byte) 0x01, 0x07});
        termTagList.add(new byte[]{(byte) 0x01, 0x08});
        termTagList.add(new byte[]{(byte) 0x01, 0x09});
        termTagList.add(new byte[]{(byte) 0x01, 0x10});
        termTagList.add(new byte[]{(byte) 0x01, 0x11});
        termTagList.add(new byte[]{(byte) 0x01, 0x12});//
        termTagList.add(new byte[]{(byte) 0x01, 0x13});
        termTagList.add(new byte[]{(byte) 0x01, 0x14});
        termTagList.add(new byte[]{(byte) 0x01, 0x15});
        termTagList.add(new byte[]{(byte) 0x01, 0x16});
        termTagList.add(new byte[]{(byte) 0x01, 0x17});
        termTagList.add(new byte[]{(byte) 0x01, 0x18});
        termTagList.add(new byte[]{(byte) 0x01, 0x19});
        termTagList.add(new byte[]{(byte) 0x01, 0x20});
        termTagList.add(new byte[]{(byte) 0x01, 0x21});
        termTagList.add(new byte[]{(byte) 0x01, 0x22});//
        termTagList.add(new byte[]{(byte) 0x01, 0x23});
        termTagList.add(new byte[]{(byte) 0x01, 0x24});
        termTagList.add(new byte[]{(byte) 0x01, 0x25});
        termTagList.add(new byte[]{(byte) 0x01, 0x26});
        termTagList.add(new byte[]{(byte) 0x01, 0x27});
        termTagList.add(new byte[]{(byte) 0x01, 0x28});
        termTagList.add(new byte[]{(byte) 0x01, 0x29});
        int ret = easyLink.getData(DataType.CONFIGURATION_DATA, termTagList, valueList);

        StringBuffer result = new StringBuffer("All Terminal Info:");
        for (int i = 0; i < valueList.size(); i++) {
            if (i == 16 || i == 23 || i == 28) {
                result.append("\ntag:" + Tools.bcd2Str(valueList.get(i).getTag()) + ", value:" + Tools.bcd2Str(valueList.get(i).getValue()));

            } else {
                result.append("\ntag:" + Tools.bcd2Str(valueList.get(i).getTag()) + ", value:" + new String(valueList.get(i).getValue()));
            }
        }
        updateResult(result.toString());

    }

    private void getAllConfigData() {
        String result = null;
        ByteArrayOutputStream dataList = new ByteArrayOutputStream();
        int ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x01}, dataList);
        result = "sleepTimeout ret = " + ret + "\ndata:" + Tools.bcd2Str(dataList.toByteArray()) + "\n\n";

        ByteArrayOutputStream pinEncryptType = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x02}, pinEncryptType);
        result += "PinEncryType ret = " + ret + "\ndata:" + Tools.bcd2Str(pinEncryptType.toByteArray()) + "\n\n";

        ByteArrayOutputStream pinEncryptIndex = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x03}, pinEncryptIndex);
        result += "PinEncryIndex ret = " + ret + "\ndata:" + Tools.bcd2Str(pinEncryptIndex.toByteArray()) + "\n\n";

        ByteArrayOutputStream pinBlockMode = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x04}, pinBlockMode);
        result += "pinBlockMode ret = " + ret + "\ndata:" + Tools.bcd2Str(pinBlockMode.toByteArray()) + "\n\n";

        ByteArrayOutputStream DataEncryptionType = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x05}, DataEncryptionType);
        result += "DataEncryptionType ret = " + ret + "\ndata:" + Tools.bcd2Str(DataEncryptionType.toByteArray()) + "\n\n";

        ByteArrayOutputStream DataEncryptionKeyIdx = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x06}, DataEncryptionKeyIdx);
        result += "DataEncryptionKeyIdx ret = " + ret + "\ndata:" + Tools.bcd2Str(DataEncryptionKeyIdx.toByteArray()) + "\n\n";

        ByteArrayOutputStream FallbackAllowFlag = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x07}, FallbackAllowFlag);
        result += "FallbackAllowFlag ret = " + ret + "\ndata:" + Tools.bcd2Str(FallbackAllowFlag.toByteArray()) + "\n\n";

        ByteArrayOutputStream PANMaskStartPos = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x08}, PANMaskStartPos);
        result += "PANMaskStartPos ret = " + ret + "\ndata:" + Tools.bcd2Str(PANMaskStartPos.toByteArray()) + "\n\n";

        ByteArrayOutputStream TransMode = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x09}, TransMode);
        result += "TransMode ret = " + ret + "\ndata:" + Tools.bcd2Str(TransMode.toByteArray()) + "\n\n";

        ByteArrayOutputStream DukptDesMode = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x0A}, DukptDesMode);
        result += "DukptDesMode ret = " + ret + "\ndata:" + Tools.bcd2Str(DukptDesMode.toByteArray()) + "\n\n";

        ByteArrayOutputStream macKeyIndex = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x10}, macKeyIndex);
        result += "macKeyIndex ret = " + ret + "\ndata:" + Tools.bcd2Str(macKeyIndex.toByteArray()) + "\n\n";

        ByteArrayOutputStream MacCalcType = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x12}, MacCalcType);
        result += "MacCalcType ret = " + ret + "\ndata:" + Tools.bcd2Str(MacCalcType.toByteArray()) + "\n\n";

        ByteArrayOutputStream MacCalcMode = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x13}, MacCalcMode);
        result += "MacCalcMode ret = " + ret + "\ndata:" + Tools.bcd2Str(MacCalcMode.toByteArray()) + "\n\n";

        ByteArrayOutputStream CardEntryMode = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x14}, CardEntryMode);
        result += "CardEntryMode ret = " + ret + "\ndata:" + Tools.bcd2Str(CardEntryMode.toByteArray()) + "\n\n";

        ByteArrayOutputStream MsrRequestPINAuto = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x15}, MsrRequestPINAuto);
        result += "MsrRequestPINAuto ret = " + ret + "\ndata:" + Tools.bcd2Str(MsrRequestPINAuto.toByteArray()) + "\n\n";

        ByteArrayOutputStream SupportReport = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x16}, SupportReport);
        result += "SupportReport ret = " + ret + "\ndata:" + Tools.bcd2Str(SupportReport.toByteArray()) + "\n\n";

        updateResult("getAllConfigData:" + result);
    }

    private void showPage(final String pageName) {
        Log.d(TAG, "showPage: pageName:" + pageName);
        final ArrayList<ShowPageInfo> showMsgInfo = new ArrayList<ShowPageInfo>();
        new Thread(new Runnable() {
            @Override
            public void run() {
                UIRespInfo uiRespInfo = new UIRespInfo();
                int ret = easyLink.showPage(pageName, 50, showMsgInfo, uiRespInfo);
                updateResult("showPage:" + ret + "\nUIName:" + uiRespInfo.getType() + "\nUIData:" + bcd2Str(uiRespInfo.getActionData()));
            }
        }).start();

    }

    private void showBarcodePage(final String barcodeStr) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                ShowPageInfo msgInfo1 = new ShowPageInfo("barcode", barcodeStr);
                ArrayList<ShowPageInfo> showMsgInfo = new ArrayList<ShowPageInfo>();
                showMsgInfo.add(msgInfo1);
                UIRespInfo uiRespInfo = new UIRespInfo();
                int ret = easyLink.showPage("pageBarcode.xml", 60, showMsgInfo, uiRespInfo);
                updateResult("showBarcodePage:" + ret + "\nUIName:" + uiRespInfo.getType() + "\nUIData:" + bcd2Str(uiRespInfo.getActionData()));
            }
        }).start();

    }
    private void showSignaturePage() {
        final ArrayList<ShowPageInfo> showMsgInfo = new ArrayList<ShowPageInfo>();
        new Thread(new Runnable() {
            @Override
            public void run() {
                UIRespInfo uiRespInfo = new UIRespInfo();
                int ret = easyLink.showPage("pageSignature.xml", 50, showMsgInfo, uiRespInfo);
                if (uiRespInfo.getActionData() != null) {
                    updateResult("showSignaturePage:" + ret + "\nUIName:" + uiRespInfo.getType());
                    Message msg = new Message();
                    msg.what = SHOW_SIGNATURE_VIEW;
                    Bundle bundle = new Bundle();
                    bundle.putByteArray("signData", uiRespInfo.getActionData());
                    msg.setData(bundle);
                    handler.sendMessage(msg);

                } else {
                    updateResult("showSignaturePage:" + ret + "\nUIName:" + uiRespInfo.getType() + "\nUIData:" + uiRespInfo.getActionData());
                }
            }
        }).start();

    }


    private void fileDownLoad(final String name) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Context context = EasyLinkActivity.this;
                String filePath = context.getFilesDir().getPath() + "/app/" + name;
                Tools.mkDir(context.getFilesDir().getPath() + "/app/");
                Tools.copyFileFromAssert(context, name, filePath);
                int ret = easyLink.fileDownLoad(filePath, new CustomFileDownloadListener());
                updateResult("fileDownLoad:" + ret);
            }
        }).start();

    }

    //ui
    private void downloadD180UI() {
        Context context = EasyLinkActivity.this;
        String filePath = context.getFilesDir().getPath() + "/app/" + "ui_xml_demo.ui";
        Tools.mkDir(context.getFilesDir().getPath() + "/app/");
        Tools.copyFileFromAssert(context, "ui_d180.ui", filePath);
        int ret = easyLink.fileDownLoad(filePath, new CustomFileDownloadListener());
        updateResult("fileDownLoad:" + ret);
    }

    //bin  57.40
    private void downloadEasylinkBin() {

        Context context = EasyLinkActivity.this;
        String filePath = context.getFilesDir().getPath() + "/app/" + "EASYLINK_LITE(v1.04.00W).bin";
        Tools.mkDir(context.getFilesDir().getPath() + "/app/");
        Tools.copyFileFromAssert(context, "EASYLINK_LITE(v1.04.00W).bin", filePath);
        int ret = easyLink.fileDownLoad(filePath, new CustomFileDownloadListener());
        updateResult("fileDownLoad:" + ret);

    }

    //bmp  12.40
    private void downloadBmp() {


        Context context = EasyLinkActivity.this;
        String filePath = context.getFilesDir().getPath() + "/app/" + "bmp1.bmp";
        Tools.mkDir(context.getFilesDir().getPath() + "/app/");
        Tools.copyFileFromAssert(context, "bmp1.bmp", filePath);
        int ret = easyLink.fileDownLoad(filePath, new CustomFileDownloadListener());
        updateResult("fileDownLoad:" + ret);
    }

    //clss  13.40 14.50
    private void downloadClssParam() {

        Context context = EasyLinkActivity.this;
        String filePath = context.getFilesDir().getPath() + "/app/" + "clss_param.clss";
        Tools.mkDir(filePath);
        Tools.copyFileFromAssert(context, "clss_param.clss", filePath);
//        int ret = easyLink.fileDownLoad(filePath, new CustomFileDownloadListener());
        int ret = easyLink.fileDownLoad("clss_param.clss",filePath, new CustomFileDownloadListener());
        updateResult("fileDownLoad:" + ret);
    }

    //emv 15.05
    private void downloadEmvParam() {


        Context context = EasyLinkActivity.this;
        String filePath = context.getFilesDir().getPath() + "/app/" + "emv_param.emv";
        Tools.mkDir(context.getFilesDir().getPath() + "/app/");
        Tools.copyFileFromAssert(context, "emv_param.emv", filePath);
        int ret = easyLink.fileDownLoad(filePath, new CustomFileDownloadListener());
        updateResult("fileDownLoad:" + ret);
    }

    //font
    private void downloadFontFile() {


        Context context = EasyLinkActivity.this;
        String filePath = context.getFilesDir().getPath() + "/app/" + "FONT_EUR_INT_01.font";
        Tools.mkDir(context.getFilesDir().getPath() + "/app/");
        Tools.copyFileFromAssert(context, "FONT_EUR_INT_01.font", filePath);
        int ret = easyLink.fileDownLoad(filePath, new CustomFileDownloadListener());
        updateResult("fileDownLoad:" + ret);
    }

    //monitor  57.40
    private void downloadMonitorFile() {

        Context context = EasyLinkActivity.this;
        String filePath = context.getFilesDir().getPath() + "/app/" + "D135_Monitor_Debug_20200114(V1.01)_SIG.monitor";
        Tools.mkDir(context.getFilesDir().getPath() + "/app/");
        Tools.copyFileFromAssert(context, "D135_Monitor_Debug_20200114(V1.01)_SIG.monitor", filePath);
        int ret = easyLink.fileDownLoad(filePath, new CustomFileDownloadListener());
        updateResult("fileDownLoad:" + ret);
    }


    private void switchCommModeFUN1(String type) {

        int intype = Integer.parseInt(type);
        if (intype == 0) {
            int ret = easyLink.switchCommMode(ProtocolType.MULTI_FRAMEP_ROTOCOL);
            updateResult("switchCommMode:" + ret);
        } else if (intype == 1) {
            int ret = easyLink.switchCommMode(ProtocolType.SIMPLE_WITH_MULTI_FRAME_PROTOCOL);
            updateResult("switchCommMode:" + ret);
        }
    }


    private void EMVFUN1(String tagStr) {

        //接触式
        byte emvdata[] = {(byte) 0x9c, 0x01, 0x00, 0x5f, 0x2a, 0x02, 0x01, 0x24, 0x5f, 0x36, 0x01, 0x02, (byte) 0x9a, 0x03, 0x16, 0x10, 0x02, (byte) 0x9f, 0x21, 0x03, 0x05, 0x50, 0x59};

        //输入金额9F02
        //0.01  10.00:  10.00:(9F0206000000001000)     9999.01   9F0206000000999901


        //startTransaction

        //getData 9F27:80（走联机，setData设置参数，然后调用complete） 	40（脱机，交易结束）


        //

        int length = tagStr.length() / 2;
        if (length == 0) {
            return;
        }

        int emvdataLen = emvdata.length;

        byte[] emvamout = StringUtils.hexString2Bytes(tagStr, length);

        byte[] data = new byte[emvdataLen + 9];
        System.arraycopy(emvdata, 0, data, 0, emvdataLen);
        System.arraycopy(emvamout, 0, data, emvdataLen, 9);

        //set amount and other parameter
        int ret = 0;

        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        ret = easyLink.setData(DataType.TRANSACTION_DATA, data, failedTags);
        updateResult("setData:" + ret + "\nfailedTags:" + bcd2Str(failedTags.toByteArray()));
        //9F030600000000000010
//				byte[] datat = {(byte)0x9F,0x03,0x06,0x00,0x00,0x00,0x0,0x50,0x00};
//				easyLink.setData(1, datat, new mySetDataListener());
        //set 91 8A
        byte[] NSMutableData = {(byte) 0x91, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, (byte) 0x8A, 0x02, 0x30, 0x30, (byte) 0x89, 0x06, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36};


        ByteArrayOutputStream failedTags1 = new ByteArrayOutputStream();
        ret = easyLink.setData(DataType.TRANSACTION_DATA, NSMutableData, failedTags1);

        updateResult("setData:" + ret + "\nfailedTags:" + bcd2Str(failedTags1.toByteArray()));


        byte[] data2 = {0x03, 0x08, 0x01, 0x00};
        ByteArrayOutputStream failedTags2 = new ByteArrayOutputStream();
        ret = easyLink.setData(DataType.CONFIGURATION_DATA, data2, failedTags2);

        updateResult("setData:" + ret + "\nfailedTags:" + bcd2Str(failedTags2.toByteArray()));

        // start transaction
        ret = easyLink.startTransaction();
        updateResult("startTransaction:" + ret);


        if (!startTransactionStatue.equals("TransStart succ")) {

            updateResult(startTransactionStatue);
            return;
        }

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


        //get 9F27
        byte[] emvgetData = {(byte) 0x9F, 0x27};

        ByteArrayOutputStream dataList = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.TRANSACTION_DATA, emvgetData, dataList);
        updateResult("getData:" + ret + "\ndataList:" + bcd2Str(dataList.toByteArray()));
        byte statuedata = emvpa[5];

        // Judge online or offline
        if (statuedata == -128)//联机
        {
            ret = easyLink.completeTransaction();
            updateResult("completeTransaction:" + ret);
        } else if (statuedata == 64)//脱机
        {
            progressDialog.dismiss();
        } else {
            updateResult("getData:" + ret + "\ndataList" + bcd2Str(dataList.toByteArray()));
        }

    }

    private void EMVFUN2(String tagStr) {

        //接触式
        byte emvdata[] = {(byte) 0x9c, 0x01, 0x00, 0x5f, 0x2a, 0x02, 0x01, 0x24, 0x5f, 0x36, 0x01, 0x02, (byte) 0x9a, 0x03, 0x16, 0x10, 0x02, (byte) 0x9f, 0x21, 0x03, 0x05, 0x50, 0x59};

        byte setDataother[] = {0x71, 0x0F, (byte) 0x9F, 0x18, 0x04, 0x11, 0x22, 0x33, 0x44, (byte) 0x86, 0x06, (byte) 0x84, 0x24, 0x00, 0x00, 0x00, 0X00, 0x72, 0x0F, (byte) 0x9F, 0x18, 0x04, 0x11, (byte) 0x22, 0x33, 0x44, (byte) 0x86, 0x06, (byte) 0x84, 0x24, 0x00, 0x00, 0x00, 0x00};


        int length = tagStr.length() / 2;
        if (length == 0) {
            return;
        }

        int emvdataLen = emvdata.length;

        byte[] emvamout = StringUtils.hexString2Bytes(tagStr, length);

        byte[] data = new byte[emvdataLen + 9];
        System.arraycopy(emvdata, 0, data, 0, emvdataLen);
        System.arraycopy(emvamout, 0, data, emvdataLen, 9);

        //set amount and other parameter
        int ret = 0;

        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        ret = easyLink.setData(DataType.TRANSACTION_DATA, data, failedTags);
        updateResult("setData:" + ret + "\nfailedTags:" + bcd2Str(failedTags.toByteArray()));

        ByteArrayOutputStream failedTags2 = new ByteArrayOutputStream();
        ret = easyLink.setData(DataType.TRANSACTION_DATA, setDataother, failedTags2);
        updateResult("setData:" + ret + "\nfailedTags:" + bcd2Str(failedTags2.toByteArray()));


        // start transaction
        ret = easyLink.startTransaction();
        updateResult("startTransaction:" + ret);


        if (!startTransactionStatue.equals("TransStart succ")) {

            updateResult(startTransactionStatue);
            return;
        }

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


        //get 9F27
        byte[] emvgetData = {(byte) 0x9F, 0x27};
        ByteArrayOutputStream dataList = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.TRANSACTION_DATA, emvgetData, dataList);
        updateResult("getData:" + ret + "\ndataList:" + bcd2Str(dataList.toByteArray()));


        byte statuedata = emvpa[5];


        // Judge online or offline
        if (statuedata == -128)//联机
        {
            ret = easyLink.completeTransaction();
            updateResult("completeTransaction:" + ret);
        } else if (statuedata == 64)//脱机
        {
            progressDialog.dismiss();
        } else {
            updateResult("getData:" + ret + "\ndataList" + bcd2Str(dataList.toByteArray()));
        }

    }

    //非接

    private void EMVFUN3(String tagStr) {

        int length = tagStr.length() / 2;
        if (length == 0) {
            return;
        }

        byte[] emvamout = StringUtils.hexString2Bytes(tagStr, length);

        //set amount and other parameter

        int ret = 0;
        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        ret = easyLink.setData(DataType.TRANSACTION_DATA, emvamout, failedTags);
        updateResult("setData:" + ret + "\nfailedTags:" + bcd2Str(failedTags.toByteArray()));

        //接触式
        byte emvdata[] = {(byte) 0x9c, 0x01, 0x00, 0x5f, 0x2a, 0x02, 0x01, 0x24, 0x5f, 0x36, 0x01, 0x02, (byte) 0x9a, 0x03, 0x16, 0x10, 0x02, (byte) 0x9f, 0x21, 0x03, 0x05, 0x50, 0x59};

        //输入金额9F02
        //0.01  10.00:  10.00:(9F0206000000001000)     9999.01   9F0206000000999901


        //startTransaction

        //getData 9F27:80（走联机，setData设置参数，然后调用complete） 	40（脱机，交易结束）


        //


        //set amount and other parameter
        ByteArrayOutputStream failedTags2 = new ByteArrayOutputStream();
        ret = easyLink.setData(DataType.TRANSACTION_DATA, emvdata, failedTags2);
        updateResult("setData:" + ret + "\nfailedTags:" + bcd2Str(failedTags2.toByteArray()));
        //9F030600000000000010
//				byte[] datat = {(byte)0x9F,0x03,0x06,0x00,0x00,0x00,0x0,0x50,0x00};
//				easyLink.setData(1, datat, new mySetDataListener());
        //set 91 8A
        byte[] NSMutableData = {(byte) 0x91, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, (byte) 0x8A, 0x02, 0x30, 0x30, (byte) 0x89, 0x06, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36};

        ByteArrayOutputStream failedTags3 = new ByteArrayOutputStream();
        ret = easyLink.setData(DataType.TRANSACTION_DATA, NSMutableData, failedTags3);
        updateResult("setData:" + ret + "\nfailedTags:" + bcd2Str(failedTags3.toByteArray()));


        byte[] data11 = {0x03, 0x08, 0x01, 0x00};
        ByteArrayOutputStream failedTags4 = new ByteArrayOutputStream();
        easyLink.setData(DataType.CONFIGURATION_DATA, data11, failedTags4);
        updateResult("setData:" + ret + "\nfailedTags:" + bcd2Str(failedTags4.toByteArray()));
        // start transaction
        ret = easyLink.startTransaction();
        updateResult("startTransaction:" + ret);


        if (!startTransactionStatue.equals("TransStart succ")) {

            updateResult(startTransactionStatue);
            return;
        }

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        //031A的判断
        byte[] HolderVerificationData = {0x03, 0x1A};
        ByteArrayOutputStream dataList = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, HolderVerificationData, dataList);
        updateResult("getData:" + ret + "\ndataList:" + bcd2Str(dataList.toByteArray()));

        byte HolderVerificationstatue = emvpa[5];
        if (HolderVerificationstatue == 2) {
            ByteArrayOutputStream pinBlock = new ByteArrayOutputStream();
            ByteArrayOutputStream ksn = new ByteArrayOutputStream();
            ret = easyLink.getPinBlock("", pinBlock, ksn);
            updateResult("getPinBlock:" + "\npinBlock:" + bcd2Str(pinBlock.toByteArray())
                    + "\nksn" + bcd2Str(ksn.toByteArray()));
        }


        //get 9F27
        byte[] emvgetData = {(byte) 0x9F, 0x27};
        ByteArrayOutputStream dataList2 = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.TRANSACTION_DATA, emvgetData, dataList2);
        updateResult("getData:" + ret + "\ndataList:" + bcd2Str(dataList2.toByteArray()));
        byte statuedata = 0;
        if (emvpa.length > 4) {
            statuedata = emvpa[5];
        }

        // Judge online or offline
        if (statuedata == -128)//联机
        {
            ret = easyLink.completeTransaction();
            updateResult("completeTransaction:" + ret);
        } else if (statuedata == 64)//脱机
        {
            progressDialog.dismiss();
        } else {
            updateResult("getData:" + ret + "\ndataList" + bcd2Str(dataList2.toByteArray()));
        }

    }

    //退货
    private void EMVFUN4() {

        //接触式
        byte emvdata[] = {(byte) 0x9c, 0x01, 0x20, 0x5f, 0x2a, 0x02, 0x01, 0x24, 0x5f, 0x36, 0x01, 0x02, (byte) 0x9a, 0x03, 0x16, 0x10, 0x02, (byte) 0x9f, 0x21, 0x03, 0x05, 0x50, 0x59};

        //输入金额9F02
        //0.01  10.00:  10.00:(9F0206000000001000)     9999.01   9F0206000000999901


        //startTransaction

        //getData 9F27:80（走联机，setData设置参数，然后调用complete） 	40（脱机，交易结束）


        //set amount and other parameter
        int ret = 0;
        ByteArrayOutputStream failedTags = new ByteArrayOutputStream();
        ret = easyLink.setData(DataType.TRANSACTION_DATA, emvdata, failedTags);
        updateResult("setData:" + ret + "\nfailedTags:" + bcd2Str(failedTags.toByteArray()));

        //9F030600000000000010
//				byte[] datat = {(byte)0x9F,0x03,0x06,0x00,0x00,0x00,0x0,0x50,0x00};
//				easyLink.setData(1, datat, new mySetDataListener());
        //set 91 8A
        byte[] NSMutableData = {(byte) 0x91, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, (byte) 0x8A, 0x02, 0x30, 0x30, (byte) 0x89, 0x06, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36};

        ByteArrayOutputStream failedTags2 = new ByteArrayOutputStream();
        ret = easyLink.setData(DataType.TRANSACTION_DATA, NSMutableData, failedTags2);
        updateResult("setData:" + ret + "\nfailedTags:" + bcd2Str(failedTags2.toByteArray()));

        ByteArrayOutputStream failedTags3 = new ByteArrayOutputStream();
        byte[] data11 = {0x03, 0x08, 0x01, 0x00};
        ret = easyLink.setData(DataType.CONFIGURATION_DATA, data11, failedTags3);
        updateResult("setData:" + ret + "\nfailedTags:" + bcd2Str(failedTags3.toByteArray()));
        // start transaction
        ret = easyLink.startTransaction();
        updateResult("startTransaction:" + ret);


        if (!startTransactionStatue.equals("TransStart succ")) {

            updateResult(startTransactionStatue);
            return;
        }

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        //031A的判断
        byte[] HolderVerificationData = {0x03, 0x1A};
        ByteArrayOutputStream dataList = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.CONFIGURATION_DATA, HolderVerificationData, dataList);
        updateResult("getData:" + ret + "\ndataList:" + bcd2Str(dataList.toByteArray()));
        byte HolderVerificationstatue = emvpa[5];
        if (HolderVerificationstatue == 2) {
            ByteArrayOutputStream pinBlock = new ByteArrayOutputStream();
            ByteArrayOutputStream ksn = new ByteArrayOutputStream();
            ret = easyLink.getPinBlock("", pinBlock, ksn);
            updateResult("getPinBlock:" + "\npinBlock:" + bcd2Str(pinBlock.toByteArray())
                    + "\nksn" + bcd2Str(ksn.toByteArray()));
        }


        //get 9F27
        byte[] emvgetData = {(byte) 0x9F, 0x27};

        ByteArrayOutputStream dataList2 = new ByteArrayOutputStream();
        ret = easyLink.getData(DataType.TRANSACTION_DATA, emvgetData, dataList2);
        updateResult("getData:" + ret + "\ndataList:" + bcd2Str(dataList2.toByteArray()));
        progressDialog.dismiss();
        updateResult("getData:" + ret + "\ndataList" + bcd2Str(dataList2.toByteArray()));

        byte statuedata = emvpa[5];


        // Judge online or offline
        if (statuedata == -128)//联机
        {
            ret = easyLink.completeTransaction();
            updateResult("completeTransaction:" + ret);

        } else if (statuedata == 64)//脱机
        {
            progressDialog.dismiss();
        } else {
            updateResult("getData:" + ret + "\ndataList" + bcd2Str(dataList2.toByteArray()));
        }

    }


    private void updateResult(String result) {
        Message msg = new Message();
        msg.what = 1;
        Bundle data = new Bundle();
        data.putString("result", result);
        msg.setData(data);
        handler.sendMessage(msg);
    }

    private void updateSetParamResult(int timeout) {
        Message msg = new Message();
        msg.what = MSG_SET_PARAM_RSP;
        msg.arg1 = timeout;
        handler.sendMessage(msg);
    }

    private void updateResultWithWhat(ArrayList<String> appList, ArrayList<String> aidList,int timeout, String prompts, int what) {
        Message msg = new Message();
        msg.what = what;
        Bundle data = new Bundle();
        data.putStringArrayList("appList", appList);
        data.putStringArrayList("aidList", aidList);
        data.putInt("timeout", timeout);
        data.putString("prompts", prompts);
        msg.setData(data);
        handler.sendMessage(msg);
    }

    private void updatePromptAllowCancel() {
        Message msg = new Message();
        msg.what = SEND_CANCEL;
        handler.sendMessage(msg);
    }

    public String bcd2Str(byte[] bytes) {
        if (bytes == null) {
            return "";
        }
        char temp[] = new char[bytes.length * 2], val;

        for (int i = 0; i < bytes.length; i++) {
            val = (char) (((bytes[i] & 0xf0) >> 4) & 0x0f);
            temp[i * 2] = (char) (val > 9 ? val + 'A' - 10 : val + '0');

            val = (char) (bytes[i] & 0x0f);
            temp[i * 2 + 1] = (char) (val > 9 ? val + 'A' - 10 : val + '0');
        }
        return new String(temp);
    }

    public String bcd2Str(byte[] bytes, int offset, int len) {
        if (bytes == null) {
            return "";
        }
        char temp[] = new char[len* 2], val;

        for (int i = offset; i < (offset+len); i++) {
            val = (char) (((bytes[i] & 0xf0) >> 4) & 0x0f);
            temp[(i-offset) * 2] = (char) (val > 9 ? val + 'A' - 10 : val + '0');

            val = (char) (bytes[i] & 0x0f);
            temp[(i-offset) * 2 + 1] = (char) (val > 9 ? val + 'A' - 10 : val + '0');
        }
        return new String(temp);
    }

    private void cancelFileDownload() {
        iscancelfiledownload = true;
        progressDialog.dismiss();
        updateResult("iscancelfiledownload:" + iscancelfiledownload);
    }

    private void testCalcMac(String data) {
        int length = data.length() / 2;
        if (length == 0) {
            return;
        }

        byte[] databy = StringUtils.hexString2Bytes(data, length);

        ByteArrayOutputStream mac = new ByteArrayOutputStream();
        int ret = easyLink.calcMAC(databy, mac);
        updateResult("calcMac ret:" + ret + "\ncalcMac:" + bcd2Str(mac.toByteArray()));
    }

    private void testIncreaseKsn(String groupIndexStr) {
        int groupIndex = Integer.parseInt(groupIndexStr);
        int ret = easyLink.increaseKSN((byte) groupIndex);
        updateResult("IncreaseKSN ret:" + ret);
    }

    private void testGetKeyInfo(String keyType) {
        if (keyType.length() != 2) {
            return;
        }

        byte[] bKeyType = StringUtils.hexString2Bytes(keyType, 1);
        int maxGroupIndex;
        if (KeyType.PED_TLK == bKeyType[0]){
            maxGroupIndex = 1;
        }else if (KeyType.PED_TIK == bKeyType[0]){
            maxGroupIndex = 40;
        }else
            maxGroupIndex = 99;

        StringBuffer result = new StringBuffer();
        result.append("KeyIndex   Kcv         KSN:\n");
        for(int i=1; i<(maxGroupIndex+1); i++) {
            ByteArrayOutputStream keyInfo = new ByteArrayOutputStream();
            int ret = easyLink.getKeyInfo(bKeyType[0], (byte) i, keyInfo);
            if ((ret == ResponseCode.EL_RET_OK) && (keyInfo != null) && (keyInfo.size()>0)) {
                byte[] keyInfoData = keyInfo.toByteArray();
                result.append(" "+ i + "      " + bcd2Str(keyInfoData, 1, 4) + "  " + bcd2Str(keyInfoData, 5, 10) + "\n");
            }
        }
        updateResult(result.toString());
    }

    private void startSelectFileActivity() {

        if (mInterface.equals("DownLoadExtFile")) {
            Intent intent = new Intent(EasyLinkActivity.this, SelectFileActivity.class);
            if (mNo.equals("1")) {
                intent.putExtra("platform", "Server");
            } else if (mNo.equals("2")) {
                intent.putExtra("platform", "Full");

            } else if (mNo.equals("3")) {
                intent.putExtra("platform", "Lite");
            }
            startActivity(intent);
        }
    }

    private void showAllowCancelDlg() {
        if (EasyLinkActivity.this.isFinishing()) {
            return;
        }
        if (allowCancelDlg == null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(EasyLinkActivity.this);
            builder.setIcon(android.R.drawable.ic_dialog_alert);
            builder.setTitle("Cancel?");
            builder.setNegativeButton("No", null);
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            int cancelRet = easyLink.sendCancel();
                            Log.w("TAG", "sendCancelRet=" + cancelRet);
//                            updateResult("send Cancel ret="+cancelRet);
                        }
                    }).start();
                }
            });
            builder.setCancelable(false);
            allowCancelDlg = builder.create();
        }

        if (!EasyLinkActivity.this.isFinishing() && !allowCancelDlg.isShowing()) {
            allowCancelDlg.show();
        }
    }

    private void showSetRspParamDlg(int timeout) {
        if (EasyLinkActivity.this.isFinishing()) {
            return;
        }
        if (setRspParamDlg == null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(EasyLinkActivity.this);
            builder.setIcon(android.R.drawable.ic_dialog_alert);
            builder.setTitle("Pls set key info(TLV)");
            final EditText edit = new EditText(this);
            edit.setText("020201010203010102040100");
            builder.setView(edit);
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    setRspParamStr = null;
                    setParamRspCV.open();
                }
            });
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    setRspParamStr = edit.getText().toString();
                    setParamRspCV.open();
                }
            });
            builder.setCancelable(false);
            setRspParamDlg = builder.create();
        }

        if (!EasyLinkActivity.this.isFinishing() && !setRspParamDlg.isShowing()) {
            setRspParamDlg.show();
            handler.sendEmptyMessageDelayed(MSG_SET_PARAM_RSP_TIMEOUT, timeout * 1000);
        }
    }

    private void showSetEmvAIDParamPage(Bundle bundle, int what) {
        if (EasyLinkActivity.this.isFinishing()) {
            return;
        }
        Log.w(TAG, "showSetEmvAIDParamPage: ");
        Intent toShowParamPage = new Intent(EasyLinkActivity.this, ShowParamActivity.class);
        toShowParamPage.putExtras(bundle);
        EasyLinkActivity.this.startActivityForResult(toShowParamPage, 2);
        int timeout = bundle.getInt("timeout");
        handler.sendEmptyMessageDelayed(what, ((timeout + 1) * 1000));

    }

    private void showReadCardOKStatusParamPage(Bundle bundle) {
        if (EasyLinkActivity.this.isFinishing()) {
            return;
        }
        Log.w(TAG, "showReadCardOKStatusParamPage: ");
        Intent toShowParamPage = new Intent(EasyLinkActivity.this, ReadCardOKParamActivity.class);
        toShowParamPage.putExtras(bundle);
        EasyLinkActivity.this.startActivityForResult(toShowParamPage, 3);
        int timeout = bundle.getInt("timeout");
        handler.sendEmptyMessageDelayed(MSG_RUN_CMD_READ_CARD_OK_PARAM_RSP_TIMEOUT, (timeout + 1) * 1000);

    }

    private void showAppSelect(String prompts, int timeout, ArrayList<String> appList, ArrayList<String> aidList) {
        if (EasyLinkActivity.this.isFinishing()) {
            return;
        }
        if (appSelectDlg == null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(EasyLinkActivity.this);
            builder.setTitle(prompts);
            //    指定下拉列表的显示数据
            final String[] app = new String[appList.size()];
            for (int i=0; i<appList.size(); i++){
                app[i] = aidList.get(i) + "-" + appList.get(i);
            }
            //final String[] aid = aidList.toArray(new String[aidList.size()]);
            //    设置一个下拉的列表选择项
//        builder.setItems(cities, new DialogInterface.OnClickListener()
            selectAppLabel = new ArrayList<>();
            builder.setMultiChoiceItems(app, null, new DialogInterface.OnMultiChoiceClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which, boolean isChecked) {
//                Toast.makeText(EasyLinkActivity.this, "Select：" + app[which], Toast.LENGTH_SHORT).show();
                    if (isChecked) {
                        selectAppLabel.add(appList.get(which));
                        selectAppIndex.add(which);
                    }

                }
            });
            builder.setPositiveButton("confirm", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    appSelectCv.open();
                    appSelectDlg.dismiss();
                    handler.removeMessages(SELECT_APP_TIMEOUT);
                }
            });
            builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    userCancel = true;
                    appSelectCv.open();
                    appSelectDlg.dismiss();
                    handler.removeMessages(SELECT_APP_TIMEOUT);

                }
            });
            appSelectDlg = builder.create();
        }

        if (!EasyLinkActivity.this.isFinishing() && !appSelectDlg.isShowing()) {
            appSelectDlg.show();
            handler.sendEmptyMessageDelayed(SELECT_APP_TIMEOUT, timeout * 1000);
        }
    }

    class CustomFileDownloadListener implements FileDownloadListener {

        public void onDisplayStatus(int current, int total) {
            progressDialog.dismiss();
            updateResult("process:" + current + "/" + total);
        }

        @Override
        public boolean cancelDownload() {
            // TODO Auto-generated method stub
            return iscancelfiledownload;
        }
    }

}
