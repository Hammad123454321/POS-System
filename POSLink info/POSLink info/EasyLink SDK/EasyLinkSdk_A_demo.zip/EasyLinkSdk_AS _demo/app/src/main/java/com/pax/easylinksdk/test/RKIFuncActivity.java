package com.pax.easylinksdk.test;

import android.content.Context;
import android.os.Bundle;
import android.os.Debug;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.pax.easylinksdk.test.utils.Tools;
import com.paxsz.easylink.api.EasyLinkSdkManager;
import com.paxsz.easylink.api.ResponseCode;
import com.paxsz.easylink.listener.DisplayTag;
import com.paxsz.easylink.listener.IRKIStatusListener;
import com.paxsz.easylink.model.KeyType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class RKIFuncActivity extends AppCompatActivity implements IRKIStatusListener, View.OnClickListener {
    private static String TAG = "RKIFuncActivity";
    private static final int NORMALSTATUS = 1;
    private static final int CERTLISTSTATUS = 2;
    private EditText etHostIP;
    private EditText etHostPort;
    private TextView tvResult;
    private Button btDownloadKey;
    private Button btUnBind;
    private Button btInjectOfflKey;
    private Button btInGetCertList;

    private EasyLinkSdkManager easyLink;
    private Handler mayHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case NORMALSTATUS:
                    tvResult.requestFocus();
                    try {
                        Bundle bundle = msg.getData();
                        if (bundle.containsKey("statusMsg")) {
                            String resultJson = bundle.getString("statusMsg");
                            JSONObject jsonObject = new JSONObject(resultJson);
                            String result = jsonObject.getString(DisplayTag.STATUS_MESSAGE);
                            if (!TextUtils.isEmpty(result)){
                                tvResult.setGravity(Gravity.CENTER);
                                tvResult.setText(result);
                            }
                        }else if (bundle.containsKey("certList")){
                            String result = bundle.getString("certList");
                            JSONObject jsonObject = new JSONObject(result);
                            JSONArray jsonArray = jsonObject.getJSONArray(DisplayTag.CERT_LIST);
                            StringBuilder messageBuider = new StringBuilder();
                            if (jsonArray != null) {
                                for (int i= 0; i< jsonArray.length(); i++ ) {
                                    JSONObject obj = jsonArray.getJSONObject(i);
                                    String displayMsg = null;
                                    String certType = obj.getString(DisplayTag.CERT_TYPE);
                                    String status = obj.getString(DisplayTag.STATUS_MESSAGE);
                                    if ("OK".equals(status)){
                                        String version = obj.getString(DisplayTag.VERSION);
                                        String sn = obj.getString(DisplayTag.SN);
                                        String startDate = obj.getString(DisplayTag.START_DATE);
                                        String endDate = obj.getString(DisplayTag.EXPIRY);
                                        String issueName = obj.getString(DisplayTag.ISSUE_NAME);
                                        String subjectName = obj.getString(DisplayTag.SUBJECT_NAME);

                                        displayMsg = certType + ": \n" +
                                                "Version : " + version + "\n" +
                                                "SN : " + sn + "\n" +
                                                "Start Date : " + startDate + "\n" +
                                                "Expiry Date : " + endDate + "\n" +
                                                "Issuer Name : " + issueName + "\n" +
                                                "Subject Name : " + subjectName + "\n\n";
                                    } else {
                                        displayMsg = certType + " " + status + "\n";
                                    }
                                    messageBuider.append(displayMsg);
                                }
                            }

                            tvResult.setGravity(Gravity.LEFT);
                            tvResult.setText(messageBuider.toString());
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rki_func);

        etHostIP = findViewById(R.id.et_hostIp);
        etHostPort = findViewById(R.id.et_hostPort);
        tvResult = findViewById(R.id.tv_result);
        btDownloadKey = findViewById(R.id.btn_downloadkey);
        btUnBind = findViewById(R.id.btn_unbind);
        btInjectOfflKey = findViewById(R.id.btn_rki_offl);
        btInGetCertList = findViewById(R.id.btn_get_cert);
        btDownloadKey.setOnClickListener(this);
        btUnBind.setOnClickListener(this);
        btInjectOfflKey.setOnClickListener(this);
        btInGetCertList.setOnClickListener(this);
        easyLink = EasyLinkSdkManager.getInstance(this);

        tvResult.setMovementMethod(ScrollingMovementMethod.getInstance());
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }

    @Override
    protected void onResume(){
        super.onResume();
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_downloadkey){
            testRKIRemoteDownloadKey();
        }else if (v.getId() == R.id.btn_unbind){
            testRKIUnbid();
        }else if (v.getId() == R.id.btn_rki_offl) {
            downloadRKIOfflineKeyFile();
        }else if (v.getId() == R.id.btn_get_cert) {
            testGetRKICert();
        }
    }

    private void testRKIRemoteDownloadKey() {
        new Thread(()->{
            easyLink.rkiRemoteKeyDownLoad(etHostIP.getText().toString(),
                    etHostPort.getText().toString(),  RKIFuncActivity.this);
        }).start();
    }

    //monitor  57.40
    private void downloadRKIOfflineKeyFile() {

        String filePath = getFilesDir().getPath() + "/app/" + "PAX_D180_6J879175_1.rki";
        Tools.mkDir(getFilesDir().getPath() + "/app/");
        Tools.copyFileFromAssert(this, "PAX_D180_6J879175_1.rki", filePath);

        new Thread(()-> {
            easyLink.rkiInjectOfflineKey(filePath, RKIFuncActivity.this);
        }).start();
    }


    private void testRKIUnbid(){
        new Thread(()->{
            easyLink.rkiUnBindDevice(etHostIP.getText().toString(),
                    etHostPort.getText().toString(), RKIFuncActivity.this);
         }).start();
    }

    public void testGetRKICert(){
        new Thread(()->{

            ByteArrayOutputStream keyInfo = new ByteArrayOutputStream();
            byte [] bKeyType = new byte[1];
            bKeyType[0] = KeyType.PED_TIK;
            int Ret = easyLink.getKeyInfo(bKeyType[0], (byte) 0x01, keyInfo);
            if ((Ret == ResponseCode.EL_RET_OK) && (keyInfo != null) && (keyInfo.size()>0)) {
                byte[] keyInfoData = keyInfo.toByteArray();
                Log.d("testGetRKICert", "PED_TIK Key 01 :" + Utils.bcd2Str(keyInfoData, 5, 10));
                //result.append(" "+ i + "      " + Utils.bcd2Str(keyInfoData, 1, 4) + "  " + Utils.bcd2Str(keyInfoData, 5, 10) + "\n");
            }

            StringBuffer certBuffer = new StringBuffer();
            int ret = easyLink.rkiGetCertList( certBuffer, RKIFuncActivity.this);
            if(ret == 0){
                Log.d("testGetRKICert", "certBuffer :" + certBuffer.toString());
                Bundle bundle = new Bundle();
                bundle.putString("certList", certBuffer.toString());
                Message msg= new Message();
                msg.what = NORMALSTATUS;
                msg.setData(bundle);
                mayHandler.sendMessage(msg);
            }
        }).start();
    }


//    private void testRKIDebug(){
//        new Thread(()->{
//            Communication communication = new Communication(this,etHostIP.getText().toString(),
//                    etHostPort.getText().toString(), "rki_ca_chain.pem", RKIFuncActivity.this);
//            communication.connectRKIServer(true);
//            communication.online((byte)0x80, Tools.str2Bcd("ff90000400005101ff900303000111ffa400132010005041587c5078377c3730303030303030"));
//            communication.close();
//        }).start();
//    }

    @Override
    public void onDisplayStatus(String displayMessage) {
        Bundle bundle = new Bundle();
        bundle.putString("statusMsg", displayMessage);
        Log.d("onDisplayStatus", "displayMessage :" + displayMessage);
        Message msg= new Message();
        msg.what = NORMALSTATUS;
        msg.setData(bundle);
        mayHandler.sendMessage(msg);
    }

    @Override
    public boolean isNetworkEnable() {
        return true;
    }



}
