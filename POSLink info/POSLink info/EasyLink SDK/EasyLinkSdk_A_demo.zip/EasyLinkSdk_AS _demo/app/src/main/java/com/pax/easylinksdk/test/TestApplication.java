package com.pax.easylinksdk.test;

import android.app.Application;

import com.paxsz.easylink.api.EasyLinkSdkManager;

/**
 * Created by zhanzc on 2017/8/17.
 */

public class TestApplication extends Application {
    public static EasyLinkSdkManager manager;

    @Override
    public void onCreate() {
        super.onCreate();

        manager = EasyLinkSdkManager.getInstance(this);
    }
}
