package com.pax.easylinksdk.test;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.design.widget.TextInputLayout;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import com.pax.easylinksdk.test.manage.ConfigManager;
import com.pax.easylinksdk.test.utils.Tools;
import com.pax.gl.utils.impl.Convert;
import com.paxsz.easylink.model.DataModel;
import com.paxsz.easylink.model.TLVDataObject;
import com.paxsz.easylink.model.report.EmvAidParam;
import com.paxsz.easylink.model.report.ICSParam;

import java.util.ArrayList;

public class ShowParamActivity extends Activity implements View.OnClickListener {
    private static final String TAG = "ShowParamActivity";

    private TextInputLayout layout1;
    private TextInputLayout layout2;
    private TextInputLayout layout3;
    private TextInputLayout layout4;
    private TextInputLayout layout5;
    private TextView mTextView;
    private EditText param1Edit;
    private EditText param2Edit;
    private EditText param3Edit;
    private EditText param4Edit;
    private EditText param5Edit;
    private EditText param6Edit;
    private EditText param7Edit;
    private EditText param8Edit;
    private EditText param9Edit;
    private EditText param10Edit;
    private EditText param11Edit;
    private EditText param12Edit;
    private EditText param13Edit;
    private EditText param14Edit;
    private EditText param15Edit;

    private EditText cmdListSizeEdit;
    private EditText setDataSizeEdit;

    private CheckBox setDataCb;
    private EditText setConfigTlvEdit;
    private EditText setEmvTlvEdit;

    private Button mSkipBtn;
    private Button mSaveBtn;
    int paramType = 0;
    EmvAidParam emvAidParam;
    ICSParam icsParam;
    ConfigManager cfg;

    TimeCount mTimeCount;
    // timer Util
    /* 定义一个倒计时的内部类 */
    class TimeCount extends CountDownTimer {
        public TimeCount(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);// 参数依次为总时长,和计时的时间间隔
        }

        @Override
        public void onFinish() {// 计时完毕时触发
            Log.e(TAG, "onFinish: timeout" );
            processSetResult(new Bundle());
        }

        @Override
        public void onTick(long millisUntilFinished) {// 计时过程显示

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle emvAidData = getIntent().getExtras();
        paramType = emvAidData.getInt("paramType");
        Log.e(TAG, "onCreate: "+paramType );
        int timeout = emvAidData.getInt("timeout",30);
        if(paramType == 1){
            setContentView(R.layout.activity_inputs);
        }else if(paramType == 2){
            setContentView(R.layout.activity_inputs_icsparam);
        }

        cfg = ConfigManager.getInstance(getApplicationContext());
        initView();
        processExtra(emvAidData);
        mTimeCount = new TimeCount(timeout*1000,1000);
        mTimeCount.start();


    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void initView() {
        mTextView = findViewById(R.id.txt_report_tlvs);
        param1Edit = findViewById(R.id.ed_param1);
        param2Edit = findViewById(R.id.ed_param2);
        param3Edit = findViewById(R.id.ed_param4);
        param4Edit = findViewById(R.id.ed_param4);
        param5Edit = findViewById(R.id.ed_param5);
        param6Edit = findViewById(R.id.ed_param6);
        param7Edit = findViewById(R.id.ed_param7);
        param8Edit = findViewById(R.id.ed_param8);
        param9Edit = findViewById(R.id.ed_param9);
        param10Edit = findViewById(R.id.ed_param10);
        param11Edit = findViewById(R.id.ed_param11);
        param12Edit = findViewById(R.id.ed_param12);
        param13Edit = findViewById(R.id.ed_param13);
        param14Edit = findViewById(R.id.ed_param14);
        param14Edit = findViewById(R.id.ed_param14);
        param15Edit = findViewById(R.id.ed_param15);
        mSkipBtn = findViewById(R.id.btn_skip);
        mSaveBtn = findViewById(R.id.btn_save);
        mSkipBtn.setOnClickListener(this);
        mSaveBtn.setOnClickListener(this);
        cmdListSizeEdit = findViewById(R.id.edit_cmdList);
        cmdListSizeEdit.setText("1");

        setDataSizeEdit = findViewById(R.id.edit_setdata_cmdList);

        setDataCb = findViewById(R.id.cb_set_data);
        setDataCb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    String setDataSize = setDataSizeEdit.getText().toString();
                    if(!TextUtils.isEmpty(setDataSize) && Integer.parseInt(setDataSize) == 0){
                        setDataSizeEdit.setText(1+"");
                    }
                }else{
                    setDataSizeEdit.setText(0+"");
                }
            }
        });

        setConfigTlvEdit = findViewById(R.id.ed_set_config_tlv);
        setEmvTlvEdit = findViewById(R.id.ed_set_emv_tlv);

        setConfigTlvEdit.setText(cfg.getValueByTag("configTlvListStr","020201010203010502040100"));
        setEmvTlvEdit.setText(cfg.getValueByTag("emvTlvListStr","9f02060000000050009C0100"));

        layout1 = findViewById(R.id.layout_1);
        layout2 = findViewById(R.id.layout_2);
        layout3 = findViewById(R.id.layout_3);
        layout4 = findViewById(R.id.layout_4);
        layout5 = findViewById(R.id.layout_5);

    }


    private void processExtra(Bundle emvAidData) {

        ArrayList<TLVDataObject> configTLVs = emvAidData.getParcelableArrayList("configTlv");
        ArrayList<TLVDataObject> emvTLVs = emvAidData.getParcelableArrayList("emvTlv");
        StringBuilder configs = new StringBuilder("configTlv:\n");
        if (configTLVs != null && configTLVs.size() > 0) {
            for (TLVDataObject configTLV : configTLVs) {
                configs.append("tag:" + Tools.bcd2Str(configTLV.getTag()) + ", value:" + Tools.bcd2Str(configTLV.getValue()) + "\n");
            }
        }
        StringBuilder emvTLVStr = new StringBuilder("\nemvTLVs:\n");
        if (emvTLVs != null && emvTLVs.size() > 0) {
            for (TLVDataObject emvTLV : emvTLVs) {
                emvTLVStr.append("tag:" + Tools.bcd2Str(emvTLV.getTag()) + ", value:" + Tools.bcd2Str(emvTLV.getValue()) + "\n");
            }
        }

        Log.d(TAG, "report configTLV and emvTLV data:\n" + configs.toString() + emvTLVStr.toString());
        mTextView.setText(configs.toString() + emvTLVStr.toString());
        paramType = emvAidData.getInt("paramType");
        if (paramType == 1) {
            emvAidParam = (EmvAidParam) emvAidData.getSerializable("param");
            initData(emvAidParam, null);
        } else if (paramType == 2) {
            icsParam = (ICSParam) emvAidData.getSerializable("param");
            initData(null, icsParam);

        }
    }

    private void initData(EmvAidParam emvAidParam, ICSParam icsParam) {
        if (emvAidParam != null && icsParam == null) {
            cmdListSizeEdit.setVisibility(View.VISIBLE);
            param1Edit.setText(emvAidParam.getApplicationId());
            param2Edit.setText(emvAidParam.getPartialAidSelection() + "");
            param3Edit.setText(emvAidParam.getIfUseLocalAidName() + "");
            param4Edit.setText(emvAidParam.getLocalAidName());
            param5Edit.setText(emvAidParam.getTerminalAidVersion());
            param6Edit.setText(emvAidParam.getTacDenial());
            param7Edit.setText(emvAidParam.getTacOnline());
            param8Edit.setText(emvAidParam.getTacDefault());
            param9Edit.setText(emvAidParam.getFloorLimit() + "");
            param10Edit.setText(emvAidParam.getThreshold() + "");
            param11Edit.setText(emvAidParam.getTargetPercentage() + "");
            param12Edit.setText(emvAidParam.getMaxTargetPercentage() + "");
            param13Edit.setText(emvAidParam.getTerminalDefaultTDOL());
            param14Edit.setText(emvAidParam.getTerminalDefaultDDOL());
            param15Edit.setText(emvAidParam.getTerminalRiskManagementData());
        } else if (emvAidParam == null && icsParam != null) {
            cmdListSizeEdit.setVisibility(View.GONE);
            layout1.setVisibility(View.GONE);
            layout2.setVisibility(View.GONE);
            layout3.setVisibility(View.GONE);
            layout4.setVisibility(View.GONE);
            layout5.setVisibility(View.GONE);
            param6Edit.setText(icsParam.getCardDataInputCapability());
            param7Edit.setText(icsParam.getCvmCapability());
            param8Edit.setText(icsParam.getSecurityCapability());
            param9Edit.setText(icsParam.getAdditionalTerminalCapabilities());
            param10Edit.setText(icsParam.getGetDataForPinTryCounter() + "");
            param10Edit.setText(icsParam.getGetDataForPinTryCounter() + "");
            param11Edit.setText(icsParam.getBypassPinEntry() + "");
            param12Edit.setText(icsParam.getSubsequentBypassPinEntry() + "");
            param13Edit.setText(icsParam.getExceptionFileSupported() + "");
            param14Edit.setText(icsParam.getForcedOnlineCapability() + "");
            param15Edit.setText(icsParam.getIssuerReferralsSupported() + "");
        }
    }

    @Override
    public void onClick(View v) {

        Bundle bundle = new Bundle();
        switch (v.getId()) {
            case R.id.btn_skip:
                break;
            case R.id.btn_save:
                if (paramType == 1) {
                    emvAidParam.setTerminalAidVersion(param5Edit.getText().toString());
                    emvAidParam.setTacDenial(param6Edit.getText().toString());
                    emvAidParam.setTacOnline(param7Edit.getText().toString());
                    emvAidParam.setTacDefault(param8Edit.getText().toString());
                    emvAidParam.setFloorLimit(Long.parseLong(param9Edit.getText().toString()));
                    emvAidParam.setThreshold(Long.parseLong(param10Edit.getText().toString()));
                    emvAidParam.setTargetPercentage((byte)Integer.parseInt(param11Edit.getText().toString()));
                    emvAidParam.setMaxTargetPercentage((byte)Integer.parseInt(param12Edit.getText().toString()));
                    emvAidParam.setTerminalDefaultTDOL(param13Edit.getText().toString());
                    emvAidParam.setTerminalDefaultDDOL(param14Edit.getText().toString());
                    emvAidParam.setTerminalRiskManagementData(param15Edit.getText().toString());
                    bundle.putSerializable("param", emvAidParam);
                } else if (paramType == 2) {
                    icsParam.setCardDataInputCapability(param6Edit.getText().toString());
                    icsParam.setCvmCapability(param7Edit.getText().toString());
                    icsParam.setSecurityCapability(param8Edit.getText().toString());
                    icsParam.setAdditionalTerminalCapabilities(param9Edit.getText().toString());
                    icsParam.setGetDataForPinTryCounter(Integer.parseInt(param10Edit.getText().toString()));
                    icsParam.setBypassPinEntry(Integer.parseInt(param11Edit.getText().toString()));
                    icsParam.setSubsequentBypassPinEntry(Integer.parseInt(param12Edit.getText().toString()));
                    icsParam.setExceptionFileSupported(Integer.parseInt(param13Edit.getText().toString()));
                    icsParam.setForcedOnlineCapability(Integer.parseInt(param14Edit.getText().toString()));
                    icsParam.setIssuerReferralsSupported(Integer.parseInt(param15Edit.getText().toString()));
                    bundle.putSerializable("param", icsParam);
                }

                if (setDataCb.isChecked()) {
                    String setDataCmdSize = setDataSizeEdit.getText().toString();
                    if(!TextUtils.isEmpty(setDataCmdSize)&& Integer.parseInt(setDataCmdSize)>0){
                        String configTlvList = setConfigTlvEdit.getText().toString();
                        String emvTlvList = setEmvTlvEdit.getText().toString();
                        ArrayList<TLVDataObject> configList = new ArrayList<>();
                        ArrayList<TLVDataObject> emvList = new ArrayList<>();
                        if(!TextUtils.isEmpty(configTlvList)){
                            configList.addAll(Utils.unpackTLVs(DataModel.DataType.CONFIGURATION_DATA, Convert.strToBcd(configTlvList, Convert.EPaddingPosition.PADDING_RIGHT)));
                        }
                        if(!TextUtils.isEmpty(emvTlvList)){
                            emvList.addAll(Utils.unpackTLVs(DataModel.DataType.TRANSACTION_DATA, Convert.strToBcd(emvTlvList, Convert.EPaddingPosition.PADDING_RIGHT)));
                        }
                        bundle.putParcelableArrayList("emvTlvList",emvList);
                        bundle.putParcelableArrayList("configTlvList",configList);
                        bundle.putInt("setDataSize",Integer.parseInt(setDataCmdSize));

                        cfg.saveTagValue("emvTlvListStr", emvTlvList);
                        cfg.saveTagValue("configTlvListStr", configTlvList);
                    }else{
                        bundle.putParcelableArrayList("emvTlvList",null);
                        bundle.putParcelableArrayList("configTlvList",null);
                        bundle.putInt("setDataSize",0);
                    }
                }else{
                    bundle.putParcelableArrayList("emvTlvList",null);
                    bundle.putParcelableArrayList("configTlvList",null);
                }
                break;
        }

       processSetResult(bundle);
    }

    @Override
    public void onBackPressed() {
        processSetResult(new Bundle());
        super.onBackPressed();

    }

    private void processSetResult(Bundle bundle){
        if(ShowParamActivity.this.isFinishing()){
            return;
        }
        Intent intent = new Intent(ShowParamActivity.this, EasyLinkActivity.class);
        if (paramType == 1) {
            bundle.putSerializable("param", emvAidParam);
        } else if (paramType == 2) {
            bundle.putSerializable("param", icsParam);
        }
        bundle.putInt("paramType", paramType);

        bundle.putInt("cmdListSize",Integer.parseInt(cmdListSizeEdit.getText().toString()));
        intent.putExtras(bundle);
        setResult(0, intent);
        finish();
        if (mTimeCount != null) {
            mTimeCount.cancel();
            mTimeCount = null;
        }
    }
}
