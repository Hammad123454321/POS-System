package com.pax.easylinksdk.test.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.pax.easylinksdk.test.R;
import com.pax.easylinksdk.test.manage.ConfigManager;
import com.paxsz.easylink.api.EasyLinkSdkManager;
import com.paxsz.easylink.device.DeviceInfo;


/**
 * Created by zhanzc on 2017/8/8.
 * 测试连接功能
 */

public class ConnectActivity extends Activity implements View.OnClickListener {

    private EditText et_ip;
    private EditText et_port;
    private ProgressDialog progress;
    private final int REQUEST_BT_DISCOVER = 2;
    private static final int MSG_CONNECT_TCP = 10;
    ConfigManager cfgm;
    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message message) {
            switch (message.what) {
                case MSG_CONNECT_TCP:
                    progress.dismiss();
                    Toast.makeText(getApplicationContext(), "TCP Connect, ret = " + message.arg1, Toast.LENGTH_SHORT).show();
                    break;
            }
            return false;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connect);

        progress = new ProgressDialog(this);

        et_ip = (EditText) findViewById(R.id.et_ip);
        et_port = (EditText) findViewById(R.id.et_port);
        cfgm = ConfigManager.getInstance(getApplicationContext());
        String ip = cfgm.serverAddr;
        int port = cfgm.serverPort;
        et_ip.setText(ip);
        et_port.setText("" + port);
        findViewById(R.id.btn_connect_tcp).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.btn_search_bluetooth:
                Intent bluetoothIntent = new Intent(this, BluetoothActivity.class);
                startActivity(bluetoothIntent);
                break;

            case R.id.btn_connect_tcp:
                progress.show();
                String inputIp = et_ip.getText().toString();
                String inputPort = et_port.getText().toString();

                if (TextUtils.isEmpty(inputIp) || TextUtils.isEmpty(inputPort)) {
                    Toast.makeText(getApplicationContext(), "Please Input IP and Port", Toast.LENGTH_SHORT).show();
                    progress.dismiss();
                    return;
                }

                int iPort;
                try {
                    iPort = Integer.parseInt(inputPort);
                } catch (Exception e) {
                    progress.dismiss();
                    return;
                }


                final DeviceInfo tcpDevice = new DeviceInfo(DeviceInfo.CommType.TCP);
                tcpDevice.setIp(inputIp);
                tcpDevice.setPort(iPort);
                tcpDevice.setIdentifier(inputIp + iPort);
                cfgm.serverAddr = inputIp;
                cfgm.serverPort = iPort;
                cfgm.save();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        int tcpRet = EasyLinkSdkManager.getInstance(getApplicationContext()).connect(tcpDevice);
                        Message message = Message.obtain();
                        message.what = MSG_CONNECT_TCP;
                        message.arg1 = tcpRet;
                        handler.sendMessage(message);
                    }
                }).start();
                break;

            case R.id.btn_get_usb_device:
                startActivity(new Intent(this, UsbActivity.class));
                break;

            case R.id.btn_ipc:
                final DeviceInfo deviceInfo = new DeviceInfo(DeviceInfo.CommType.IPC);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        int result = EasyLinkSdkManager.getInstance(ConnectActivity.this).connect(deviceInfo);
                        handler.sendEmptyMessage(result);
                    }
                }).start();
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
