package com.pax.easylinksdk.test.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.pax.easylinksdk.test.R;
import com.pax.easylinksdk.test.TestApplication;
import com.pax.easylinksdk.test.manage.ConfigManager;
import com.pax.easylinksdk.test.observer.DataWatcher;
import com.pax.easylinksdk.test.observer.IObservable;
import com.pax.easylinksdk.test.utils.MyLog;
import com.paxsz.easylink.device.DeviceInfo;
import com.paxsz.easylink.listener.IDeviceStateChangeListener;
import com.paxsz.easylink.listener.SearchDeviceListener;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by zhanzc on 2017/8/8.
 * 测试连接功能
 */

public class BluetoothActivity extends Activity implements View.OnClickListener, IObservable {
    private static final String TAG = "BluetoothActivity";
    private TextView tv_progress;

    private ListView lv_bluetooth;
    private List<DeviceInfo> deviceInfos;
    private BluetoothAdapter adapter;

    private Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message message) {
            int ret = message.arg1;
            if (message.what == 0) {
                Toast.makeText(BluetoothActivity.this, "BT Disconnect, ret = " + ret, Toast.LENGTH_SHORT).show();
            } else if (message.what == 1) {
                Toast.makeText(BluetoothActivity.this, "BT connect, ret = " + ret, Toast.LENGTH_SHORT).show();
                TestApplication.manager.registerDisconnectStateListener(new IDeviceStateChangeListener() {
                    @Override
                    public void onDisconnect() {
                        Toast.makeText(BluetoothActivity.this, "BT has disconnect", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            return false;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);

        // 观察者观察被观察者
        DataWatcher.getInstance().register(this);
        lv_bluetooth = (ListView) findViewById(R.id.lv_bluetooth);
        deviceInfos = new ArrayList<DeviceInfo>();
        adapter = new BluetoothAdapter(this, deviceInfos);
        lv_bluetooth.setAdapter(adapter);
        lv_bluetooth.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int i, long l) {
                TestApplication.manager.stopSearchingDevice();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        int ret = TestApplication.manager.connect(deviceInfos.get(i));

                        ConfigManager.getInstance(BluetoothActivity.this).bluetoothMac = deviceInfos.get(i).getIdentifier();
                        ConfigManager.getInstance(BluetoothActivity.this).deviceName = deviceInfos.get(i).getDeviceName();
                        ConfigManager.getInstance(BluetoothActivity.this).commType = deviceInfos.get(i).getCommType().name();
                        ConfigManager.getInstance(BluetoothActivity.this).save();
                        Message message = Message.obtain();
                        message.arg1 = ret;
                        message.what = 1;
                        mHandler.sendMessage(message);
                    }
                }).start();

            }
        });

        tv_progress = (TextView) findViewById(R.id.tv_progress);
        findViewById(R.id.btn_stop_searching).setOnClickListener(this);
        findViewById(R.id.btn_search).setOnClickListener(this);
        findViewById(R.id.btn_reconnect).setOnClickListener(this);
    }

    @Override
    protected void onDestroy() {
        // 观察者观察被观察者
        DataWatcher.getInstance().unregister(this);
        super.onDestroy();
    }


    private static class BluetoothListener implements SearchDeviceListener {
        @Override
        public void discoverOneDevice(DeviceInfo deviceInfo) {
            // 通知被观察者更新数据
            DataWatcher.getInstance().notifyObservable(deviceInfo);
        }

        @Override
        public void discoverComplete() {
            // 通知被观察者更新数据
            DataWatcher.getInstance().notifyFinish();
        }
    }

    private void startSearch() {
        tv_progress.setText("Search......");
        deviceInfos.clear();
        adapter.notifyDataSetChanged();

        TestApplication.manager.searchDevices(new BluetoothListener(), 40000);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_search:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {//API LEVEL 18
                    if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_DENIED || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_DENIED) {
                        MyLog.e(TAG,"request permission");
                        requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.BLUETOOTH, Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.BLUETOOTH_ADMIN, Manifest.permission.BLUETOOTH_PRIVILEGED}, 1001);
                        return;
                    } else {

                    }
                }
                startSearch();

                break;

            case R.id.btn_stop_searching:
                TestApplication.manager.stopSearchingDevice();
                break;

            case R.id.btn_reconnect:
                final DeviceInfo.CommType commType = ConfigManager.getInstance(BluetoothActivity.this).commType.equals(DeviceInfo.CommType.BLUETOOTH.name()) ? DeviceInfo.CommType.BLUETOOTH : DeviceInfo.CommType.BLUETOOTH;
                final String deviceName = ConfigManager.getInstance(BluetoothActivity.this).deviceName;
                final String macAddr = ConfigManager.getInstance(BluetoothActivity.this).bluetoothMac;
                MyLog.e(TAG,"reconnect: commType->"+commType.name()+", deviceName->"+deviceName+", mac->"+macAddr);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        DeviceInfo devInfo = new DeviceInfo(commType, deviceName, macAddr);
                        int ret = TestApplication.manager.connect(devInfo);
                        Message message = Message.obtain();
                        message.arg1 = ret;
                        message.what = 1;
                        mHandler.sendMessage(message);
                    }
                }).start();

                break;
        }
    }

    @Override
    public void update(DeviceInfo paramDeviceInfo) {
        deviceInfos.add(paramDeviceInfo);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onSearchFinish() {
        tv_progress.setText("Searching complete");
    }


    private class BluetoothAdapter extends BaseAdapter {
        private Context context;
        private List<DeviceInfo> deviceList;

        public BluetoothAdapter(Context context, List<DeviceInfo> devices) {
            this.context = context;
            this.deviceList = devices;
        }

        @Override
        public int getCount() {
            return deviceList.size();
        }

        @Override
        public Object getItem(int i) {
            return deviceList.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                view = LayoutInflater.from(context).inflate(R.layout.item_bluetooth, null);
                viewHolder = new ViewHolder();
                viewHolder.tv_bluetooth = (TextView) view.findViewById(R.id.tv_bluetooth);
                view.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) view.getTag();
            }

            viewHolder.tv_bluetooth.setText(deviceList.get(i).getDeviceName() + "  Addr: " + deviceList.get(i).getIdentifier());

            return view;
        }
    }

    private ViewHolder viewHolder;

    private static class ViewHolder {
        TextView tv_bluetooth;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1001) {
            for (int grantResult : grantResults) {
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    continue;
                }else {
                    return;
                }
            }
            startSearch();

        }
    }
}
