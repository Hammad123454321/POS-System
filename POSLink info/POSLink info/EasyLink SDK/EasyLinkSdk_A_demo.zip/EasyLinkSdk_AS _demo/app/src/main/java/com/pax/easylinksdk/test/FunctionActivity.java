package com.pax.easylinksdk.test;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;


public class FunctionActivity extends ListActivity {

    private String mModule;
    private String mInterface;
    private String mFuncNum;

    private String[] mFunDownLoadExtFile = {
            "1.EasyLinkServer",
            "2.EasyLinkFull",
            "3.EasyLinKLite",
    };

    private String[] mFunSetData = {
            "1.SetTransData",
            "2.SetConfData",
            "3.SetFixConfig",
            "4.SetFixTrans",
            "5.SetCompleteTransData"
    };

    private String[] mFunGetData = {
            "1.GetTransData",
            "2.GetConfData",
            "3.GetAllConfData",
            "4.GetTermInfo",
    };


    private String[] mFunCompleteTransaction = {
            "1.CompleteTransaction",
            "2.CompleteTransactionWithReport",
            "3.CompleteTransactionWithCancel",
    };

    private String[] mFunGetPinBlock = {
            "1.GetPinBlock",
            "2.GetPinBlockWithReport",
            "3.GetPinBlockWithCancel",
    };

    private String[] mFunConnect = {
            "1.BT",
            "2.TCP",
            "3.USB",
            "4.IPC",
    };

    private String[] mFunStartTrans = {
            "1.StartTrans",
            "2.StartTransWithReport",
            "3.Sale&online approve",
            "4.Sale&online decline",
            "5.cashBack&online approve",
            "6.cashback&online decline",
            "7.StartTransWithReportStatus",
            "8.StartTransWithCancel",
            "9.StartTransWithMultiAcq",
            "10.StartRefundTrans",
            "11.StartTrans(NoDefaultData)",
    };

    private String[] mFileDownLoad = {
            "1.input Name",
            "2.D180 UI",
            "3.EasyLink App.bin",
            "4.bmp1.bmp",
            "5.clss_param.clss",
            "6.emv_param.emv",
            "7.FONT_EUR_INT_01.font",
            "8.monitor file.monitor",
    };


    private String[] mFunWriteKey = {
            "1.WriteTWKAndTest",
            "2.WriteTIKAndTest",
            "3.CalPinByPlainKey",
            "4.CalPinByEncryptKey",
            "5.CalMacByPlainKey",
            "6.CalMacByEncryptKey",
            "7.CalDataByPlainKey",
            "8.CalDataEncryptKey",
            "9.CalDataEncryptKeyKCV",
            "10.WriteErrkeyTestRetCode",
            "11.CalPinByNoKcvTIK",
            "12.CalPinByKcvTIK"
    };

    private String[] mFunShowPage = {
            "1.pageSignature.xml",
            "2.pageBarcode.xml",
            "3.showPage"
    };

    private String[] mEncryptData = {
            "1.encryptData"
    };
    private String[] mCancelFileDownload = {
            "1.cancelFileDownload"
    };

    private String[] mCalcMac = {
            "1.calcMac"
    };
    private String[] mIncreaseKSN = {
            "1.increaseKSN"
    };

    private String[] mGetKeyInfo = {
            "1.getKeyInfo"
    };

    private String[] mEmv = {
            "1.EMV contact 1",
            "2.EMV contact 2",
            "3.EMV contactless",
            "4.EMV contact 3"

    };
    private String[] mSwitchMode = {
            "1.SIMPLE_WITH_MULTI_FRAME_PROTOCOL",
            "2.MULTI_FRAMEP_ROTOCOL",
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();
        mModule = intent.getStringExtra("Module");
        mInterface = intent.getStringExtra("Interface");
        mFuncNum = intent.getStringExtra("FuncNum");
        intent.getStringExtra("TolNum");
        intent.getStringExtra("StrNum");

        TextView tv = (TextView) findViewById(R.id.list_title);
        tv.setText(mInterface);

        if ("DownLoadExtFile".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mFunDownLoadExtFile));
        } else if ("setData".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mFunSetData));
        } else if ("getData".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mFunGetData));
        } else if ("connect".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mFunConnect));
        } else if ("startTransaction".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mFunStartTrans));
        } else if ("fileDownLoad".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mFileDownLoad));
        } else if ("completeTransaction".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mFunCompleteTransaction));
        } else if ("getPinBlock".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mFunGetPinBlock));
        } else if ("WriteKey".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mFunWriteKey));
        } else if ("cancelFileDownload".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mCancelFileDownload));
        } else if ("showPage".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mFunShowPage));
        } else if ("encryptData".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mEncryptData));
        } else if ("calcMac".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mCalcMac));
        } else if ("IncreaseKsn".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mIncreaseKSN));
        } else if ("EMV".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mEmv));
        } else if ("switchCommMode".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mSwitchMode));
        } else if ("GetKeyInfo".equals(mFuncNum)) {
            setListAdapter(new MainListAdapter(this, mGetKeyInfo));
        }
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        Intent intent;

        if (mModule.equals("EasyLink")) {
            intent = new Intent(FunctionActivity.this, EasyLinkActivity.class);
            intent.putExtra("Interface", mInterface);
            intent.putExtra("No", (position + 1) + "");
        } else {
            return;
        }

        startActivity(intent);
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
        }
        return false;
    }

    private class MainListAdapter extends BaseAdapter {
        private Context mContext;
        private String[] mStrings;

        public MainListAdapter(Context context, String[] strAry) {
            mContext = context;
            mStrings = strAry;
        }

        public int getCount() {
            return mStrings.length;
        }

        @Override
        public boolean areAllItemsEnabled() {
            return false;
        }

        @Override
        public boolean isEnabled(int position) {
            return !mStrings[position].startsWith("-");
        }

        public Object getItem(int position) {
            return position;
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            TextView tv;
            if (convertView == null) {
                tv = (TextView) LayoutInflater.from(mContext).inflate(
                        android.R.layout.simple_expandable_list_item_1, parent, false);
            } else {
                tv = (TextView) convertView;
            }
            tv.setText(mStrings[position]);
            return tv;
        }
    }
}
