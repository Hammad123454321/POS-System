/*
 * ===========================================================================================
 * = COPYRIGHT
 *          PAX Computer Technology(Shenzhen) CO., LTD PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or nondisclosure
 *   agreement with PAX Computer Technology(Shenzhen) CO., LTD and may not be copied or
 *   disclosed except in accordance with the terms in that agreement.
 *     Copyright (C) YYYY-? PAX Computer Technology(Shenzhen) CO., LTD All rights reserved.
 * Description: // Detail description about the function of this module,
 *             // interfaces with the other modules, and dependencies.
 * Revision History:
 * Date                      Author                 Action
 * 20180712                  huangwp                Create
 *
 *
 * ============================================================================
 */
package com.pax.easylinksdk.test;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.paxsz.easylink.api.EasyLinkSdkManager;
import com.paxsz.easylink.listener.FileDownloadListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class SelectFileActivity extends Activity implements AdapterView.OnItemClickListener{
    private static final String TAG = "SelectFileActivity";
    private String platForm;
    private ArrayList arrayListPath = new ArrayList();
    private ArrayList arrayListName = new ArrayList();
    private ArrayList fileList = new ArrayList();
    private HashMap hashMap = new HashMap();
    private String filePath;
    private EasyLinkSdkManager easyLinkSdkManager;
    private AlertDialog alertDialog1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_select_file);


        Intent intent = getIntent();
        platForm = intent.getStringExtra("platform");
        Log.d(TAG, "platForm =" + platForm);
        getFile();
        Collections.sort(arrayListName, Collections.reverseOrder());
        ArrayAdapter<ArrayList<String>> adapter = new ArrayAdapter<ArrayList<String>>(
                SelectFileActivity.this, android.R.layout.simple_list_item_1, arrayListName);
        ListView listView = (ListView) findViewById(R.id.list_view);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);

        easyLinkSdkManager = EasyLinkSdkManager.getInstance(getApplicationContext());
        alertDialog1 = new AlertDialog.Builder(SelectFileActivity.this)
                .setTitle("download file")//标题
                .setMessage("")//内容
                .create();
    }


    /**
     54      * 响应ListView中item的点击事件
     55      */
    @Override
    public void onItemClick(AdapterView<?> arg0, View v, int position, long id) {
        Toast.makeText(this, "item clicked, pos -->" + position,
                          Toast.LENGTH_SHORT).show();
        Log.d(TAG, "onItemClick:" + position);
        Log.d(TAG, "onItemClick String:" + arg0.getAdapter().getItem(position));
        filePath = (String)hashMap.get(arg0.getAdapter().getItem(position));
        Log.d(TAG, "onItemClick value:" + filePath);

        new Thread(new Runnable() {
            @Override
            public void run() {
                final String result;
                int ret =  easyLinkSdkManager.fileDownLoad(filePath, new myFileDownloadListener());
                Log.d(TAG,"fileDownLoad ret =" + ret);
                result = "ret = " + ret;
                SelectFileActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        alertDialog1.setMessage(result);
                        alertDialog1.show();
                    }
                });
            }
        }).start();
     }



    private void getFile(){
            String state = Environment.getExternalStorageState();

            if(Environment.MEDIA_MOUNTED.equals(state)){
                Log.d(TAG,"Environment" );
                File root = Environment.getExternalStorageDirectory();
                Log.d(TAG,"getExternalStorageDirectory:"+root.toString() );
                String path = root.getPath() + "/EasyLinkParam";
                fileScan(path);
                File file = new File(path);
                if(file.exists()){
                    Log.d(TAG,"path:"+ path );
                    File[] files = file.listFiles();
                    getDirFile(files);
                    Log.d(TAG,"getDirFile end:" );
                    Log.d(TAG,"getDirFile end arrayListPath.size():"+arrayListPath.size() );
                    if (platForm.equals("Server")) {
                        fileList = getSeverParam(arrayListPath);
                    }else if(platForm.equals("Full")){
                        fileList = getFullParam(arrayListPath);
                    }else if(platForm.equals("Lite")){
                        fileList = getLiteParam(arrayListPath);
                    }

                }else {
                    Toast.makeText(this, "Pls put EasyLinkParam to external storage",
                            Toast.LENGTH_SHORT).show();
                    Log.d(TAG,"Copy EasyLinkParam to external storage");
                    CopyAssets(SelectFileActivity.this,"EasyLinkParam",path);
                }
            }




    }

    private ArrayList<String> getDirFile(File[] files){
        for(int i = 0; i< files.length; i++){
            //Log.d("huangwp","files:"+ files[i].getName());
            if(files[i].isDirectory()){
                //Log.d("huangwp","getDirFile dir files:"+ files[i].getName());
                getDirFile(files[i].listFiles());
            }else{
                //Log.d("huangwp","getDirFile normal files:"+ files[i].getName());
                Log.d(TAG,"getDirFile normal files:"+ files[i].getPath());
                arrayListPath.add(files[i].getPath());
            }
        }
        //Log.d("huangwp","getDirFile end:");
        return arrayListPath;
    }

    private ArrayList<String> getFullParam(ArrayList<String> strings){
        ArrayList<String> parmList = new ArrayList();

        for(String list: strings){
            if(list.contains("full")){
                parmList.add(list);
                arrayListName.add(list.substring(list.lastIndexOf("/")+1));
                hashMap.put(list.substring(list.lastIndexOf("/")+1),list);
                Log.d(TAG,"getFullParam list :" + list);
            }
        }
        return parmList;
    }

    private ArrayList<String> getLiteParam(ArrayList<String> strings){
        ArrayList<String> parmList = new ArrayList();

        for(String list: strings){
            if(list.contains("lite")){
                parmList.add(list);
                arrayListName.add(list.substring(list.lastIndexOf("/")+1));
                hashMap.put(list.substring(list.lastIndexOf("/")+1),list);
                Log.d(TAG,"getLiteParam list :" + list);
            }
        }
        Log.d(TAG,"getLiteParam parmList.size() :" + parmList.size());
        return parmList;
    }

    private ArrayList<String> getSeverParam(ArrayList<String> strings){
        ArrayList<String> parmList = new ArrayList();
        Log.d(TAG,"getSeverParam strings.size() :" + strings.size());
        for(String list: strings){
            Log.d(TAG,"getSeverParam list :" + list);
            if(list.contains("server")){
                arrayListName.add(list.substring(list.lastIndexOf("/")+1));
                parmList.add(list);
                hashMap.put(list.substring(list.lastIndexOf("/")+1),list);
                Log.d(TAG,"getSeverParam list :" + list);
            }
        }
        Log.d(TAG,"getSeverParam parmList.size() :" + parmList.size());
        return parmList;
    }


    public void CopyAssets(Context context, String oldPath, String newPath) {
        try {
            String fileNames[] = context.getAssets().list(oldPath);// 获取assets目录下的所有文件及目录名
            if (fileNames.length > 0) {// 如果是目录
                File file = new File(newPath);
                file.mkdirs();// 如果文件夹不存在，则递归
                for (String fileName : fileNames) {
                    CopyAssets(context, oldPath + "/" + fileName, newPath + "/" + fileName);
                    fileScan(newPath);
                }
            } else {// 如果是文件
                InputStream is = context.getAssets().open(oldPath);
                FileOutputStream fos = new FileOutputStream(new File(newPath));
                byte[] buffer = new byte[1024];
                int byteCount = 0;
                while ((byteCount = is.read(buffer)) != -1) {// 循环从输入流读取
                    // buffer字节
                    fos.write(buffer, 0, byteCount);// 将读取的输入流写入到输出流
                }
                fos.flush();// 刷新缓冲区
                is.close();
                fos.close();
                fileScan(newPath);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private  void  fileScan(String fName){
        Uri data = Uri. parse("file:///" +fName);
        sendBroadcast( new  Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE , data));
    }

    class myFileDownloadListener implements FileDownloadListener {
        String percent;
        public void onDisplayStatus(int current, int total) {
            percent = current + "/" + total;
         SelectFileActivity.this.runOnUiThread(new Runnable() {
             @Override
             public void run() {
                 alertDialog1.setMessage(percent);
                 alertDialog1.show();
             }
         });

        }

        @Override
        public boolean cancelDownload() {
            // TODO Auto-generated method stub
            return false;
        }
    }

}
