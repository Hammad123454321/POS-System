package com.pax.easylinksdk.test;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.pax.easylinksdk.test.manage.ConfigManager;


public class InputActivity extends Activity {
    private static String TAG = "InputActivity";
    private TextView tvTips;
    private EditText index;
    private int func;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interface);
        Intent intent = getIntent();
        final String mInterface = intent.getStringExtra("Interface");
        String idxText = intent.getStringExtra("index");
        func = intent.getIntExtra("FUNC", 0);
        TextView tv = (TextView) findViewById(R.id.title);
        tvTips = (TextView) findViewById(R.id.tips);
        tv.setText(mInterface);
        index = (EditText) findViewById(R.id.index);
        index.setText(idxText);
        context = getApplicationContext();
        Button confirm = (Button) findViewById(R.id.confirm);
        confirm.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                if (!index.getText().toString().equals("")) {
                    Intent intent = new Intent();
                    intent.setClass(getApplicationContext(), EasyLinkActivity.class);
                    String value = index.getText().toString();

                    ConfigManager cfg = ConfigManager.getInstance(getApplicationContext());
                    cfg.saveTagValue(mInterface, value);

                    intent.putExtra("index", value);
                    intent.putExtra("FUNC", func);
                    setResult(RESULT_OK, intent);
                    Log.e(TAG, "InputActivity FUNC:" + func + ", value:" + value);
                    finish();
                } else {
                    tvTips.setText("can not be empty");
                }
            }
        });
    }
}
