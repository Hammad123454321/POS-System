/*
 * ===========================================================================================
 * = COPYRIGHT
 *          PAX Computer Technology(Shenzhen) CO., LTD PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or nondisclosure
 *   agreement with PAX Computer Technology(Shenzhen) CO., LTD and may not be copied or
 *   disclosed except in accordance with the terms in that agreement.
 *     Copyright (C) YYYY-? PAX Computer Technology(Shenzhen) CO., LTD All rights reserved.
 * Description: // Detail description about the function of this module,
 *             // interfaces with the other modules, and dependencies.
 * Revision History:
 * Date                      Author                 Action
 * 20180812                  huangwp                Create
 *
 *
 * ============================================================================
 */
package com.pax.easylinksdk.test.activity;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.ConditionVariable;
import android.text.InputFilter;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.pax.easylinksdk.test.R;
import com.pax.easylinksdk.test.EasyLinkActivity;
import com.pax.easylinksdk.test.manage.ConfigManager;

public class SetConfigParamActivity extends ListActivity {
    private static final String TAG = "SetConfigParamActivity";
    private String[] mStrings = {
            "1.SleepModeTimeout",
            "2.PINEncryptionType",
            "3.PINEncryptionKeyIdx",
            "4.PINBlockMode",
            "5.DataEncryptionType",
            "6.DataEncryptionKeyIdx",
            "7.FallbackAllowFlag",
            "8.PANMaskStartPos",
            "9.TransactionProcessingMode",
            "10.DUKPTDESmode ",
            "11.MacKeyIdx",
            "12.Language",
            "13.MacCalcType",
            "14.MacCalcMode",
            "15.CardEntryMode",
            "16.MsrRequestPINAuto",
            "17.SupportReport",
            "18.EmvRefundNeedAuthorize",
            "19.ContactlessLightStandard",
            "20.ReportTimeout",
    };

    private String[] mPinEncType = {
            "1.TDES",
            "2.DUKPT",
    };

    private String[] mPinBlockMode = {
            "1.0x00: ISO9564 format0",
            "2.0x01: ISO9564 format1",
            "3.0x02: ISO9564 format3",

    };

    private String[] mDataEncryptType = {
            "1.Plaintext",
            "2.TDES",
            "3.RSA",
            "4.MAC",
            "5.DUKPT",
            "6.CYBS"

    };

    private String[] mFallBack = {
            "1.fallback not allowed",
            "2.fallback allowed",
    };

    private String[] mPANMaskStartPos = {
            "1.0",
            "2.1",
            "3.2",
            "4.3",
            "5.4",
            "6.5",
            "7.6",
    };

    private String[] mTransMode = {
            "1.normal",
            "2.demo",
    };

    private String[] mdukptDesMode = {
            "1.ECB Decryption",
            "2.ECB Encryption",
            "3.CBC Decryption",
            "4.CBC Encryption",
    };

    private String[] mLanguage = {
            "1.English",
            "2.Farsi",
            "3.Japanese",
            "4.Greek"
    };

    private String[] mMacCalcType = {
            "1.TAK",
            "2.TIK",
    };

    private String[] mMacCalcMode = {
            "1.0x00",
            "2.0x01",
            "3.0x02",
            "4.0x20",
            "5.0x21",
            "6.0x22",
            "7.0x40",
            "8.0x41",
            "9.0x42",
    };

    private String[] mCardEntryMode = {
            "1.MSR SWIPE",
            "2.ICC INSERT",
            "3.SWIPE/INSERT",
            "4.PICC TAP",
            "5.SWIPE/TAP",
            "6.INSERT/TAP",
            "7.SWIPE/INSERT/TAP",
    };

    private String[] mMsrReqPinAuto = {
            "1.REQUEST PIN AUTO",
            "2.DO NOT REQUEST PIN",

    };

    private String[] mSupportReport = {
            "1.UNSUPPORT",
            "2.SUPPORT",

    };

    private String[] mEmvRefundNeedAuthorize = {
            "1.Need Emv Auth",
            "2.No Need Emv Auth",
    };

    private String[] mContactlessLightStandard = {
            "1.Standard",
            "2.Europe",

    };

    private ConfigManager configManager;
    private int func;

    final ConditionVariable cv = new ConditionVariable();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_param_setting);
        Intent intent = getIntent();
        TextView tv = (TextView)findViewById(R.id.list_title);
        tv.setText(getString(R.string.dxx_test));
        configManager = ConfigManager.getInstance(getApplicationContext());
        func = intent.getIntExtra("FUNC", 0);
        setListAdapter(new MainListAdapter(this));
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        switch (position) {
            case 0:
                showInputDialog("SleepModeTimeout",4);
                break;
            case 1:
                ShowChoise(mPinEncType, "PINEncryptionType");
                break;
            case 2:
                showInputDialog("PINEncryptionKeyIdx",2);
                break;
            case 3:
                ShowChoise(mPinBlockMode, "PINBlockMode");
                break;
            case 4:
                ShowChoise(mDataEncryptType, "DataEncryptionType");
                break;
            case 5:
                showInputDialog("DataEncryptionKeyIdx",2);
                break;
            case 6:
                ShowChoise(mFallBack, "FallbackAllowFlag");
                break;
            case 7:
                ShowChoise(mPANMaskStartPos, "DataEncryptionType");
                break;
            case 8:
                ShowChoise(mTransMode, "TransactionProcessingMode");
                break;
            case 9:
                ShowChoise(mdukptDesMode, "DUKPTDESmode");
                break;
            case 10:
                showInputDialog("MacKeyIdx",2);
                break;
            case 11:
                ShowChoise(mLanguage, "Language");
                break;
            case 12:
                ShowChoise(mMacCalcType, "MacCalcType");
                break;
            case 13:
                ShowChoise(mMacCalcMode, "MacCalcMode");
                break;
            case 14:
                ShowChoise(mCardEntryMode, "CardEntryMode");
                break;
            case 15:
                ShowChoise(mMsrReqPinAuto, "MsrRequestPINAuto");
                break;
            case 16:
                ShowChoise(mSupportReport, "SupportReport");
                break;
            case 17:
                ShowChoise(mEmvRefundNeedAuthorize, "EmvRefundNeedAuthorize");
                break;
            case 18:
                ShowChoise(mContactlessLightStandard, "ContactlessLightStandard");
                break;
            case 19:
                showInputDialog("ReportTimeout", 4);
                break;
            default:
                break;
        }
    }

    private class MainListAdapter extends BaseAdapter {
        private Context mContext;

        public MainListAdapter(Context context) {
            mContext = context;
        }

        public int getCount() {
            return mStrings.length;
        }

        @Override
        public boolean areAllItemsEnabled() {
            return false;
        }

        @Override
        public boolean isEnabled(int position) {
            return !mStrings[position].startsWith("-");
        }

        public Object getItem(int position) {
            return position;
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            TextView tv;
            if (convertView == null) {
                tv = (TextView) LayoutInflater.from(mContext).inflate(
                        android.R.layout.simple_expandable_list_item_1, parent, false);
            } else {
                tv = (TextView) convertView;
            }
            tv.setText(mStrings[position]);
            return tv;
        }
    }

    protected void dialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setMessage(getString(R.string.save_program))
                .setTitle(getString(R.string.prompt))
                .setPositiveButton(getString(R.string.confirm), new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent();
                        intent.setClass(getApplicationContext(), EasyLinkActivity.class);
                        intent.putExtra("index", "setParam");
                        intent.putExtra("FUNC", func);
                        setResult(RESULT_OK, intent);
                        Log.e(TAG, "InputActivity FUNC:" + func);
                        dialog.dismiss();
                        SetConfigParamActivity.this.finish();
                    }
                });

        builder.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.create().show();
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
            dialog();
            return true;
        }
        return false;
    }

    private void showInputDialog(final String key, int maxLen){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Please Input");    //设置对话框标题
        builder.setIcon(android.R.drawable.btn_star);

        String val = configManager.getValueByTag(key, "");

        final EditText edit = new EditText(this);
        edit.setText(val);
        edit.setFilters( new InputFilter[]{new InputFilter.LengthFilter(maxLen) });
        builder.setView(edit);
        builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(SetConfigParamActivity.this, "input value: " + edit.getText().toString(), Toast.LENGTH_SHORT).show();
                configManager.saveTagValue(key,edit.getText().toString());
                cv.open();
            }
        });
        builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(SetConfigParamActivity.this, "cacel", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setCancelable(true);    //设置按钮是否可以按返回键取消,false则不可以取消
        AlertDialog dialog = builder.create();  //创建对话框
        dialog.setCanceledOnTouchOutside(true); //设置弹出框失去焦点是否隐藏,即点击屏蔽其它地方是否隐藏
        dialog.show();
    }

    private void  ShowChoise(final String[] value, final String key)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        //builder.setIcon(R.drawable.ic_launcher);
        builder.setTitle("please select");

        String val = configManager.getValueByTag(key, "1").substring(0,1);
        int checkItem = Integer.parseInt(val) - 1;

        //    设置一个下拉的列表选择项
        builder.setSingleChoiceItems(value,checkItem, new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                Toast.makeText(SetConfigParamActivity.this, "select：" + value[which], Toast.LENGTH_SHORT).show();
                configManager.saveTagValue(key, value[which]);
            }

        });
        builder.show();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent();
        intent.setClass(getApplicationContext(), EasyLinkActivity.class);
        intent.putExtra("index", "setParam");
        intent.putExtra("FUNC", func);
        setResult(RESULT_OK, intent);
        Log.e(TAG, "InputActivity FUNC:" + func);
        finish();
    }
}
