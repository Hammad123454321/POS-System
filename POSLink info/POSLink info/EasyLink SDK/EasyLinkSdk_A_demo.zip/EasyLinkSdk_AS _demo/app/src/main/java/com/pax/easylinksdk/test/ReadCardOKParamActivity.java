package com.pax.easylinksdk.test;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import com.pax.easylinksdk.test.manage.ConfigManager;
import com.pax.easylinksdk.test.utils.MyLog;
import com.pax.easylinksdk.test.utils.Tools;
import com.pax.gl.utils.impl.Convert;
import com.paxsz.easylink.model.DataModel;
import com.paxsz.easylink.model.TLVDataObject;
import com.paxsz.easylink.model.report.KeyParam;
import com.paxsz.easylink.model.report.TikKeyParam;

import java.util.ArrayList;

public class ReadCardOKParamActivity extends Activity implements View.OnClickListener {
    private static final String TAG = "ReadCardOKParamActivity";

    private TextView mTextView;
    private CheckBox setDataCb;
    private EditText setConfigTlvEdit;
    private EditText setEmvTlvEdit;
    private CheckBox writeKey1Cb;
    private CheckBox writeKey2Cb;

    private EditText srcKeyTypeEdit;
    private EditText srcKeyIndexEdit;
    private EditText dstKeyTypeEdit;
    private EditText dstKeyIndexEdit;
    private EditText dstKeyValueEdit;
    private EditText checkModeEdit;
    private EditText checkBufEdit;
    private EditText srcKeyTypeEdit1;
    private EditText srcKeyIndexEdit1;
    private EditText dstKeyTypeEdit1;
    private EditText dstKeyIndexEdit1;
    private EditText dstKeyValueEdit1;
    private EditText checkModeEdit1;
    private EditText checkBufEdit1;

    private CheckBox writeTikKeyCb;
    private EditText groupIndexEdit;
    private EditText tikSrcKeyIndexEdit;
    private EditText tikKeyValueEdit;
    private EditText ksnEdit;
    private EditText tikCheckeModeEdit;
    private EditText tikCheckBufEdit;

    private CheckBox newANullEmvAidParamCb;
    private CheckBox newANullICSParamCb;


    private Button mSkipBtn;
    private Button mSaveBtn;
    ConfigManager cfg;

    TimeCount mTimeCount;
    // timer Util
    /* 定义一个倒计时的内部类 */
    class TimeCount extends CountDownTimer {
        public TimeCount(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);// 参数依次为总时长,和计时的时间间隔
        }

        @Override
        public void onFinish() {// 计时完毕时触发
            processSetResult(null);
        }

        @Override
        public void onTick(long millisUntilFinished) {// 计时过程显示

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_readok_param);
        cfg = ConfigManager.getInstance(getApplicationContext());
        initView();
        processExtra();



    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void initView() {
        mTextView = findViewById(R.id.txt_report_tlvs);
        setDataCb = findViewById(R.id.cb_set_data);
        setConfigTlvEdit = findViewById(R.id.ed_set_config_tlv);
        setEmvTlvEdit = findViewById(R.id.ed_set_emv_tlv);
        setConfigTlvEdit.setText(cfg.getValueByTag("configTlvStr","020201010203010502040100"));
        setEmvTlvEdit.setText(cfg.getValueByTag("emvTlvStr","9f02060000000050009C0100"));
        writeKey1Cb = findViewById(R.id.cb_write_key_1);
        writeKey2Cb = findViewById(R.id.cb_write_key_2);
        srcKeyTypeEdit = findViewById(R.id.ed_src_key_type);
        srcKeyIndexEdit = findViewById(R.id.ed_src_key_index);
        dstKeyTypeEdit = findViewById(R.id.ed_dst_key_type);
        dstKeyIndexEdit  = findViewById(R.id.ed_dst_key_index);
        dstKeyValueEdit  = findViewById(R.id.ed_dst_key_value);
        checkModeEdit  = findViewById(R.id.ed_check_mode);
        checkBufEdit  = findViewById(R.id.ed_check_buf);
        srcKeyTypeEdit1  = findViewById(R.id.ed_src_key_type_1);
        srcKeyIndexEdit1  = findViewById(R.id.ed_src_key_index_1);
        dstKeyTypeEdit1  = findViewById(R.id.ed_dst_key_type_1);
        dstKeyIndexEdit1  = findViewById(R.id.ed_dst_key_index_1);
        dstKeyValueEdit1  = findViewById(R.id.ed_dst_key_value_1);
        checkModeEdit1  = findViewById(R.id.ed_check_mode_1);
        checkBufEdit1  = findViewById(R.id.ed_check_buf_1);

        writeTikKeyCb  = findViewById(R.id.cb_write_tik_key);
        groupIndexEdit  = findViewById(R.id.ed_group_index);
        tikSrcKeyIndexEdit  = findViewById(R.id.ed_tik_src_key_index);
        tikKeyValueEdit  = findViewById(R.id.ed_tik_key_value);
        ksnEdit = findViewById(R.id.ed_ksn);
        tikCheckeModeEdit  = findViewById(R.id.ed_tik_check_mode);
        tikCheckBufEdit  = findViewById(R.id.ed_tik_check_buf);
        newANullEmvAidParamCb = findViewById(R.id.cb_new_null_emvAidParam);
        newANullICSParamCb = findViewById(R.id.cb_new_null_icsParam);
        mSkipBtn = findViewById(R.id.btn_skip);
        mSaveBtn = findViewById(R.id.btn_save);
        mSkipBtn.setOnClickListener(this);
        mSaveBtn.setOnClickListener(this);

    }


    private void processExtra() {

        Bundle emvAidData = getIntent().getExtras();
        int timeout = emvAidData.getInt("timeout",30);
        ArrayList<TLVDataObject> configTLVs = emvAidData.getParcelableArrayList("configTlv");
        ArrayList<TLVDataObject> emvTLVs = emvAidData.getParcelableArrayList("emvTlv");
        StringBuilder configs = new StringBuilder("configTlv:\n");
        if (configTLVs != null && configTLVs.size() > 0) {
            for (TLVDataObject configTLV : configTLVs) {
                configs.append("tag:" + Tools.bcd2Str(configTLV.getTag()) + ", value:" + Tools.bcd2Str(configTLV.getValue()) + "\n");
            }
        }
        StringBuilder emvTLVStr = new StringBuilder("\nemvTLVs:\n");
        if (emvTLVs != null && emvTLVs.size() > 0) {
            for (TLVDataObject emvTLV : emvTLVs) {
                emvTLVStr.append("tag:" + Tools.bcd2Str(emvTLV.getTag()) + ", value:" + Tools.bcd2Str(emvTLV.getValue()) + "\n");
            }
        }
        mTextView.setText(configs.toString() + emvTLVStr.toString());
        mTimeCount = new TimeCount(timeout*1000,1000);
        mTimeCount.start();
    }

    @Override
    public void onBackPressed() {
        processSetResult(null);
        super.onBackPressed();
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btn_skip:
                processSetResult(null);
                break;
            case R.id.btn_save:
                processSave();
                break;
        }


    }

    private void processSave(){
        Bundle bundle = new Bundle();
        ArrayList<TLVDataObject> configTlvList = new ArrayList<>();
        ArrayList<TLVDataObject> emvTlvList = new ArrayList<>();
        if (setDataCb.isChecked()) {
            String configTlvStr = setConfigTlvEdit.getText().toString();
            if(!TextUtils.isEmpty(configTlvStr)){
                Log.w(TAG, "processSave: bcd.size="+ Convert.strToBcd(configTlvStr, Convert.EPaddingPosition.PADDING_RIGHT).length );
                configTlvList.addAll(Utils.unpackTLVs(DataModel.DataType.CONFIGURATION_DATA, Convert.strToBcd(configTlvStr, Convert.EPaddingPosition.PADDING_RIGHT)));
                for (TLVDataObject tlvDataObject : configTlvList) {
                    MyLog.i(TAG,"tag:" + Tools.bcd2Str(tlvDataObject.getTag()) + ", value:" + Tools.bcd2Str(tlvDataObject.getValue()));
                }
                bundle.putParcelableArrayList("configTlvList",configTlvList);
                cfg.saveTagValue("configTlvStr", configTlvStr);
            }
            String emvTlvStr = setEmvTlvEdit.getText().toString();
            if(!TextUtils.isEmpty(emvTlvStr)){
                emvTlvList.addAll(Utils.unpackTLVs(DataModel.DataType.TRANSACTION_DATA, Convert.strToBcd(emvTlvStr, Convert.EPaddingPosition.PADDING_RIGHT)));
                bundle.putParcelableArrayList("emvTlvList",emvTlvList);
                cfg.saveTagValue("emvTlvStr", emvTlvStr);
            }



        }else{
            bundle.putParcelableArrayList("configTlvList",null);
            bundle.putParcelableArrayList("emvTlvList",null);
        }

        KeyParam keyParam1 = new KeyParam();
        KeyParam keyParam2 = new KeyParam();

        if(writeKey1Cb.isChecked()){
            keyParam1.setSrcKeyIndex(TextUtils.isEmpty(srcKeyIndexEdit.getText().toString())?0:Integer.parseInt(srcKeyIndexEdit.getText().toString()));
            keyParam1.setSrcKeyType(TextUtils.isEmpty(srcKeyTypeEdit.getText().toString())? 0:Integer.parseInt(srcKeyTypeEdit.getText().toString()));
            keyParam1.setDstKeyType(TextUtils.isEmpty(dstKeyTypeEdit.getText().toString())? 0:Integer.parseInt(dstKeyTypeEdit.getText().toString()));
            keyParam1.setDstKeyIndex(TextUtils.isEmpty(dstKeyIndexEdit.getText().toString())? 0:Integer.parseInt(dstKeyIndexEdit.getText().toString()));
            if(!TextUtils.isEmpty(dstKeyValueEdit.getText().toString())){
                keyParam1.setDstKeyValue(Convert.strToBcd(dstKeyValueEdit.getText().toString(),Convert.EPaddingPosition.PADDING_RIGHT));
            }
            keyParam1.setCheckMode(TextUtils.isEmpty(checkModeEdit.getText().toString())? 0x00:(byte)Integer.parseInt(checkModeEdit.getText().toString()));
            if(!TextUtils.isEmpty(checkBufEdit.getText().toString())){
                keyParam1.setCheckBuf(Convert.strToBcd(checkBufEdit.getText().toString(),Convert.EPaddingPosition.PADDING_RIGHT));
            }
            bundle.putSerializable("writeKey1",keyParam1);
        }else{
            bundle.putSerializable("writeKey1",null);
        }
        if(writeKey2Cb.isChecked()){
            keyParam2.setSrcKeyIndex(TextUtils.isEmpty(srcKeyIndexEdit1.getText().toString())? 0:Integer.parseInt(srcKeyIndexEdit1.getText().toString()));
            keyParam2.setSrcKeyType(TextUtils.isEmpty(srcKeyTypeEdit1.getText().toString())? 0:Integer.parseInt(srcKeyTypeEdit1.getText().toString()));
            keyParam2.setDstKeyType(TextUtils.isEmpty(dstKeyTypeEdit1.getText().toString())? 0:Integer.parseInt(dstKeyTypeEdit1.getText().toString()));
            keyParam2.setDstKeyIndex(TextUtils.isEmpty(dstKeyIndexEdit1.getText().toString())? 0:Integer.parseInt(dstKeyIndexEdit1.getText().toString()));
            if(!TextUtils.isEmpty(dstKeyValueEdit1.getText().toString())){
                keyParam2.setDstKeyValue(Convert.strToBcd(dstKeyValueEdit1.getText().toString(),Convert.EPaddingPosition.PADDING_RIGHT));
            }
            keyParam2.setCheckMode(TextUtils.isEmpty(checkModeEdit1.getText().toString())? 0x00:(byte)Integer.parseInt(checkModeEdit1.getText().toString()));
            if(!TextUtils.isEmpty(checkBufEdit1.getText().toString())){
                keyParam2.setCheckBuf(Convert.strToBcd(checkBufEdit1.getText().toString(),Convert.EPaddingPosition.PADDING_RIGHT));
            }
            bundle.putSerializable("writeKey2",keyParam2);
        }else{
            bundle.putSerializable("writeKey2",null);
        }
        TikKeyParam tikKeyParam = new TikKeyParam();
        if(writeTikKeyCb.isChecked()){
            tikKeyParam.setGroupIndex(TextUtils.isEmpty(groupIndexEdit.getText().toString())? 0: Integer.parseInt(groupIndexEdit.getText().toString()));
            tikKeyParam.setSrcKeyIndex(TextUtils.isEmpty(tikSrcKeyIndexEdit.getText().toString())? 0:Integer.parseInt(tikSrcKeyIndexEdit.getText().toString()));
            if(!TextUtils.isEmpty(tikKeyValueEdit.getText().toString())){
                tikKeyParam.setKeyValue(Convert.strToBcd(tikKeyValueEdit.getText().toString(),Convert.EPaddingPosition.PADDING_RIGHT));
            }
            if(!TextUtils.isEmpty(ksnEdit.getText().toString())){
                tikKeyParam.setKsn(Convert.strToBcd(ksnEdit.getText().toString(),Convert.EPaddingPosition.PADDING_RIGHT));
            }
            tikKeyParam.setCheckMode(TextUtils.isEmpty(tikCheckeModeEdit.getText().toString())? 0x00:(byte)Integer.parseInt(tikCheckeModeEdit.getText().toString()));
            if(!TextUtils.isEmpty(tikCheckBufEdit.getText().toString())){
                tikKeyParam.setCheckBuf(Convert.strToBcd(tikCheckBufEdit.getText().toString(),Convert.EPaddingPosition.PADDING_RIGHT));
            }
            bundle.putSerializable("writeTikKey",tikKeyParam);
        }else{
            bundle.putSerializable("writeTikKey",null);
        }

        if(newANullICSParamCb.isChecked()){
            bundle.putBoolean("newANullICSParam",true);
        }
        if(newANullEmvAidParamCb.isChecked()){
            bundle.putBoolean("newANullEmvAidParam",true);
        }
        processSetResult(bundle);
    }


    private void processSetResult(Bundle bundle){
        Intent intent = new Intent(ReadCardOKParamActivity.this, EasyLinkActivity.class);
        if(bundle == null){
            bundle = new Bundle();
            bundle.putParcelableArrayList("configTlvList",null);
            bundle.putParcelableArrayList("emvTlvList",null);
            bundle.putSerializable("writeKey1",null);
            bundle.putSerializable("writeKey2",null);
            bundle.putSerializable("writeTikKey",null);
        }
        intent.putExtras(bundle);
        setResult(0, intent);
        finish();
        if (mTimeCount != null) {
            mTimeCount.cancel();
            mTimeCount = null;
        }
    }
}
