package com.pax.easylinksdk.test.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.pax.easylinksdk.test.R;
import com.pax.easylinksdk.test.TestApplication;
import com.paxsz.easylink.api.EasyLinkSdkManager;
import com.paxsz.easylink.device.DeviceInfo;
import com.paxsz.easylink.listener.IDeviceStateChangeListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhanzc on 2017/8/8.
 * 测试usb连接功能
 */

public class UsbActivity extends Activity implements View.OnClickListener {

    private TextView tv_progress;

    private ListView lv_bluetooth;
    private List<DeviceInfo> deviceInfos;
    private UsbAdapter adapter;

    private Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message message) {
            int ret = message.arg1;
            if (message.what == 0) {
                Toast.makeText(getApplicationContext(), "Usb Disconnect, ret = " + ret, Toast.LENGTH_SHORT).show();

            } else if (message.what == 1) {
                Toast.makeText(getApplicationContext(), "Usb connect, ret = " + ret, Toast.LENGTH_SHORT).show();
                TestApplication.manager.registerDisconnectStateListener(new IDeviceStateChangeListener() {
                    @Override
                    public void onDisconnect() {
                        Toast.makeText(UsbActivity.this, "USB has disconnect", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            return false;
        }
    });

    private UsbReceiver receiver;

    private class UsbReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (deviceInfos == null) {
                return;
            }

            if (adapter == null) {
                return;
            }
            deviceInfos.clear();
            deviceInfos.addAll(EasyLinkSdkManager.getInstance(UsbActivity.this).getUsbDevice());
            adapter.notifyDataSetChanged();
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usb);

        receiver = new UsbReceiver();
        IntentFilter filter = new IntentFilter("android.hardware.usb.action.USB_STATE");
        filter.addAction(Intent.ACTION_MEDIA_MOUNTED);
        filter.addAction(Intent.ACTION_MEDIA_UNMOUNTED);
        filter.addDataScheme("file");
        filter.setPriority(800);
        registerReceiver(receiver, filter);

        lv_bluetooth = (ListView) findViewById(R.id.lv_bluetooth);
        deviceInfos = new ArrayList<>();
        adapter = new UsbAdapter(this, deviceInfos);
        lv_bluetooth.setAdapter(adapter);
        lv_bluetooth.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int i, long l) {

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        int ret = TestApplication.manager.connect(deviceInfos.get(i));
                        Message message = Message.obtain();
                        message.arg1 = ret;
                        message.what = 1;
                        mHandler.sendMessage(message);
                    }
                }).start();


            }
        });

        tv_progress = (TextView) findViewById(R.id.tv_progress);
        findViewById(R.id.btn_search).setOnClickListener(this);


    }

    @Override
    protected void onDestroy() {
        // 观察者观察被观察者
        super.onDestroy();
        unregisterReceiver(receiver);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_search:
                tv_progress.setText("Search......");
                deviceInfos.clear();
                deviceInfos.addAll(EasyLinkSdkManager.getInstance(this).getUsbDevice());
                adapter.notifyDataSetChanged();
                break;
        }
    }


    private class UsbAdapter extends BaseAdapter {
        private Context context;
        private List<DeviceInfo> deviceList;

        public UsbAdapter(Context context, List<DeviceInfo> devices) {
            this.context = context;
            this.deviceList = devices;
        }

        @Override
        public int getCount() {
            return deviceList.size();
        }

        @Override
        public Object getItem(int i) {
            return deviceList.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                view = LayoutInflater.from(context).inflate(R.layout.item_bluetooth, null);
                viewHolder = new ViewHolder();
                viewHolder.tv_bluetooth = (TextView) view.findViewById(R.id.tv_bluetooth);
                view.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) view.getTag();
            }

            viewHolder.tv_bluetooth.setText(deviceList.get(i).getDeviceName() + "  Addr: " + deviceList.get(i).getIdentifier());

            return view;
        }
    }

    private ViewHolder viewHolder;

    private static class ViewHolder {
        TextView tv_bluetooth;
    }
}
