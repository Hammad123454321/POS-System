package com.pax.easylinksdk.test;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.pax.gl.commhelper.impl.GLCommDebug;
import com.paxsz.easylink.api.EasyLinkSdkManager;

import pax.ecr.protocol.api.Debug;


public class MainActivity extends ListActivity {

	private String[] mStrings = {
			"1.EasyLink",
			"2.Version",
	};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);


		TextView tv = (TextView) findViewById(R.id.list_title);
		tv.setText(getString(R.string.dxx_test));

		EasyLinkSdkManager.getInstance(this).setDebugMode(true);
		Debug.setDebugLevel(Debug.EDebugLevel.DEBUG_LEVEL_NONE);
		GLCommDebug.setDebugLevel(GLCommDebug.EDebugLevel.DEBUG_LEVEL_NONE);

		setListAdapter(new MainListAdapter(this));
		findViewById(R.id.btn_easy_link).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				// 跳到功能测试列表界面(新界面)
				Intent intent = new Intent(MainActivity.this, ConfigActivity.class);
			intent.putExtra("Module", "Config");
				startActivity(intent);
			}
		});
    }

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		// TODO Auto-generated method stub
    	Intent intent;
    	switch (position) {
		case 0:	//EasyLink
			intent = new Intent(MainActivity.this, InterfaceActivity.class);
			intent.putExtra("Module", "EasyLink");
			break;
		case 1:	//CommConfig
			intent = new Intent(MainActivity.this, VersionActivity.class);
			break;
		default:
			return;
    	}

		startActivity(intent);
	}

	private class MainListAdapter extends BaseAdapter {
    	private Context mContext;
    	
        public MainListAdapter(Context context) {
            mContext = context;
        }

        public int getCount() {
            return mStrings.length;
        }

        @Override
        public boolean areAllItemsEnabled() {
            return false;
        }

        @Override
        public boolean isEnabled(int position) {
            return !mStrings[position].startsWith("-");
        }

        public Object getItem(int position) {
            return position;
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            TextView tv;
            if (convertView == null) {
                tv = (TextView) LayoutInflater.from(mContext).inflate(
                		android.R.layout.simple_expandable_list_item_1, parent, false);
            } else {
                tv = (TextView) convertView;
            }
            tv.setText(mStrings[position]);
            return tv;
        }
    }

    protected void dialog() {
		AlertDialog.Builder builder = new Builder(this)
			.setMessage(getString(R.string.exit_program))
			.setTitle(getString(R.string.prompt))
			.setPositiveButton(getString(R.string.confirm), new OnClickListener() {
		
		   @Override
		   public void onClick(DialogInterface dialog, int which) {
			   
			    dialog.dismiss();
				EasyLinkSdkManager.getInstance(MainActivity.this).disconnect();
			    MainActivity.this.finish();
			    //ActivityManager.getInstance().exit(MainActivity.class);
		   }
		  });
		
		  builder.setNegativeButton(getString(R.string.cancel), new OnClickListener() {
		
		   @Override
		   public void onClick(DialogInterface dialog, int which) {
			   dialog.dismiss();
		   }
		  });

		  builder.create().show();
    }

	public boolean onKeyDown(int keyCode, KeyEvent event) {

		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			dialog();
			return true;
		}
		return false;
	}
}
