package com.pax.easylinksdk.test;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.paxsz.easylink.api.EasyLinkSdkManager;
import com.paxsz.easylink.device.DeviceInfo;


public class InterfaceActivity extends ListActivity {

    private String mModule;
    private String[] mEasyLink = {
            "1.connect",
            "2.disconnect",
            "3.startTransaction",
            "4.completeTransaction",
            "5.getPinBlock",
            "6.encryptData",
            "7.setData",
            "8.getData",
            "9.showPage",
            "10.fileDownLoad",
            "11.switchCommMode",
            "12.EMV",
            "13.searchDevices",
            "14.cancelFileDownload",
            "15.calcMac",
            "16.IncreaseKSN",
            "17.DownLoadExtFile",
            "18.isConnect",
            "19.WriteKey",
            "20.getConnectedDevice",
            "21.RKI",
            "22.GetKeyInfo"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();
        mModule = intent.getStringExtra("Module");

        TextView tv = (TextView) findViewById(R.id.list_title);
        tv.setText(mModule);

        if (mModule.equals("EasyLink")) {
            setListAdapter(new MainListAdapter(this, mEasyLink));
        }
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        Intent intent;

        intent = new Intent(InterfaceActivity.this, FunctionActivity.class);
        intent.putExtra("Module", mModule);

        if (mModule.equals("EasyLink")) {
            switch (position) {

                case 0:
                    intent.putExtra("Interface", "connect");
                    intent.putExtra("FuncNum", "connect");
                    break;
                case 1:
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            final int disConnRet = EasyLinkSdkManager.getInstance(InterfaceActivity.this).disconnect();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(InterfaceActivity.this, "disconnect " + ((disConnRet == 0) ? "success" : "failed"), Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }).start();
                    return;
                case 2:
                    intent.putExtra("Interface", "startTransaction");
                    intent.putExtra("FuncNum", "startTransaction");
                    break;
                case 3:
                    intent.putExtra("Interface", "completeTransaction");
                    intent.putExtra("FuncNum", "completeTransaction");
                    break;
                case 4:
                    intent.putExtra("Interface", "getPinBlock");
                    intent.putExtra("FuncNum", "getPinBlock");
                    break;
                case 5:
                    intent.putExtra("Interface", "encryptData");
                    intent.putExtra("FuncNum", "encryptData");
                    break;
                case 6:
                    intent.putExtra("Interface", "setData");
                    intent.putExtra("FuncNum", "setData");
                    break;
                case 7:
                    intent.putExtra("Interface", "getData");
                    intent.putExtra("FuncNum", "getData");
                    break;
                case 8:
                    intent.putExtra("Interface", "showPage");
                    intent.putExtra("FuncNum", "showPage");
                    break;
                case 9:
                    intent.putExtra("Interface", "fileDownLoad");
                    intent.putExtra("FuncNum", "fileDownLoad");
                    break;
                case 10:
                    intent.putExtra("Interface", "switchCommMode");
                    intent.putExtra("FuncNum", "switchCommMode");
                    break;
                case 11:
                    intent.putExtra("Interface", "EMV");
                    intent.putExtra("FuncNum", "EMV");
                    break;
                case 12:
//                    intent.putExtra("Interface", "searchDevices");
//                    intent.putExtra("FuncNum", "searchDevices");
//                    break;
                    return;

                case 13:
                    intent.putExtra("Interface", "cancelFileDownload");
                    intent.putExtra("FuncNum", "cancelFileDownload");
                    break;
                case 14:
                    intent.putExtra("Interface", "calcMac");
                    intent.putExtra("FuncNum", "calcMac");
                    break;
                case 15:
                    intent.putExtra("Interface", "IncreaseKsn");
                    intent.putExtra("FuncNum", "IncreaseKsn");
                    break;
                case 16:
                    intent.putExtra("Interface", "DownLoadExtFile");
                    intent.putExtra("FuncNum", "DownLoadExtFile");
                    break;
                case 17:
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            final boolean isConnected = EasyLinkSdkManager.getInstance(InterfaceActivity.this).isConnected();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(InterfaceActivity.this, "isConnected=" + isConnected, Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }).start();
                    return;
                case 18:
                    intent.putExtra("Interface", "WriteKey");
                    intent.putExtra("FuncNum", "WriteKey");
                    break;
                case 19:
                    DeviceInfo connectedDev = EasyLinkSdkManager.getInstance(InterfaceActivity.this).getConnectedDevice();
                    if (connectedDev == null) {
                        return;
                    }
                    DeviceInfo.CommType commType = connectedDev.getCommType();
                    String addr = "";
                    if (commType == DeviceInfo.CommType.BLUETOOTH || commType == DeviceInfo.CommType.BLUETOOTH) {
                        addr = connectedDev.getIdentifier();
                    } else if (commType == DeviceInfo.CommType.USB) {
                        addr = connectedDev.getProductId() + "," + connectedDev.getVendorId();
                    } else if (commType == DeviceInfo.CommType.TCP) {
                        addr = connectedDev.getIp() + ":" + connectedDev.getPort();

                    } else {

                    }
                    String msg = "connectType:" + connectedDev.getCommType().name() + "\ndeviceName:" + connectedDev.getDeviceName() + "\n Other Info:" + addr;
                    new AlertDialog.Builder(InterfaceActivity.this).setTitle("Connected Device Info").setMessage(msg).setCancelable(false).setPositiveButton("OK", null).create().show();
                    return;
                case 20:
                    intent = new Intent(this, RKIFuncActivity.class);
                    break;
                case 21:
                    intent.putExtra("Interface", "GetKeyInfo");
                    intent.putExtra("FuncNum", "GetKeyInfo");
                    break;
                default:
                    return;
            }
        } else {
            return;
        }

        startActivity(intent);
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
        }
        return false;
    }

    private class MainListAdapter extends BaseAdapter {
        private Context mContext;
        private String[] mStrings;

        public MainListAdapter(Context context, String[] strAry) {
            mContext = context;
            mStrings = strAry;
        }

        public int getCount() {
            return mStrings.length;
        }

        @Override
        public boolean areAllItemsEnabled() {
            return false;
        }

        @Override
        public boolean isEnabled(int position) {
            return !mStrings[position].startsWith("-");
        }

        public Object getItem(int position) {
            return position;
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            TextView tv;
            if (convertView == null) {
                tv = (TextView) LayoutInflater.from(mContext).inflate(
                        android.R.layout.simple_expandable_list_item_1, parent, false);
            } else {
                tv = (TextView) convertView;
            }
            tv.setText(mStrings[position]);
            return tv;
        }
    }
}
