package com.pax.easylinksdk.test;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pax.gl.utils.impl.Convert;
import com.pax.easylinksdk.test.utils.Tools;
import com.paxsz.easylink.api.EasyLinkSdkManager;
import com.paxsz.easylink.model.DataModel;
import com.paxsz.easylink.model.KcvInfo;
import com.paxsz.easylink.model.TLVDataObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;


public class VersionActivity extends Activity {
    private static final String TAG = "VersionActivity";
    private TextView mTextView;
    private LinearLayout mLayout;
    EasyLinkSdkManager easyLink = EasyLinkSdkManager.getInstance(VersionActivity.this);
    String termInfo = "Terminal Info:\n";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_version);
        mLayout = new LinearLayout(this);//�������Բ���
        mTextView = new TextView(this);//����һ��TextView
//		mTextView.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT));//���ÿ��
        //Utils.unpackTLVs(DataModel.DataType.TRANSACTION_DATA, Convert.strToBcd("9f020600000000000000", Convert.EPaddingPosition.PADDING_RIGHT));
        getVersinInfo();

//        test3();

//        testPackJson();
//        testGson();
//        testSetData();
        mTextView.setTextSize(20);//�����С
        //	mTextView.setBackgroundColor(Color.BLUE);//���ñ�����ɫ
        mTextView.setGravity(Gravity.CENTER);//����
        mTextView.setPadding(0, 20, 0, 0);//left,top,right,buttom
        mLayout.addView(mTextView);//����ͼ��ӵ�������

        setContentView(mLayout);



    }

//    private void testGson(){
//        ArrayList<BaseRunCmdModel> baseRunCmdModels = new ArrayList<>();
//        baseRunCmdModels.add(new BaseRunCmdModel());
//        BaseRunCmdModel baseRunCmdModel = new BaseRunCmdModel();
//        baseRunCmdModel.setCmd("cmd");
//        baseRunCmdModels.add(baseRunCmdModel);
//        baseRunCmdModels.add(new SetDataModel());
//        baseRunCmdModels.add(new WriteKeyModel());
//        baseRunCmdModels.add(new SetEmvAidParamModel(new EmvAidParam()));
//        baseRunCmdModels.add(new SetICSParamModel(new ICSParam()));
//        Gson nullableGson = new GsonBuilder()
//                .enableComplexMapKeySerialization()
//                .serializeNulls()
//                .create();
//        Log.e(TAG, "testGson1: "+nullableGson.toJson(baseRunCmdModels) );
//        RunCmdListResponse runCmdListResponse = new RunCmdListResponse();
//        runCmdListResponse.setCmdList(baseRunCmdModels);
//        Log.w(TAG, "testGson2: "+nullableGson.toJson(runCmdListResponse) );
//        ReportResponse<RunCmdListResponse> response = new ReportResponse();
//        response.setCurrentStatus("waitCmd");
//        response.setJsonData(runCmdListResponse);
//        Log.i(TAG, "testGson3: "+nullableGson.toJson(response));
//
//
////        RunCmdResponse runCmdResponse = new RunCmdResponse();
////        runCmdResponse.setCmdList(nullableGson.toJson(baseRunCmdModels));
////        ReportResponse<RunCmdResponse> response2 = new ReportResponse();
////        response2.setCurrentStatus("waitCmd");
////        response2.setJsonData(runCmdResponse);
////        Log.i(TAG, "testGson4: "+nullableGson.toJson(response2));
////
////        ReportResponse<String> response3 = new ReportResponse();
////        response3.setCurrentStatus("waitCmd");
////        response3.setJsonData("cmdList:"+nullableGson.toJson(baseRunCmdModels));
////        Log.i(TAG, "testGson5: "+nullableGson.toJson(response3));
////
////
////        RunCmdListResponse2 runCmdListResponse1 = new RunCmdListResponse2();
////        runCmdListResponse1.setCmdList(baseRunCmdModels);
////        Log.w(TAG, "testGson2: "+nullableGson.toJson(runCmdListResponse1) );
////        ReportResponse<RunCmdListResponse> response4 = new ReportResponse();
////        response4.setCurrentStatus("waitCmd");
////        response4.setJsonData(runCmdListResponse);
////        Log.i(TAG, "testGson6: "+nullableGson.toJson(response4));
//
//    }


    private void getVersinInfo() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final List<TLVDataObject> list = new ArrayList<>();
                final List<byte[]> versionTagList = new ArrayList<>();
                versionTagList.add(new byte[]{(byte) 0x01, 0x18});
                versionTagList.add(new byte[]{(byte) 0x01, 0x19});
                versionTagList.add(new byte[]{(byte) 0x01, 0x26});
                versionTagList.add(new byte[]{(byte) 0x01, 0x27});
                int ret = easyLink.getData(DataModel.DataType.CONFIGURATION_DATA, versionTagList, list);
                if (ret == 0) {
                    int widgetNum = list.size();
                    Log.d(TAG, "tagsize: " + widgetNum);
                    for (int i = 0; i < widgetNum; i++) {
                        Log.i(TAG, "tag: " + Tools.bcd2Str(list.get(i).getTag()) + ", value:" + new String(list.get(i).getValue()));
                        termInfo = termInfo + new String(list.get(i).getValue()) + " ";

                    }
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mTextView.setText("SDK Version:\n" + easyLink.getVersionName() + "\n\n" + termInfo
                        );
                    }
                });


            }
        }).start();
    }


    private void test2() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "EasyLink is connected:" + easyLink.isConnected());
                byte groupIdx = 3;
                byte srcKeyIdx = 0;
                byte[] keyValueIn = Convert.strToBcd("A45CD2F44A41A46D24CD129E39BF267A", Convert.EPaddingPosition.PADDING_RIGHT);
                byte[] ksnIn = Convert.strToBcd("7B83FF54020406E00000", Convert.EPaddingPosition.PADDING_RIGHT);
                KcvInfo kcvInfoIn = new KcvInfo();
                int iResponse = easyLink.writeTIK(groupIdx, srcKeyIdx, keyValueIn, ksnIn, kcvInfoIn, 10);
                Log.d(TAG, "writeTIK response:" + iResponse);

                ArrayList<TLVDataObject> list = new ArrayList<>();
                TLVDataObject MACkeyIndex = new TLVDataObject(new byte[]{0x02, 0x10}, new byte[]{groupIdx});
                list.add(MACkeyIndex);
                TLVDataObject MACcalcType = new TLVDataObject(new byte[]{0x02, 0x12}, new byte[]{0x02}); // 2 = TIK
                list.add(MACcalcType);

                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                iResponse = easyLink.setData(DataModel.DataType.CONFIGURATION_DATA, list, byteArrayOutputStream);
                Log.d(TAG, "setData response:" + iResponse);

                List<TLVDataObject> checkList = new ArrayList<>();
                List<byte[]> mTags = new ArrayList<>();
                mTags.add(new byte[]{0x02, 0x10});
                mTags.add(new byte[]{0x02, 0x12});
                iResponse = easyLink.getData(DataModel.DataType.CONFIGURATION_DATA, mTags, checkList);
                Log.d(TAG, "getData response:" + iResponse);
                TLVDataObject tTlvObj;
                for (int ix = 0; ix < checkList.size(); ix++) {
                    tTlvObj = checkList.get(ix);
                    Log.d(TAG, "TAG:" + Convert.bcdToStr(tTlvObj.getTag()) + " Len:" + tTlvObj.getLength() + " Value:" + Convert.bcdToStr(tTlvObj.getValue()));
                }

                byte[] testData = Convert.strToBcd("This is test data for MAC", Convert.EPaddingPosition.PADDING_RIGHT);
                Log.d(TAG, "testData:" + Convert.bcdToStr(testData));
                ByteArrayOutputStream macOutput = new ByteArrayOutputStream();
                iResponse = easyLink.calcMAC(testData, macOutput);
                Log.d(TAG, "calcMAC:" + iResponse);
            }
        }).start();


    }

    private void testSetData(){//len>40   before version 20190107, this is a bug
        new Thread(new Runnable() {
            @Override
            public void run() {
                List<TLVDataObject> list = new ArrayList<>();
                String testStr = "031B031C030403050306031A030702020203020402050206020702080209031B031C030403050306";//40
//                String testStr = "031B031C030403050306031A030702020203020402050206020702080209";//30
                Log.i(TAG, "run: testStr.len="+testStr.length() + "\n"+testStr);
                list.add(new TLVDataObject(new byte[]{(byte)0x02,0x19}, Convert.strToBcd(testStr, Convert.EPaddingPosition.PADDING_RIGHT)));
                int test = easyLink.setData(DataModel.DataType.CONFIGURATION_DATA, list, new ByteArrayOutputStream());
                Log.d(TAG, "setData test(len>40) : " + test );
            }
        }).start();

    }


    private void test3() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                ByteArrayOutputStream outStream = new ByteArrayOutputStream();
                TLVDataObject configTlv = new TLVDataObject();
                configTlv.setTag(new byte[]{0x02, 0x19});
                configTlv.setValue(new byte[]{0x03, 0x1B, 0x03, 0x1C, 0x03, 0x04, 0x03, 0x05, 0x03, 0x06, 0x03, 0x1A, 0x03, 0x07});

                TLVDataObject emvTlv = new TLVDataObject();
                emvTlv.setTag(new byte[]{0x02, 0x1A});
                emvTlv.setValue(new byte[]{0x4F, 0x5A});

                ArrayList<TLVDataObject> setDataLists = new ArrayList<>();
                setDataLists.add(configTlv);
//				setDataLists.add(emvTlv);

                int ret = EasyLinkSdkManager.getInstance(VersionActivity.this).setData(DataModel.DataType.CONFIGURATION_DATA, setDataLists, outStream);
                Log.d(TAG, "set tag:0219 =" + ret);

                List<byte[]> tagList = new ArrayList<>();
                tagList.add(new byte[]{0x02,0x19});
//                tagList.add(new byte[]{0x02,0x1A});
//                tagList.add(new byte[]{0x03,0x05});
                List<TLVDataObject> resultList = new ArrayList<>();
                ret = EasyLinkSdkManager.getInstance(VersionActivity.this).getData(DataModel.DataType.CONFIGURATION_DATA, tagList,resultList );
                Log.d(TAG, "get tag:0219, 021A=" + ret);
                for (int i = 0; i < resultList.size(); i++) {
                    Log.d(TAG, "get tag:" +Convert.bcdToStr(resultList.get(i).getTag())+", value:"+Convert.bcdToStr(resultList.get(i).getValue()));
                }

//                byte[] configTlvData = new byte[]{0x02, 0x19, 0x0E, 0x03, 0x1B, 0x03, 0x1C, 0x03, 0x04, 0x03, 0x05, 0x03, 0x06, 0x03, 0x1A, 0x03, 0x07};//0219 tag + len + value
//                int setRet = EasyLinkSdkManager.getInstance(VersionActivity.this).setData(DataModel.DataType.CONFIGURATION_DATA, configTlvData, outStream);
//                Log.d(TAG, "set config Data, ret=" + setRet);
//
//                byte[] emvTlvData = new byte[]{0x02,0x1A, 0x02, 0x4F,0x5A};//021A tag + len + value
//                setRet = EasyLinkSdkManager.getInstance(VersionActivity.this).setData(DataModel.DataType.CONFIGURATION_DATA, emvTlvData, outStream);
//                Log.d(TAG, "set emv Data, ret=" + setRet);
//
//                List<byte[]> tagList = new ArrayList<>();
//                tagList.add(new byte[]{0x02,0x19});
//                tagList.add(new byte[]{0x02,0x1A});
//                tagList.add(new byte[]{0x03,0x05});
//                List<TLVDataObject> resultList = new ArrayList<>();
//                ret = EasyLinkSdkManager.getInstance(VersionActivity.this).getData(DataModel.DataType.CONFIGURATION_DATA, tagList,resultList );
//                Log.d(TAG, "get tag:0219, 021A=" + ret);
//                for (int i = 0; i < resultList.size(); i++) {
//                    Log.d(TAG, "get tag:" +Convert.bcdToStr(resultList.get(i).getTag())+", value:"+Convert.bcdToStr(resultList.get(i).getValue()));
//                }


//				List<TLVDataObject> list1 = new ArrayList<>();
//				list1.add(new TLVDataObject(new byte[]{0x02,0x19}, Convert.strToBcd("031B031C030403050306031A0307", Convert.EPaddingPosition.PADDING_RIGHT)));
//				list1.add(new TLVDataObject(new byte[]{0x02,0x09}, Convert.strToBcd("01", Convert.EPaddingPosition.PADDING_RIGHT)));
//				int test = easyLink.setData(DataModel.DataType.CONFIGURATION_DATA, list1, new ByteArrayOutputStream());
//				Log.d(TAG, "test: " + test );

				List<TLVDataObject> list4 = new ArrayList<>();
				list4.add(new TLVDataObject(new byte[]{0x02,0x19}, Convert.strToBcd("031B031C030403050306031A030702020203020402050206020702080209031B031C030403050306031A030702020203020402050206020702080209031B031C030403050306031A030702020203020402050206020702080209031B031C030403050306031A03070202020302040205020602070208020902020203020402050206020702080209", Convert.EPaddingPosition.PADDING_RIGHT)));
				int test4 = easyLink.setData(DataModel.DataType.CONFIGURATION_DATA, list4, new ByteArrayOutputStream());
				Log.d(TAG, "setData test4 : " + test4 );

                List<byte[]> list44 = new ArrayList<>();
                list44.add(new byte[]{0x02,0x19});
                List<TLVDataObject> resultTlvList = new ArrayList<>();
                int test44 = easyLink.getData(DataModel.DataType.CONFIGURATION_DATA, list44,resultTlvList);
                Log.d(TAG, "getData test44 : " + test44 );
                for (TLVDataObject tlvDataObject : resultTlvList) {
                    Log.d(TAG, "get tag:" +Convert.bcdToStr(tlvDataObject.getTag())+", value:"+Convert.bcdToStr(tlvDataObject.getValue()));

                }

                List<TLVDataObject> list6 = new ArrayList<>();
                String testStr = "031B031C030403050306031A030702020203020402050206020702080209031B031C030403050306031A030702020203020402050206020702080209031B031C030403050306031A030702020203020402050206020702080209031B031C030403050306031A03070202020302040205020602070208020902020203020402050206020702080209"+"031B031C030403050306031A030702020203020402050206020702080209031B031C030403050306031A030702020203020402050206020702080209031B031C030403050306031A030702020203020402050206020702080209031B031C030403050306031A03070202020302040205020602070208020902020203020402050206020702080209"+
                        "031B031C030403050306031A030702020203020402050206020702080209031B031C030403050306031A030702020203020402050206020702080209031B031C030403050306031A030702020203020402050206020702080209031B031C030403050306031A03070202020302040205020602070208020902020203020402050206020702080209"+"031B031C030403050306031A030702020203020402050206020702080209031B031C030403050306031A030702020203020402050206020702080209031B031C030403050306031A030702020203020402050206020702080209031B031C030403050306031A03070202020302040205020602070208020902020203020402050206020702080209";
                testStr = testStr+testStr;
                Log.i(TAG, "run: testStr.len="+testStr.length() + "\n"+testStr);
                list6.add(new TLVDataObject(new byte[]{0x02,0x19}, Convert.strToBcd(testStr, Convert.EPaddingPosition.PADDING_RIGHT)));
                int test6 = easyLink.setData(DataModel.DataType.CONFIGURATION_DATA, list6, new ByteArrayOutputStream());
                Log.d(TAG, "setData test6 : " + test6 );

                List<byte[]> tagList1 = new ArrayList<>();
                tagList1.add(new byte[]{0x02,0x19});
                List<TLVDataObject> resultList1 = new ArrayList<>();
                ret = EasyLinkSdkManager.getInstance(VersionActivity.this).getData(DataModel.DataType.CONFIGURATION_DATA, tagList1,resultList1 );
                Log.d(TAG, "get tag:0219, 021A=" + ret);
                for (int i = 0; i < resultList1.size(); i++) {
                    Log.d(TAG, "get tag:" +Convert.bcdToStr(resultList1.get(i).getTag())+", value:"+Convert.bcdToStr(resultList1.get(i).getValue()));
                }

//				List<TLVDataObject> list2 = new ArrayList<>();
//				list2.add(new TLVDataObject(new byte[]{0x02,0x1A}, Convert.strToBcd("4F5A", Convert.EPaddingPosition.PADDING_RIGHT)));
//				int test2 = easyLink.setData(DataModel.DataType.CONFIGURATION_DATA, list2, new ByteArrayOutputStream());
//				Log.d(TAG, "test2: " + test2 );
//
//				List<TLVDataObject> list3 = new ArrayList<>();
//				list3.add(new TLVDataObject(new byte[]{0x02,0x1A}, Convert.strToBcd("4F5A9F12505F205F30579C", Convert.EPaddingPosition.PADDING_RIGHT)));
//				int test3 = easyLink.setData(DataModel.DataType.CONFIGURATION_DATA, list3, new ByteArrayOutputStream());
//				Log.d(TAG, "test3: " + test3 );
//
//				List<TLVDataObject> list5 = new ArrayList<>();
//				list5.add(new TLVDataObject(new byte[]{0x02,0x1A}, Convert.strToBcd("4F5A9F12505F205F30579C4F5A9F12505F205F30579C4F5A9F12505F205F30579C4F5A9F12505F205F30579C4F5A9F12505F205F30579C4F5A9F12505F205F30579C4F5A9F12505F205F30579C4F5A9F12505F205F30579C4F5A9F12505F205F30579C4F5A9F12505F205F30579C4F5A9F12505F205F30579C4F5A9F12505F205F30579C", Convert.EPaddingPosition.PADDING_LEFT)));
//				int test5 = easyLink.setData(DataModel.DataType.CONFIGURATION_DATA, list5, new ByteArrayOutputStream());
//				Log.d(TAG, "test5: " + test5 );
            }
        }).start();
    }




}
