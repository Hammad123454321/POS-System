package com.pax.easylinksdk.test.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.pax.easylinksdk.test.R;


/**
 * Created by zhanzc on 2017/8/8.
 * 测试结果界面
 */

public class TestResultActivity extends Activity {
    public static final String KEY_RESULT = "result";
    private TextView tv_result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        tv_result = (TextView) findViewById(R.id.tv_result);

        String result = getIntent().getStringExtra(KEY_RESULT);
        tv_result.setText(result);
    }
}
