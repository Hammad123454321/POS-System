package com.pax.easylink.test.tab.fragment;

import android.view.View;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.example.easylink.R;
import com.pax.easylink.test.constant.UIParamKeys;
import com.pax.easylink.test.sale.model.ReportDataList;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.Bind;

/**
 * Created by lixc on 2017/6/22.
 */

public class ReportFragment extends BaseFragment {

    @Bind(R.id.title)
    TextView title;
    @Bind(R.id.reportList)
    ListView reportList;

    private ReportDataList reportDataList;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_report;
    }

    @Override
    protected void initData() {
        reportDataList = ReportDataList.getInstance();
    }

    @Override
    protected void initView(View view) {
        title.setText(getString(R.string.title_report));
        updateReportList();
    }

    private void updateReportList() {
        List<Map<String, Object>> reportListItems = new ArrayList<>();
        for (int i = reportDataList.getCount() - 1; i >= 0; i--) {
            Map<String, Object> map = new HashMap<>();
            map.put(UIParamKeys.SHOP.toString(), reportDataList.getData(i).getShopname());
            map.put(UIParamKeys.IMAGE.toString(), reportDataList.getData(i).getImage());
            map.put(UIParamKeys.TITLE.toString(), reportDataList.getData(i).getTitle());
            map.put(UIParamKeys.SUBTITLE.toString(), reportDataList.getData(i).getSubtitle());
            map.put(UIParamKeys.TIME.toString(), reportDataList.getData(i).getTranstime());

            if (reportDataList.getData(i).getCount() == 1) {
                map.put(UIParamKeys.COUNT.toString(), "A total of a commodity");
            } else {
                map.put(UIParamKeys.COUNT.toString(), "A total of " + reportDataList.getData(i).getCount() + " pieces of goods");
            }

            DecimalFormat decimalFormat = new DecimalFormat("#####0.00");
            String moneyFormat = decimalFormat.format((reportDataList.getData(i).getMoney())
                    * (reportDataList.getData(i).getCount()));
            map.put(UIParamKeys.MONEY.toString(), moneyFormat);
            reportListItems.add(map);
        }
        SimpleAdapter adapter = new SimpleAdapter(getContext(), reportListItems, R.layout.report_list_items,
                new String[]{UIParamKeys.SHOP.toString(), UIParamKeys.IMAGE.toString(),
                        UIParamKeys.TITLE.toString(), UIParamKeys.SUBTITLE.toString(),
                        UIParamKeys.TIME.toString(), UIParamKeys.COUNT.toString(), UIParamKeys.MONEY.toString()},
                new int[]{R.id.shop, R.id.reportListImage, R.id.reportListTitle, R.id.reportListSubtitle, R.id.reportListTime, R.id.reportListNumber, R.id.reportListMoney});
        reportList.setAdapter(adapter);
    }
}
