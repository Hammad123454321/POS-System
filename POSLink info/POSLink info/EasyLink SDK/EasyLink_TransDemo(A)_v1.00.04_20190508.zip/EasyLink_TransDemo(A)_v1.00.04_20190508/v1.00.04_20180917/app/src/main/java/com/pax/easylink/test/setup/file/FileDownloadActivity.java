package com.pax.easylink.test.setup.file;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.easylink.R;
import com.pax.easylink.test.app.FinancialApplication;
import com.pax.easylink.test.event.ResultEvent;
import com.pax.easylink.test.utils.Convert;
import com.pax.easylink.test.utils.Dialog;
import com.pax.easylink.test.utils.Snackbar;
import com.pax.easylink.test.utils.ZipControl;
import com.paxsz.easylink.api.ResponseCode;
import com.paxsz.easylink.listener.FileDownloadListener;
import com.paxsz.easylink.model.DataModel;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by lixc
 * file download
 */

public class FileDownloadActivity extends AppCompatActivity {

    @Bind(R.id.uiLayout)
    LinearLayout uiLayout;
    @Bind(R.id.uiFile)
    TextView uiFile;
    @Bind(R.id.clssFile)
    TextView clssFile;
    @Bind(R.id.emvFile)
    TextView emvFile;
    @Bind(R.id.uiCheckBox)
    CheckBox uiCheckBox;
    @Bind(R.id.clssCheckBox)
    CheckBox clssCheckBox;
    @Bind(R.id.emvCheckBox)
    CheckBox emvCheckBox;
    @Bind(R.id.downloadButton)
    Button downloadButton;

    private static final String TAG = "FileDownloadActivity";
    private Context context;
    private AlertDialog alert;
    private boolean isCanceled = false;
    private int fileCount = 0;
    private String uiFileName;


    private static final String[][] TERMINAL_TYPE_UI = {
            {"23", "ui_d180.ui"},
            {"D180", "ui_d180.ui"},
            {"D200", "ui_d200.ui"},
            {"D220", "ui_d220.ui"},
            {"Q20", "ui_q20.ui"},
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_download);
        ButterKnife.bind(this);
        FinancialApplication.getApp().register(this);

        init();
    }

    private void init() {
        context = FileDownloadActivity.this;
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(getResources().getString(R.string.title_file_download));
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        uiFileName = selectUiFile(getTermType());
        if (uiFileName != null) {
            uiFile.setText(uiFileName);
        } else {
            uiLayout.setVisibility(View.GONE);
        }
        FinancialApplication.getApp().runInBackground(FileDownloadActivity.this::copyFile);
    }

    private String getTermType() {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        int ret = FinancialApplication.getEasyLinkSdkManager().getData(DataModel.DataType.CONFIGURATION_DATA,
                new byte[]{(byte) 0x01, 0x02}, byteArrayOutputStream);
        if (ret != ResponseCode.EL_RET_OK) {
            return null;
        }

//        Log.i(TAG, "termType TLV: " + Convert.byte2Str(byteArrayOutputStream.toByteArray(), 0));
//        Log.i(TAG, "termType TLV: " + Convert.bcdToStr(byteArrayOutputStream.toByteArray()));

        if (byteArrayOutputStream != null && byteArrayOutputStream.toByteArray().length > 4) {

            if (byteArrayOutputStream.toByteArray()[4] != 0) {
                if (byteArrayOutputStream.toByteArray()[4] == 0x01 && byteArrayOutputStream.toByteArray()[5] == 0x23) {
                    return "D180";
                } else {
                    return Convert.byte2Str(byteArrayOutputStream.toByteArray(), 5);
                }
            }
        }

        return null;
    }

    @SuppressWarnings("unused")
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(ResultEvent event) {
        switch ((ResultEvent.Status) event.getStatus()) {
            case DOWNLOAD_SUCCESS:
                updateChecked();
                disDownloadResult(getString(R.string.prompt_file_download_success));
                break;
            case DOWNLOAD_FAILED:
                disDownloadResult(ResponseCode.getRespCodeMsg((int) event.getData()));
                break;
            default:
                break;
        }
    }

    private void disDownloadResult(String message) {
        if (alert != null && alert.isShowing()) {
            alert.dismiss();
            alert = null;
        }
        Snackbar.showSnackBar(getWindow().getDecorView(), message);
        isCanceled = false;
    }

    @OnClick({R.id.uiFile, R.id.clssFile, R.id.emvFile, R.id.downloadButton})
    protected void onClick(View v) {
        switch (v.getId()) {
            case R.id.uiFile:
                downloadProcess(uiFileName);
                break;
            case R.id.clssFile:
                downloadProcess(getString(R.string.file_name_clss_param));
                break;
            case R.id.emvFile:
                downloadProcess(getString(R.string.file_name_emv_param));
                break;
            case R.id.downloadButton:
                if (fileCount == 1) {
                    downloadProcess(getFileName());
                } else {
                    downloadProcess(getString(R.string.file_name_zip));
                }
                break;
            default:
                break;
        }
    }

    @OnClick({R.id.uiCheckBox, R.id.clssCheckBox, R.id.emvCheckBox})
    protected void onCheckedChanged(CheckBox checkBox) {
        if (checkBox.isChecked()) {
            fileCount++;
        } else {
            fileCount--;
        }
        if (fileCount > 0) {
            downloadButton.setVisibility(View.VISIBLE);
        } else {
            downloadButton.setVisibility(View.GONE);
        }
    }

    private void updateChecked() {
        if (uiCheckBox.isChecked()) {
            uiCheckBox.setChecked(false);
            fileCount--;
        }
        if (clssCheckBox.isChecked()) {
            clssCheckBox.setChecked(false);
            fileCount--;
        }
        if (emvCheckBox.isChecked()) {
            emvCheckBox.setChecked(false);
            fileCount--;
        }
    }

    private String selectUiFile(String termType) {
        if (termType == null) {
            return null;
        }

        Log.i(TAG, "termType = " + termType);

        for (int i = 0; i < TERMINAL_TYPE_UI.length; i++) {
            if (termType.equalsIgnoreCase(TERMINAL_TYPE_UI[i][0])) {
                return TERMINAL_TYPE_UI[i][1];
            }
        }

        return "ui_d180.ui";
    }

    private String getFileName() {
        String fileName = "";
        if (uiCheckBox.isChecked()) {
            fileName = uiFileName;
        } else if (clssCheckBox.isChecked()) {
            fileName = getResources().getString(R.string.file_name_clss_param);
        } else if (emvCheckBox.isChecked()) {
            fileName = getResources().getString(R.string.file_name_emv_param);
        }
        return fileName;
    }

    private void downloadProcess(final String fileName) {
        alert = new AlertDialog.Builder(context).create();
        Dialog.showProgressDialog(context, alert, getString(R.string.prompt_downloading),
                getString(R.string.prompt_wait), true);
        alert.setOnCancelListener(dialog -> isCanceled = true);

        FinancialApplication.getApp().runInBackground(() -> {
            String filePath;
            if (fileCount == 1) {
                filePath = getFilePath(fileName);
            } else {
                filePath = getZipFilePath();

                String[] filePathStrings = getFilePathStrings();

                try {
                    ZipControl.writeByApacheZipOutputStream(filePathStrings, filePath);
                } catch (IOException e) {
                    Log.e(TAG, e.toString());
                }
                Log.e(TAG, "complete zip");
            }

            fileDownload(fileName, filePath);
        });
    }

    private void fileDownload(String fileName, String filePath) {
        checkFileExist(fileName);
//        int ret = FinancialApplication.getEasyLinkSdkManager().fileDownLoad(fileName, filePath, new MyFileDownloadListener());
        int ret = FinancialApplication.getEasyLinkSdkManager().fileDownLoad(filePath,new MyFileDownloadListener());
        Log.d(TAG, "fileDownLoad = " + ret + ", fileName = " + fileName + ", filePath = " + filePath);
        if (ret == ResponseCode.EL_RET_OK) {
            FinancialApplication.getApp().doEvent(new ResultEvent(ResultEvent.Status.DOWNLOAD_SUCCESS));
        } else {
            FinancialApplication.getApp().doEvent(new ResultEvent(ResultEvent.Status.DOWNLOAD_FAILED, ret));
        }
    }

    private String getFilePath(String filename) {
        String filePath = context.getFilesDir().getPath() + "/app/" + filename;
        if (!mkDir(context.getFilesDir().getPath() + "/app/")) {
            return null;
        }
        return filePath;
    }

    private String getZipFilePath() {
        String pathString = getCacheDir().toString();
        Log.e(TAG, "path is " + pathString);
        String archiveString = pathString + "/zip";
        if (!mkDir(archiveString)) {
            return "";
        }
        return (archiveString + '/' + getString(R.string.file_name_zip));
    }

    private String[] getFilePathStrings() {
        String[] filePathStrings = new String[fileCount];
        int index = 0;
        if (uiCheckBox.isChecked()) {
            filePathStrings[index++] = getFilePath(uiFileName);
        }
        if (clssCheckBox.isChecked()) {
            filePathStrings[index++] = getFilePath(getString(R.string.file_name_clss_param));
        }
        if (emvCheckBox.isChecked()) {
            filePathStrings[index] = getFilePath(getString(R.string.file_name_emv_param));
        }
        return filePathStrings;
    }

    private static boolean mkDir(String folderPath) {
        File folder = new File(folderPath);
        return folder.exists() || folder.mkdirs();
    }

    private void copyFile() {
        try {
            copyFileFromAssert(context, getString(R.string.ui_d180), getFilePath(getString(R.string.ui_d180)));
            copyFileFromAssert(context, getString(R.string.ui_d200), getFilePath(getString(R.string.ui_d200)));
            copyFileFromAssert(context, getString(R.string.ui_d220), getFilePath(getString(R.string.ui_d220)));
            copyFileFromAssert(context, getString(R.string.ui_q20), getFilePath(getString(R.string.ui_q20)));
            copyFileFromAssert(context, getString(R.string.file_name_clss_param), getFilePath(getString(R.string.file_name_clss_param)));
            copyFileFromAssert(context, getString(R.string.file_name_emv_param), getFilePath(getString(R.string.file_name_emv_param)));
        } catch (IOException e) {
            Log.e(TAG, e.getMessage());
        }
    }

    private void checkFileExist(String fileName) {
        if (fileName.equals(getString(R.string.file_name_zip))) {
            try {
                if (uiCheckBox.isChecked()) {
                    copyFileFromAssert(context, uiFileName, getFilePath(uiFileName));
                }
                if (clssCheckBox.isChecked()) {
                    copyFileFromAssert(context, getString(R.string.file_name_clss_param), getFilePath(getString(R.string.file_name_clss_param)));
                }
                if (emvCheckBox.isChecked()) {
                    copyFileFromAssert(context, getString(R.string.file_name_emv_param), getFilePath(getString(R.string.file_name_emv_param)));
                }
            } catch (IOException e) {
                Log.e(TAG, e.getMessage());
            }
            return;
        }
        try {
            copyFileFromAssert(context, fileName, getFilePath(fileName));
        } catch (IOException e) {
            Log.e(TAG, e.getMessage());
        }
    }

    private static void copyFileFromAssert(Context ctx, String srcFile, String descFile) throws IOException {
        Log.d(TAG, "prepare copy ASSERT/" + srcFile + "file to" + descFile);

        InputStream iptStm = null;
        OutputStream optStm = null;

        try {
            iptStm = ctx.getAssets().open(srcFile);
            Log.d(TAG, "AssetsFilePath:" + srcFile + " FileSize:" + (iptStm == null ? 0 : iptStm.available()));
            Log.d(TAG, "strDesFilePath:" + descFile);

            if (iptStm == null) {
                Log.d(TAG, "file[" + srcFile + "]not exists in the ASSERT,don't need to copy!");
                return;
            }

            File file = new File(descFile);
            if (!file.exists()) {// file not exists,need to copy
                if (!file.createNewFile()) {
                    return;
                }
                Runtime.getRuntime().exec("chmod 766 " + file);
            } else {
                if (file.length() == iptStm.available()) {
                    Log.d(TAG, "File is consistent, do not need to copy!");
                    iptStm.close();
                    return;
                }
                if (!file.delete() || !file.createNewFile()) {
                    return;
                }
                Runtime.getRuntime().exec("chmod 766 " + file);
            }

            optStm = new FileOutputStream(file);

            int nLen;

            byte[] buff = new byte[1024];
            while ((nLen = iptStm.read(buff)) > 0) {
                optStm.write(buff, 0, nLen);
            }
        } catch (Exception e) {
            Log.d(TAG, e.getMessage());
        } finally {
            if (optStm != null) {
                optStm.close();
            }
            if (iptStm != null) {
                iptStm.close();
            }
        }
    }

    private class MyFileDownloadListener implements FileDownloadListener {

        public void onDownloadProgress(int current, int total) {
            //do nothing
        }

        @Override
        public boolean cancelDownload() {
            return isCanceled;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        FinancialApplication.getApp().unregister(this);
    }
}
