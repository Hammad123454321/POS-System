package com.pax.easylink.test.utils;

import android.content.Context;

/**
 * Created by lixc on 2017/11/14.
 */

public class Utils {

    private Utils() {

    }

    /**
     * 得到设备屏幕的宽度
     */
    public static int getScreenWidth(Context context) {
        return context.getResources().getDisplayMetrics().widthPixels;
    }

    /**
     * 得到设备屏幕的高度
     */
    public static int getScreenHeight(Context context) {
        return context.getResources().getDisplayMetrics().heightPixels;
    }
}
