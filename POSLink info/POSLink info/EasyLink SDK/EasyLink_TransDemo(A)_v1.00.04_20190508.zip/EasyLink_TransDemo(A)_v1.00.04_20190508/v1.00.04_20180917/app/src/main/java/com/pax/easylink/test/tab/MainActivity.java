package com.pax.easylink.test.tab;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.easylink.R;
import com.pax.easylink.test.tab.fragment.CartFragment;
import com.pax.easylink.test.tab.fragment.ReportFragment;
import com.pax.easylink.test.tab.fragment.SaleFragment;
import com.pax.easylink.test.tab.fragment.SetupFragment;
import com.pax.easylink.test.utils.Dialog;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.ButterKnife;

/**
 * Created by lixc on 2017/6/22.
 */

public class MainActivity extends AppCompatActivity {

    private static final String TAB_TITLE_SALE = "SALE";
    private static final String TAB_TITLE_CART = "CART";
    private static final String TAB_TITLE_REPORT = "REPORT";
    private static final String TAB_TITLE_SETUP = "SETUP";

    private static final String TAB_TITLE = "TAB_TITLE";
    private static final String TAB_IMAGE = "TAB_IMAGE";

    List<Map<String, Object>> tabResourcesList = new ArrayList<>();
    private List<Fragment> fragments;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);

        initData();
        initView();
    }

    /**
     * 初始化跟ViewPager、TabLayout中数据有关的数据
     */
    private void initData() {
        // 初始化Tablayout中展示的标题
        addTabResources(TAB_TITLE_SALE, R.drawable.tab_sale);
        addTabResources(TAB_TITLE_CART, R.drawable.tab_cart);
        addTabResources(TAB_TITLE_REPORT, R.drawable.tab_report);
        addTabResources(TAB_TITLE_SETUP, R.drawable.tab_setup);

        initFragment();
    }

    private void addTabResources(String title, Integer image) {
        Map<String, Object> map = new HashMap<>();
        map.put(TAB_TITLE, title);
        map.put(TAB_IMAGE, image);
        tabResourcesList.add(map);
    }

    private void initFragment() {
        // 初始化Fragment集合
        fragments = new ArrayList<>();
        SaleFragment saleFragment = new SaleFragment();
        fragments.add(saleFragment);
        CartFragment cartFragment = new CartFragment();
        fragments.add(cartFragment);
        ReportFragment reportFragment = new ReportFragment();
        fragments.add(reportFragment);
        SetupFragment setupFragment = new SetupFragment();
        fragments.add(setupFragment);
    }

    private void initView() {
        TabLayout tabs = (TabLayout) findViewById(R.id.tablayout);
        ViewPager viewPager = (ViewPager) findViewById(R.id.vp);

        // 为ViewPager添加适配器
        CustomPagerAdapter customPagerAdapter = new CustomPagerAdapter(getSupportFragmentManager(), fragments);
        viewPager.setAdapter(customPagerAdapter);

        // 将TabLayout和ViewPager进行绑定
        tabs.setupWithViewPager(viewPager);
        // TabLayout中Tab的排列方式，FIXED表示平分布局；SCROLLABLE表示线性排列，可滑动
        tabs.setTabMode(TabLayout.MODE_FIXED);
        // 给TabLayout中的Tab添加图标和文本
        for (int i = 0; i < tabResourcesList.size(); i++) {
            tabs.getTabAt(i).setCustomView(getTabView(tabResourcesList.get(i).get(TAB_TITLE).toString(),
                    tabResourcesList.get(i).get(TAB_IMAGE).hashCode()));
        }
    }

    private View getTabView(String title, int resId) {
        View newTabView = LayoutInflater.from(this).inflate(R.layout.tab_item_view, null);
        ImageView tabIcon = (ImageView) newTabView.findViewById(R.id.tabIcon);
        tabIcon.setImageResource(resId);
        TextView tabTitle = (TextView) newTabView.findViewById(R.id.tabText);
        tabTitle.setText(title);
        return newTabView;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
            Dialog.showExitDialog(this);
            return true;
        }
        return false;
    }
}
