package com.pax.easylink.test.sale;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.easylink.R;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by lixc
 * payment completed UI
 */

public class PaymentCompletedActivity extends Activity {

    @Bind(R.id.imagePrompt)
    ImageView imagePrompt;
    @Bind(R.id.titlePrompt)
    TextView titlePrompt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prompt);
        ButterKnife.bind(this);

        imagePrompt.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.img_5));
        titlePrompt.setText(getString(R.string.complete));
    }
}
