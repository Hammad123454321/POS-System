package com.pax.easylink.test.utils;

import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.easylink.R;

/**
 * Created by lixc on 2017/9/14.
 */

public class CaptionedImagesAdapter extends RecyclerView.Adapter<CaptionedImagesAdapter.RecyclerViewHolder> {

    private int[] imageIds;
    private String[] titles;
    private String[] subTitles;
    private Listener listener;

    public CaptionedImagesAdapter(int[] imageIds, String[] titles, String[] subTitles) {
        this.imageIds = imageIds;
        this.titles = titles;
        this.subTitles = subTitles;
    }

    static class RecyclerViewHolder extends RecyclerView.ViewHolder {
        private CardView cardView;

        private RecyclerViewHolder(CardView cardView) {
            super(cardView);
            this.cardView = cardView;
        }
    }

    @Override
    public CaptionedImagesAdapter.RecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        CardView cardView = (CardView) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.sale_image_items, parent, false);
        return new RecyclerViewHolder(cardView);
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder holder, int position) {
        CardView cardView = holder.cardView;
        ImageView imageView = (ImageView) cardView.findViewById(R.id.goodsImage);
        imageView.setImageResource(imageIds[position]);
        TextView title = (TextView) cardView.findViewById(R.id.goodsTitle);
        title.setText(titles[position]);
        TextView subTitle = (TextView) cardView.findViewById(R.id.goodsSubtitle);
        subTitle.setText(subTitles[position]);
        cardView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return imageIds.length;
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    @FunctionalInterface
    public interface Listener {
        void onClick(int position);
    }
}
