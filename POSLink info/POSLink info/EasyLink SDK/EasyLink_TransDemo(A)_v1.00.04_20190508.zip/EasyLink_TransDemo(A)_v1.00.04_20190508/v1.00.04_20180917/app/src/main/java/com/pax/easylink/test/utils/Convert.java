package com.pax.easylink.test.utils;

/**
 * Created by lixc on 2017/4/27.
 */

public class Convert {

    private static final char[] ARRAY_OF_CHAR = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    private Convert() {

    }

    public static String bcdToStr(byte[] b) {
        if (b == null) {
            throw new IllegalArgumentException("bcdToStr input arg is null");
        }

        StringBuilder localStringBuilder = new StringBuilder(b.length * 2);
        for (byte i : b) {
            localStringBuilder.append(ARRAY_OF_CHAR[((i & 0xF0) >>> 4)]);
            localStringBuilder.append(ARRAY_OF_CHAR[(i & 0xF)]);
        }

        return localStringBuilder.toString();
    }

    //bytes to string
    public static String byte2Str(byte[] bytes, int startIndex) {
        StringBuilder temp = new StringBuilder(bytes.length);
        int length = bytes.length - startIndex;
        char[] tChars = new char[length];
        for (int i = startIndex; i < bytes.length; i++) {
            tChars[i - startIndex] = (char) bytes[i];
        }
        temp.append(tChars);
        return temp.toString();
    }

    public static byte[] strToBcd(String str) {
        if (str == null) {
            throw new IllegalArgumentException("strToBcd input arg is null");
        }
        String s = str;
        int len = s.length();
        if (len % 2 != 0) {
            s = "0" + s;
            len = s.length();
        }
        if (len >= 2) {
            len /= 2;
        }
        byte[] bcd = new byte[len];
        byte[] strBytes = s.getBytes();

        for (int p = 0; p < strBytes.length / 2; p++) {
            bcd[p] = (byte) ((strByte2Int(strBytes[(2 * p)]) << 4) + strByte2Int(strBytes[(2 * p + 1)]));
        }

        return bcd;
    }

    private static int strByte2Int(byte b) {
        int j;
        if ((b >= 'a') && (b <= 'z')) {
            j = b - 'a' + 0x0A;
        } else {
            if ((b >= 'A') && (b <= 'Z'))
                j = b - 'A' + 0x0A;
            else
                j = b - '0';
        }
        return j;
    }
}
