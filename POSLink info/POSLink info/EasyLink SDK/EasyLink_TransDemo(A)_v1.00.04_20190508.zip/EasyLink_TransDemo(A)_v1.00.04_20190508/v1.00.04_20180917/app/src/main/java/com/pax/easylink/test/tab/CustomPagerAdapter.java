package com.pax.easylink.test.tab;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.List;

/**
 * Created by lixc on 2017/6/22.
 */

class CustomPagerAdapter extends FragmentPagerAdapter {

    private List<Fragment> fragments;

    CustomPagerAdapter(FragmentManager fragmentManager, List<Fragment> fragments) {
        super(fragmentManager);
        this.fragments = fragments;
    }

    @Override
    public int getCount() {
        return fragments.size();//页卡数
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }
}
