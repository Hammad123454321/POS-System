package com.pax.easylink.test.constant;

/**
 * Created by lixc on 2017/3/27.
 */

public enum UIParamKeys {
    SHOP,
    IMAGE,
    TITLE,
    SUBTITLE,
    TIME,
    COUNT,
    MONEY,
}
