package com.pax.easylink.test.tab.fragment;

import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.example.easylink.R;
import com.pax.easylink.test.constant.ParamData;
import com.pax.easylink.test.sale.model.CartDataList;
import com.pax.easylink.test.sale.model.CommodityParam;
import com.pax.easylink.test.utils.CaptionedImagesAdapter;
import com.pax.easylink.test.utils.Utils;

import butterknife.Bind;

/**
 * Created by lixc on 2017/6/22.
 */

public class SaleFragment extends BaseFragment {

    @Bind(R.id.title)
    TextView title;
    @Bind(R.id.goodsRecyclerView)
    RecyclerView recyclerView;

    private int spanCount;
    private int[] imageIds;
    private String[] titles;
    private String[] subTitles;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_sale;
    }

    @Override
    protected void initData() {
        imageIds = new int[ParamData.getParamDatas().length];
        titles = new String[ParamData.getParamDatas().length];
        subTitles = new String[ParamData.getParamDatas().length];
        for (int i = 0; i < ParamData.getParamDatas().length; i++) {
            imageIds[i] = ParamData.getParamDatas()[i].getImage();
            titles[i] = ParamData.getParamDatas()[i].getTitle();
            subTitles[i] = ParamData.getParamDatas()[i].getSubTitle();
        }
        if (Utils.getScreenWidth(getContext()) > Utils.getScreenHeight(getContext())) {
            spanCount = 5;
        } else {
            spanCount = 2;
        }
    }

    @Override
    protected void initView(View view) {
        title.setText(getString(R.string.title_sale));

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), spanCount);
        recyclerView.setLayoutManager(gridLayoutManager);
        CaptionedImagesAdapter adapter = new CaptionedImagesAdapter(imageIds, titles, subTitles);
        recyclerView.setAdapter(adapter);
        adapter.setListener(SaleFragment.this::addCart);
    }

    //add to cart
    private void addCart(int index) {
        CartDataList cartDataList = CartDataList.getInstance();
        CommodityParam commodityParam = new CommodityParam();
        boolean isAdd = false;
        for (int i = 0; i < cartDataList.getCount(); i++) {
            if (ParamData.getParamDatas()[index].getTitle().equals(cartDataList.getData(i).getTitle())) {
                isAdd = true;
                cartDataList.getData(i).setCount(cartDataList.getData(i).getCount() + 1);
                break;
            }
        }

        //not add the same one
        if (!isAdd) {
            commodityParam.setShopname(ParamData.SHOP_NAME);
            commodityParam.setImage(String.valueOf(ParamData.getParamDatas()[index].getImage()));
            commodityParam.setTitle(ParamData.getParamDatas()[index].getTitle());
            commodityParam.setSubtitle(ParamData.getParamDatas()[index].getSubTitle());
            commodityParam.setMoney(ParamData.getParamDatas()[index].getMoney());
            commodityParam.setCount(1);

            //not selected
            commodityParam.setSelect(false);
            cartDataList.addData(commodityParam);
        }
    }
}
