package com.pax.easylink.test.setup.comm;

import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.example.easylink.R;
import com.pax.easylink.test.app.FinancialApplication;
import com.pax.easylink.test.event.ResultEvent;
import com.pax.easylink.test.utils.Dialog;
import com.pax.easylink.test.utils.Snackbar;
import com.paxsz.easylink.api.ResponseCode;
import com.paxsz.easylink.device.DeviceInfo;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by lixc on 2017/9/14.
 */

public class TcpActivity extends AppCompatActivity {

    @Bind(R.id.ipText)
    TextInputEditText ipText;
    @Bind(R.id.portText)
    TextInputEditText portText;
    @Bind(R.id.saveButton)
    Button saveButton;
    @Bind(R.id.reloadButton)
    Button reloadButton;

    AlertDialog alertDialog;

    private static String ip = "";
    private static String port = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tcp);
        ButterKnife.bind(this);
        FinancialApplication.getApp().register(this);
        initView();
    }

    private void initView() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(getResources().getString(R.string.title_tcp));
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        ipText.setText(ip, null);
        portText.setText(port, null);
    }

    @OnClick({R.id.saveButton, R.id.reloadButton})
    protected void onClick(View v) {
        switch (v.getId()) {
            case R.id.saveButton:
                onClicked(ipText.getText().toString(), portText.getText().toString(), getString(R.string.prompt_save_success));
                break;
//            case R.id.reloadButton:
//                onClicked(null, null, getString(R.string.prompt_reload_success));
//                break;
            default:
                break;
        }
    }

    private void onClicked(String ipData, String portData, String prompt) {
        ip = ipData;
        port = portData;
        ipText.setText(ip, null);
        portText.setText(port, null);
        int portInt = 0;
        if(!TextUtils.isEmpty(port)){
            portInt = Integer.parseInt(port);
        }else{
            if(TextUtils.isEmpty(ip) || TextUtils.isEmpty(port)){
                Snackbar.showSnackBar(getWindow().getDecorView(), "IP or Port can not be empty");
                return;
            }

        }
        DeviceInfo devinfo = new DeviceInfo(ip, portInt);
        alertDialog = new AlertDialog.Builder(this).create();
        Dialog.showProgressDialog(this, alertDialog, getString(R.string.prompt_connecting),
                getString(R.string.prompt_wait), false);
        FinancialApplication.getApp().runInBackground(() -> {
            int ret = FinancialApplication.getEasyLinkSdkManager().connect(devinfo);
            if (ret != ResponseCode.EL_RET_OK) {
                FinancialApplication.getApp().doEvent(new ResultEvent(ResultEvent.Status.CONNECT_FAILED, ret));
            } else {
                FinancialApplication.getApp().doEvent(new ResultEvent(ResultEvent.Status.CONNECT_SUCCESS));
            }
        });
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(ResultEvent event) {
        switch ((ResultEvent.Status) event.getStatus()) {
            case CONNECT_SUCCESS:
                onConnectSuccess();
                break;
            case CONNECT_FAILED:
                onConnectFailed((int) event.getData());
                break;
            default:
                break;
        }
    }

    private void onConnectFailed(int errorCode){
        dialogDismiss();
        Snackbar.showSnackBar(getWindow().getDecorView(), ResponseCode.getRespCodeMsg(errorCode));
    }
    private void onConnectSuccess(){
        dialogDismiss();
        Snackbar.showSnackBar(getWindow().getDecorView(), "Connect Succ");
    }

    private void dialogDismiss() {
        if (alertDialog != null && alertDialog.isShowing()) {
            alertDialog.dismiss();
            alertDialog = null;
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        FinancialApplication.getApp().unregister(this);
    }
}
