package com.pax.easylink.test.sale.model;


/**
 * Created by lixc
 * commodity parameters
 */
public class CommodityParam {

    //the status of the checkbox
    private boolean isSelect;

    private String shopName;//shop name
    private String image;//good's image
    private String title;//good's title
    private String subTitle;//good's subtitle
    private double money;//good's money
    private int count;//good's count of the cart

    private String transTime;//trans time

    public void setSelect(boolean select) {
        this.isSelect = select;
    }

    public boolean getSelect() {
        return isSelect;
    }

    public String getShopname() {
        return shopName;
    }

    public void setShopname(String shopname) {
        this.shopName = shopname;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubtitle() {
        return subTitle;
    }

    public void setSubtitle(String subtitle) {
        this.subTitle = subtitle;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getTranstime() {
        return transTime;
    }

    public void setTranstime(String transtime) {
        this.transTime = transtime;
    }
}
