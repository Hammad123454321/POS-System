/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-9-7
 * Module Author: lixc
 * Description:
 *
 * ============================================================================
 */
package com.pax.easylink.test.setup.comm;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.easylink.R;
import com.pax.easylink.test.app.FinancialApplication;
import com.pax.easylink.test.event.ResultEvent;
import com.pax.easylink.test.receiver.USBBroadcastReceiver;
import com.pax.easylink.test.utils.Dialog;
import com.pax.easylink.test.utils.Snackbar;
import com.paxsz.easylink.api.ResponseCode;
import com.paxsz.easylink.device.DeviceInfo;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

public class UsbActivity extends AppCompatActivity {

    @Bind(R.id.connectedDeviceLayout)
    LinearLayout connectedDeviceLayout;
    @Bind(R.id.connectedDeviceTitle)
    TextView connectedDeviceTitle;
    @Bind(R.id.availableDevicesList)
    ListView availableDevicesList;
    @Bind(R.id.container)
    CoordinatorLayout container;
    @Bind(R.id.no_available_device)
    TextView noAvailableDevice;

    private List<DeviceInfo> usbList;
    private AlertDialog alertDialog;
    private USBBroadcastReceiver usbBroadcastReceiver = new USBBroadcastReceiver();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usb);

        FinancialApplication.getApp().register(this);
        usbBroadcastReceiver.registerUsbReceiver(this);
        ButterKnife.bind(this);
        usbList = FinancialApplication.getEasyLinkSdkManager().getUsbDevice();

        initViews();
        setListeners();
    }

    private void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(getResources().getString(R.string.title_usb));
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        resetUI();
        updateUsbList();
    }



    private void setListeners() {
        availableDevicesList.setOnItemClickListener((parent, view, position, id) -> onItemClicked(position));
        usbBroadcastReceiver.setUsbListener(new USBBroadcastReceiver.OnUsbListener() {
            @Override
            public void onUsbDetached() {
                usbList = FinancialApplication.getEasyLinkSdkManager().getUsbDevice();


                //规避SDK bug
                /*ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                FinancialApplication.getEasyLinkSdk().getData(DataModel.DataType.CONFIGURATION_DATA,
                        new byte[]{(byte) 0x01, 0x01}, byteArrayOutputStream);
                if (byteArrayOutputStream.size() == 0) {
                    connectedDeviceLayout.setVisibility(View.GONE);
                } else {
                    resetUI();
                }*/
                connectedDeviceLayout.setVisibility(View.GONE);

                updateUsbList();
            }

            @Override
            public void onUsbAttached() {
                usbList = FinancialApplication.getEasyLinkSdkManager().getUsbDevice();
                resetUI();
                updateUsbList();
            }
        });
    }

    private void resetUI() {
        if (!FinancialApplication.getEasyLinkSdkManager().isConnected(DeviceInfo.CommType.USB)) {
            connectedDeviceLayout.setVisibility(View.GONE);
            return;
        }
        String connectedDeviceName = FinancialApplication.getEasyLinkSdkManager().getConnectedDevice().getDeviceName();
        connectedDeviceLayout.setVisibility(View.VISIBLE);
        connectedDeviceTitle.setText(connectedDeviceName);

        String connectedDeviceId = FinancialApplication.getEasyLinkSdkManager().getConnectedDevice().getIdentifier();
        for (int i = 0; i < usbList.size(); i++) {
            // 不要使用deviceName来判断，要通过identifier这个USB的唯一标识来判断
            if (connectedDeviceId.equals(usbList.get(i).getIdentifier())) {
                usbList.remove(i);
                break;
            }
        }
    }

    private void updateUsbList() {
        if (usbList.isEmpty() && connectedDeviceLayout.getVisibility() != View.VISIBLE) {
            noAvailableDevice.setVisibility(View.VISIBLE);
            availableDevicesList.setVisibility(View.GONE);
            return;
        }
        noAvailableDevice.setVisibility(View.GONE);
        availableDevicesList.setVisibility(View.VISIBLE);
        UsbAdapter adapter = new UsbAdapter(this);
        availableDevicesList.setAdapter(adapter);
        availableDevicesList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
    }

    private void onItemClicked(int index) {
        alertDialog = new AlertDialog.Builder(this).create();
        Dialog.showProgressDialog(this, alertDialog, getString(R.string.prompt_connecting),
                getString(R.string.prompt_wait), false);

        FinancialApplication.getApp().runInBackground(() -> {
            int ret = FinancialApplication.getEasyLinkSdkManager().connect(usbList.get(index));
            if (ret != ResponseCode.EL_RET_OK) {
                FinancialApplication.getApp().doEvent(new ResultEvent(ResultEvent.Status.CONNECT_FAILED, ret));
            } else {
                FinancialApplication.getApp().doEvent(new ResultEvent(ResultEvent.Status.CONNECT_SUCCESS));
            }
        });
    }

    @SuppressWarnings("unused")
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(ResultEvent event) {
        switch ((ResultEvent.Status) event.getStatus()) {
            case CONNECT_SUCCESS:
                onConnectSuccess();
                break;
            case CONNECT_FAILED:
                onConnectFailed((int) event.getData());
                break;
            default:
                break;
        }
    }

    private void onConnectSuccess() {
        dialogDismiss();
        resetUI();
        updateUsbList();
    }

    private void onConnectFailed(int responseCode) {
        dialogDismiss();
        usbList = FinancialApplication.getEasyLinkSdkManager().getUsbDevice();
        resetUI();
        updateUsbList();
        Snackbar.showSnackBar(container, ResponseCode.getRespCodeMsg(responseCode));
    }

    private void dialogDismiss() {
        if (alertDialog != null && alertDialog.isShowing()) {
            alertDialog.dismiss();
            alertDialog = null;
        }
    }

    private class UsbAdapter extends BaseAdapter {

        private Context context;

        private UsbAdapter(Context context) {
            this.context = context;
        }

        @Override
        public int getCount() {
            return usbList.size();
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public Object getItem(int position) {
            return usbList.get(position);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view;
            if (convertView == null) {
                view = LayoutInflater.from(context).inflate(R.layout.device_list_items, parent, false);
            } else {
                view = convertView;
            }
            TextView title = (TextView) view.findViewById(R.id.title);
            ImageView image = (ImageView) view.findViewById(R.id.image);
            title.setText(usbList.get(position).getDeviceName());
            image.setImageResource(R.drawable.icn_usb);
            return view;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        FinancialApplication.getApp().unregister(this);
        usbBroadcastReceiver.unregisterUsbReceiver(this);
    }
}
