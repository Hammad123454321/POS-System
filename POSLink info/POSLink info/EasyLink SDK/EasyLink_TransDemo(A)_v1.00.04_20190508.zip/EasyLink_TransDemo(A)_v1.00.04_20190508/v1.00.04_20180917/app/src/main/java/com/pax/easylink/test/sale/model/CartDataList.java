package com.pax.easylink.test.sale.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lixc
 * the list of the goods which add to cart
 */

public class CartDataList {

    private static CartDataList instance = null;
    private List<CommodityParam> dataList = null;

    private CartDataList() {
        dataList = new ArrayList<>();
    }

    public static CartDataList getInstance() {
        if (instance == null) {
            instance = new CartDataList();
        }
        return instance;
    }

    public CommodityParam getData(int index) {
        return dataList.get(index);
    }

    public int getCount() {
        return dataList.size();
    }

    public boolean isEmpty() {
        return dataList.isEmpty();
    }

    public void addData(CommodityParam commodityParam) {
        dataList.add(commodityParam);
    }

    public void removeData(int index) {
        dataList.remove(index);
    }
}
