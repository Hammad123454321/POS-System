package com.pax.easylink.test.sale.model;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.easylink.R;

import java.text.DecimalFormat;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by lixc
 * define adapter, display the list of the goods
 */
public class CartAdapter extends BaseAdapter {

    private LayoutInflater mInflater;
    private CartDataList cartDataList;
    private CartSelectDataTitleList cartSelectDataTitleList;

    public CartAdapter(Context context) {
        this.mInflater = LayoutInflater.from(context);
        cartDataList = CartDataList.getInstance();
        cartSelectDataTitleList = CartSelectDataTitleList.getInstance();
    }

    /**
     * @return size
     */
    @Override
    public int getCount() {
        return cartDataList.getCount();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final CartItemView cartItemView;
        View view;
        if (convertView == null) {
            view = mInflater.inflate(R.layout.cart_list_items, null);
            cartItemView = new CartItemView(view);
            view.setTag(cartItemView);
        } else {
            view = convertView;
            cartItemView = (CartItemView) view.getTag();
        }

        initView(position, cartItemView);

        cartItemView.addButton.setOnClickListener(v -> onAddClicked(position, cartItemView));

        cartItemView.reduceButton.setOnClickListener(v -> onReduceClicked(position, cartItemView));

        cartItemView.checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (cartItemView.checkBox.isChecked()) {
                onCheckedTrue(position);
            } else {
                onCheckedFalse(position);
            }
        });
        cartItemView.checkBox.setChecked(cartDataList.getData(position).getSelect());
        return view;
    }

    private void initView(int index, CartItemView cartItemView) {
        int imageId = Integer.parseInt(cartDataList.getData(index).getImage());
        cartItemView.imageView.setImageResource(imageId);
        cartItemView.titleText.setText(cartDataList.getData(index).getTitle());
        cartItemView.subtitleText.setText(cartDataList.getData(index).getSubtitle());
        DecimalFormat decimalFormat = new DecimalFormat("#####0.00");
        String totalMoney = decimalFormat.format(cartDataList.getData(index).getMoney());
        cartItemView.moneyText.setText(totalMoney);
        cartItemView.countText.setText(String.valueOf(cartDataList.getData(index).getCount()));
    }

    private void onAddClicked(int index, CartItemView cartItemView) {
        cartDataList.getData(index).setCount(cartDataList.getData(index).getCount() + 1);
        cartItemView.countText.setText(String.valueOf(cartDataList.getData(index).getCount()));
        cartSelectDataTitleList.countChanged();
    }

    private void onReduceClicked(int index, CartItemView cartItemView) {
        if (cartDataList.getData(index).getCount() > 1) {
            cartDataList.getData(index).setCount(cartDataList.getData(index).getCount() - 1);
            cartItemView.countText.setText(String.valueOf(cartDataList.getData(index).getCount()));
            cartSelectDataTitleList.countChanged();
        }
    }

    private void onCheckedTrue(int index) {
        //not affected by select all
        if (cartSelectDataTitleList.getCount() == cartDataList.getCount()) {
            return;
        }

        boolean isAdd = false;
        for (int i = 0; i < cartSelectDataTitleList.getCount(); i++) {
            if (cartDataList.getData(index).getTitle().equals(cartSelectDataTitleList.getSelectTitle(i))) {
                isAdd = true;
                break;
            }
        }
        //not add the same one
        if (!isAdd) {
            cartDataList.getData(index).setSelect(true);
            cartSelectDataTitleList.add(cartDataList.getData(index).getTitle());
        }
    }

    private void onCheckedFalse(int index) {
        //not affected by select none
        if (cartSelectDataTitleList.getCount() == 0) {
            return;
        }

        cartDataList.getData(index).setSelect(false);
        for (int i = 0; i < cartSelectDataTitleList.getCount(); i++) {
            if (cartSelectDataTitleList.getSelectTitle(i).equals(cartDataList.getData(index).getTitle())) {
                cartSelectDataTitleList.remove(i);
                break;
            }
        }
    }

    class CartItemView {
        @Bind(R.id.goods_checkbox)
        CheckBox checkBox;
        @Bind(R.id.cartListImage)
        ImageView imageView;
        @Bind(R.id.cartListTitle)
        TextView titleText;
        @Bind(R.id.cartListSubtitle)
        TextView subtitleText;
        @Bind(R.id.cartListMoney)
        TextView moneyText;
        @Bind(R.id.reduceButton)
        ImageButton reduceButton;
        @Bind(R.id.countText)
        TextView countText;
        @Bind(R.id.addButton)
        ImageButton addButton;

        private CartItemView(View view) {
            ButterKnife.bind(this, view);
        }
    }
}
