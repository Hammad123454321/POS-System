package com.pax.easylink.test.setup.terminfo;

/**
 * Created by lixc
 * terminal information
 */
public class TerminalInformation {

    private TerminalInformation() {

    }

    private static String[][] information = {
            {"SN:", "Serial Number"},
            {"Term OS Ver:", "Extended Serial Number"},
            {"APP Name:", "Application Name"},
            {"Term Info:", "Terminal Information"},
    };

    private static final byte[][] TERMINAL_TAG = {
            {(byte) 0x01, 0x01},
            {(byte) 0x01, 0x27},
            {(byte) 0x01, 0x18},
            {(byte) 0x01, 0x02}
    };

    public static String[][] getInformation() {
        return information;
    }

    static void setInformation(int index, String data) {
        information[index][1] = data;
    }

    static byte[][] getTerminalTag() {
        return TERMINAL_TAG;
    }
}
