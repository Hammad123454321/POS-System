package com.pax.easylink.test.tab.fragment;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.example.easylink.R;
import com.pax.easylink.test.app.FinancialApplication;
import com.pax.easylink.test.event.ResultEvent;
import com.pax.easylink.test.sale.ChooseCardActivity;
import com.pax.easylink.test.sale.PaymentCompletedActivity;
import com.pax.easylink.test.sale.model.CartAdapter;
import com.pax.easylink.test.sale.model.CartDataList;
import com.pax.easylink.test.sale.model.CartSelectDataTitleList;
import com.pax.easylink.test.sale.model.ReportDataList;
import com.pax.easylink.test.sale.model.TransDataTag;
import com.pax.easylink.test.setup.param.SetParamActivity;
import com.pax.easylink.test.utils.Convert;
import com.pax.easylink.test.utils.Dialog;
import com.pax.easylink.test.utils.SharedPreferencesHelper;
import com.pax.easylink.test.utils.Snackbar;
import com.pax.easylink.test.utils.Tools;
import com.paxsz.easylink.api.ResponseCode;
import com.paxsz.easylink.listener.IReportListener;
import com.paxsz.easylink.model.DataModel;
import com.paxsz.easylink.model.TLVDataObject;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.ByteArrayOutputStream;
import java.sql.Date;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import butterknife.Bind;
import butterknife.OnClick;

/**
 * Created by lixc on 2017/6/22.
 */

public class CartFragment extends BaseFragment {

    @Bind(R.id.title)
    TextView title;
    @Bind(R.id.deleteButton)
    ImageButton deleteButton;
    @Bind(R.id.cartList)
    ListView cartList;
    @Bind(R.id.totalCheckBox)
    CheckBox totalCheckBox;
    @Bind(R.id.totalMoney)
    TextView totalMoneyText;
    @Bind(R.id.cardButton)
    Button cardButton;
    @Bind(R.id.cashButton)
    Button cashButton;

    private static final String TAG = "CartFragment";

    private TransDataTag transDataTag;
    private CartDataList cartDataList;
    private CartSelectDataTitleList selectDataTitleList;
    private CartAdapter adapter;
    private Intent intent;
    private String money;
    private String dateAndTime;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_cart;
    }

    @Override
    protected void initData() {
        FinancialApplication.getApp().register(this);

        cartDataList = CartDataList.getInstance();
        selectDataTitleList = CartSelectDataTitleList.getInstance();
        transDataTag = new TransDataTag();
    }

    @Override
    protected void initView(View view) {
        title.setText(getString(R.string.title_cart));
        deleteButton.setVisibility(View.VISIBLE);
        if ((selectDataTitleList.getCount() == cartDataList.getCount())
                && (!cartDataList.isEmpty())) {
            totalCheckBox.setChecked(true);
        } else {
            totalCheckBox.setChecked(false);
        }

        adapter = new CartAdapter(getContext());
        cartList.setAdapter(adapter);
        updateTotalMoney();
        setDataListener();
    }

    private void setDataListener() {
        selectDataTitleList.setListener(() -> {
            updateTotalMoney();
            if (selectDataTitleList.getCount() == cartDataList.getCount()) {
                //select one by one to all
                totalCheckBox.setChecked(true);
            } else {
                //from all to reduce one by one
                totalCheckBox.setChecked(false);
            }
        });
    }

    private void onTotalCheckedTrue() {
        //only response clicking on totalCheckBox, not response the type of one by one to all
        if (selectDataTitleList.getCount() == cartDataList.getCount() || cartDataList.isEmpty()) {
            return;
        }

        selectDataTitleList.removeAll();
        selectDataTitleList.addAll(cartDataList.getCount());
        for (int i = 0; i < cartDataList.getCount(); i++) {
            cartDataList.getData(i).setSelect(true);
        }
        updateTotalMoney();
        cartList.setAdapter(adapter);
    }

    private void onTotalCheckedFalse() {
        //only response from all to zero, not response from all to one by one reduce，not response deleting all
        if (selectDataTitleList.getCount() != cartDataList.getCount() || cartDataList.isEmpty()) {
            return;
        }

        selectDataTitleList.removeAll();
        for (int i = 0; i < cartDataList.getCount(); i++) {
            cartDataList.getData(i).setSelect(false);
        }
        updateTotalMoney();
        cartList.setAdapter(adapter);
    }

    @OnClick({R.id.deleteButton, R.id.cardButton, R.id.cashButton, R.id.totalCheckBox})
    protected void onClick(View v) {
        switch (v.getId()) {
            case R.id.deleteButton:
                onDeleteClicked();
                break;
            case R.id.cardButton:
                onCardButtonClicked();
                break;
            case R.id.cashButton:
                onCashButtonClicked();
                break;
            case R.id.totalCheckBox:
                onCheckedChanged();
                break;
            default:
                break;
        }
    }

    private void onDeleteClicked() {
        //delete selected items
        if (selectDataTitleList.isEmpty()) {
            return;
        }

        for (int i = 0; i < selectDataTitleList.getCount(); i++) {
            for (int j = 0; j < cartDataList.getCount(); j++) {
                if (selectDataTitleList.getSelectTitle(i).equals(cartDataList.getData(j).getTitle())) {
                    cartDataList.removeData(j);
                    break;
                }
            }
        }
        selectDataTitleList.removeAll();
        updateTotalMoney();
        totalCheckBox.setChecked(false);
        cartList.setAdapter(adapter);
    }

    private void onCardButtonClicked() {
        if (selectDataTitleList.isEmpty()) {
            Snackbar.showSnackBar(getView(), getString(R.string.prompt_select_goods));
            return;
        }
        FinancialApplication.getApp().runInBackground(CartFragment.this::transProcess);
    }

    private void onCashButtonClicked() {
        if (selectDataTitleList.isEmpty()) {
            Snackbar.showSnackBar(getView(), getString(R.string.prompt_select_goods));
            return;
        }
        transSuccess();
        Snackbar.showSnackBar(getView(), getString(R.string.prompt_trans_success));
    }

    private void onCheckedChanged() {
        //only response operation on totalCheckBox
        if (totalCheckBox.isChecked()) {
            onTotalCheckedTrue();
        } else {
            onTotalCheckedFalse();
        }
    }

    @SuppressWarnings("unused")
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(ResultEvent event) {
        switch ((ResultEvent.Status) event.getStatus()) {
            case SUCCESS:
                intent = new Intent(getContext(), PaymentCompletedActivity.class);
                startActivity(intent);
                finish();
                transSuccess();
                break;
            case FAILED:
                finish();
                Dialog.showPromptDialog(getContext(), ResponseCode.getRespCodeMsg((int) event.getData()));
                break;
            default:
                break;
        }
    }

    private void finish() {
        if (ChooseCardActivity.instance != null) {
            ChooseCardActivity.instance.finish();
        }
    }

    //trans process
    private void transProcess() {
        int ret = transPrepare();
        if (ret != ResponseCode.EL_RET_OK) {
            disTransFailed(ret);
            return;
        }

        intent = new Intent(getContext(), ChooseCardActivity.class);
        startActivity(intent);

        //get if terminal support report status to host Device
        ArrayList<TLVDataObject> TLVDataObjects = new ArrayList<TLVDataObject>();
        List<byte[]> tags = new ArrayList<byte[]>();
        tags.add(new byte[]{0x02,0x16});
        ret = FinancialApplication.getEasyLinkSdkManager().getData(DataModel.DataType.CONFIGURATION_DATA, tags, TLVDataObjects);
        Log.i(TAG, "get supoortReport: ret = " + ret + " supportReportTags value: " + Tools.bcd2Str(TLVDataObjects.get(0).getValue()));

        //start trans
//        Log.i(TAG,"TLVDataObjects.get(0).getValue().len = "+TLVDataObjects.get(0).getLength());
        if(TLVDataObjects.get(0).getLength() == 0 || TLVDataObjects.get(0).getValue()[0] == 0) {
            ret = FinancialApplication.getEasyLinkSdkManager().startTransaction();
        }else{
            ret = FinancialApplication.getEasyLinkSdkManager().startTransaction(new IReportListener() {
                @Override
                public byte[] onReport(final byte[] reportedData) {
                    if(reportedData!=null){
                        Log.d(TAG, "report data:" + new String(reportedData));
                        FinancialApplication.getApp().doEvent(new ResultEvent(ResultEvent.Status.RECV_REPORT, new String(reportedData)));
                    }
                    return new byte[0];
                }
            });
        }

        Log.i(TAG, "start trans: ret = " + ret);
        if (ret != ResponseCode.EL_RET_OK) {
            disTransFailed(ret);
            return;
        }

        //get card type
        ByteArrayOutputStream getCardTypeTags = new ByteArrayOutputStream();
        ret = FinancialApplication.getEasyLinkSdkManager().getData(DataModel.DataType.CONFIGURATION_DATA, transDataTag.getCardTypeTag(), getCardTypeTags);
        Log.i(TAG, "get card type: ret = " + ret + "  " + Arrays.toString(getCardTypeTags.toByteArray()));
        if (ret != ResponseCode.EL_RET_OK) {
            disTransFailed(ret);
            return;
        }

        ret = transFlow(getCardTypeTags);
        if (ret != ResponseCode.EL_RET_OK) {
            disTransFailed(ret);
            return;
        }

        //complete transaction success
        FinancialApplication.getApp().doEvent(new ResultEvent(ResultEvent.Status.SUCCESS));
    }

    private void disTransFailed(int result) {
        FinancialApplication.getApp().doEvent(new ResultEvent(ResultEvent.Status.FAILED, result));
    }

    private int transPrepare() {
        ArrayList<TLVDataObject> list = new ArrayList<>();
        //amount
        byte[] amount = new byte[6];
        byte[] tmp = Convert.strToBcd(money.replace(".", ""));
        System.arraycopy(tmp, 0, amount, 6 - tmp.length, tmp.length);
        list.add(new TLVDataObject(transDataTag.getAmountTag(), amount));

        //trans type
        list.add(new TLVDataObject(transDataTag.getTransTypeTag(), new byte[]{0x00}));

        //currency code
        list.add(new TLVDataObject(transDataTag.getCurrencyCodeTag(), new byte[]{0x01, 0x01}));

        ByteArrayOutputStream getParamDataTags = new ByteArrayOutputStream();

        SharedPreferencesHelper sharedPreferencesHelper = new SharedPreferencesHelper(
                getContext(), "param");
        boolean b = (Boolean) sharedPreferencesHelper.getSharedPreference("supportReport", new Boolean(false));
        Log.d(TAG, "transPrepare b:" + b);
        if(b){
            //set 0216(set pos support report status to host)
            FinancialApplication.getEasyLinkSdkManager().setData(DataModel.DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x16, 0x01,0x01}, getParamDataTags);
        }else{
            FinancialApplication.getEasyLinkSdkManager().setData(DataModel.DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x16, 0x01,0x00}, getParamDataTags);
        }

        //demo mode
        FinancialApplication.getEasyLinkSdkManager().setData(DataModel.DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x09, 0x01,0x01}, getParamDataTags);

        //set key Index
        FinancialApplication.getEasyLinkSdkManager().setData(DataModel.DataType.CONFIGURATION_DATA, new byte[]{0x02, 0x02, 0x01, 0x01, 0x02, 0x03, 0x01, 0x02}, getParamDataTags);

        //currency exponent
        list.add(new TLVDataObject(transDataTag.getCurrencyExponentTag(), new byte[]{0x02}));
        //trans date
        //get system date and time,"HH"-24 hours mode，"hh"-12 hours mode
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date curDate = new Date(System.currentTimeMillis());
        dateAndTime = dateFormat.format(curDate);
        list.add(new TLVDataObject(transDataTag.getTransDateTag(), Convert.strToBcd(dateAndTime.substring(2, 10).replace("-", ""))));
        //trans time
        list.add(new TLVDataObject(transDataTag.getTransTimeTag(), Convert.strToBcd(dateAndTime.substring(11).replace(":", ""))));
        //set trans data
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        return FinancialApplication.getEasyLinkSdkManager().setData(DataModel.DataType.TRANSACTION_DATA, list, byteArrayOutputStream);
    }

    private int transFlow(ByteArrayOutputStream cardType) {
        if ((cardType.toByteArray()[cardType.size() - 1] == 1)
                || (cardType.toByteArray()[cardType.size() - 1] == 2)) {
            //MSR card
            return goMSRBranch();
        } else {
            //not MSR card
            return goNotMSRBranch();
        }
    }

    private int goMSRBranch() {
        //get track2
        ByteArrayOutputStream getTrack2Tags = new ByteArrayOutputStream();
        int result = FinancialApplication.getEasyLinkSdkManager().getData(DataModel.DataType.CONFIGURATION_DATA, transDataTag.getTrack2Tag(), getTrack2Tags);
        Log.i(TAG, "get track2: ret = " + result + "  " + Arrays.toString(getTrack2Tags.toByteArray()));
        if (result != ResponseCode.EL_RET_OK) {
            return result;
        }
        transDataTag.setPan(Convert.byte2Str(getTrack2Tags.toByteArray(), 5));
        //must set encryption mode before get pin block
        ByteArrayOutputStream getParamDataTags = new ByteArrayOutputStream();
        result = FinancialApplication.getEasyLinkSdkManager().setData(DataModel.DataType.CONFIGURATION_DATA, transDataTag.getParamDataTag(), getParamDataTags);
        if (result != ResponseCode.EL_RET_OK) {
            return result;
        }
        //get pin block
        ByteArrayOutputStream pinBlock = new ByteArrayOutputStream();
        ByteArrayOutputStream ksn = new ByteArrayOutputStream();
        //return FinancialApplication.getEasyLinkSdkManager().getPinBlock(transDataTag.getPan(), pinBlock, ksn);
        return 0;
    }

    private int goNotMSRBranch() {
        //get trans result
        ByteArrayOutputStream getTransResultTags = new ByteArrayOutputStream();
        int result = FinancialApplication.getEasyLinkSdkManager().getData(DataModel.DataType.TRANSACTION_DATA, transDataTag.getTransResultTag(), getTransResultTags);
        Log.i(TAG, "get trans result: ret = " + result + "  " + Arrays.toString(getTransResultTags.toByteArray()));
        if (result != ResponseCode.EL_RET_OK) {
            return result;
        }

        result = online();
        if (result != ResponseCode.EL_RET_OK) {
            return result;
        }

        result = FinancialApplication.getEasyLinkSdkManager().completeTransaction();
        Log.i(TAG, "complete trans: ret = " + result);

        if (result != ResponseCode.EL_RET_OK) {
            return result;
        }

        //get trans data
        ByteArrayOutputStream getTransDataTags = new ByteArrayOutputStream();
        return FinancialApplication.getEasyLinkSdkManager().getData(DataModel.DataType.TRANSACTION_DATA, transDataTag.getTransDataTagGet(), getTransDataTags);
    }

    private int online() {
        //TODO online
        return ResponseCode.EL_RET_OK;
    }

    //update total money
    private void updateTotalMoney() {
        double totalMoney = 0.00;
        //reduce comparing times
        for (int i = 0; i < cartDataList.getCount(); i++) {
            if (cartDataList.getData(i).getSelect()) {
                double moneyDouble = cartDataList.getData(i).getMoney();
                int count = cartDataList.getData(i).getCount();
                totalMoney = totalMoney + moneyDouble * count;
            }
        }

        //two decimal point
        DecimalFormat decimalFormat = new DecimalFormat("#####0.00");
        money = decimalFormat.format(totalMoney);
        totalMoneyText.setText(money);
    }

    //complete transaction
    private void transSuccess() {
        ReportDataList reportDataList = ReportDataList.getInstance();

        //delete the selected goods, save data to display on the report UI
        for (int i = 0; i < selectDataTitleList.getCount(); i++) {
            for (int j = 0; j < cartDataList.getCount(); j++) {
                if (selectDataTitleList.getSelectTitle(i).equals(cartDataList.getData(j).getTitle())) {
                    cartDataList.getData(j).setTranstime(dateAndTime);
                    reportDataList.addData(cartDataList.getData(j));
                    cartDataList.removeData(j);
                    break;
                }
            }
        }
        selectDataTitleList.removeAll();
        updateTotalMoney();
        totalCheckBox.setChecked(false);
        cartList.setAdapter(adapter);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        FinancialApplication.getApp().unregister(this);
    }
}
