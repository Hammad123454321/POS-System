package com.pax.easylink.test.sale.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lixc
 * the list of the selected goods' title
 */

public class CartSelectDataTitleList {

    public interface OnDataChangedListener {
        void onDataChanged();
    }

    private CartSelectDataTitleList.OnDataChangedListener listener = null;

    public void setListener(CartSelectDataTitleList.OnDataChangedListener listener) {
        this.listener = listener;
    }

    private static CartSelectDataTitleList instance = null;
    private List<String> selectDataTitleList = null;

    private CartSelectDataTitleList() {
        selectDataTitleList = new ArrayList<>();
    }

    public static CartSelectDataTitleList getInstance() {
        if (instance == null) {
            instance = new CartSelectDataTitleList();
        }
        return instance;
    }

    public int getCount() {
        return selectDataTitleList.size();
    }

    public boolean isEmpty() {
        return selectDataTitleList.isEmpty();
    }

    public String getSelectTitle(int index) {
        return selectDataTitleList.get(index);
    }

    public void add(String title) {
        selectDataTitleList.add(title);
        if (listener != null) {
            listener.onDataChanged();
        }
    }

    public void remove(int index) {
        selectDataTitleList.remove(index);
        if (listener != null) {
            listener.onDataChanged();
        }
    }

    public void countChanged() {
        if (listener != null) {
            listener.onDataChanged();
        }
    }

    public void addAll(int size) {
        CartDataList cartDataList = CartDataList.getInstance();
        for (int i = 0; i < size; i++) {
            selectDataTitleList.add(cartDataList.getData(i).getTitle());
        }
    }

    public void removeAll() {
        while (!selectDataTitleList.isEmpty()) {
            selectDataTitleList.remove(0);
        }
    }
}
