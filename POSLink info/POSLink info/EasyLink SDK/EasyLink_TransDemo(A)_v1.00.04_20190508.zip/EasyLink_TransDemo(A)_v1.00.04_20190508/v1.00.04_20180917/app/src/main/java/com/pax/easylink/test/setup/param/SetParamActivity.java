package com.pax.easylink.test.setup.param;
/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2018- ? Pax Corporation. All rights reserved.
 * Description:
 * Revision History:
 * Date                      Author                 Action
 * 20180712                  huangwp                Create
 *
 *
 * ============================================================================
 */

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.easylink.R;
import com.pax.easylink.test.app.FinancialApplication;
import com.pax.easylink.test.utils.SharedPreferencesHelper;
import com.paxsz.easylink.model.DataModel;

import java.io.ByteArrayOutputStream;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SetParamActivity extends AppCompatActivity {
    @Bind(R.id.reportLayout)
    LinearLayout reportLayout;
    @Bind(R.id.supportReport)
    TextView supportReport;
    @Bind(R.id.reportCheckBox)
    CheckBox reportCheckBox;


    private final static String TAG = "SetParamActivity";
    private SharedPreferencesHelper sharedPreferencesHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_param);
        ButterKnife.bind(this);
        sharedPreferencesHelper = new SharedPreferencesHelper(
                SetParamActivity.this, "param");
        boolean b = (Boolean) sharedPreferencesHelper.getSharedPreference("supportReport", new Boolean(false));
        Log.d(TAG, "onCreate b:" + b);
        reportCheckBox.setChecked(b);
    }

    @OnClick({R.id.reportCheckBox})
    protected void onCheckedChanged(CheckBox checkBox) {
        Log.d(TAG, "onCheckedChanged :" + checkBox.isChecked());
        sharedPreferencesHelper.put("supportReport", checkBox.isChecked());
    }

}
