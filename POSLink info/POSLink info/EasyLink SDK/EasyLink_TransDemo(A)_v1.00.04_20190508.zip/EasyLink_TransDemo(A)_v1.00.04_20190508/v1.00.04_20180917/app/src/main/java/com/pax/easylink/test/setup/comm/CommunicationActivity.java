package com.pax.easylink.test.setup.comm;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;

import com.example.easylink.R;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by lixc
 */

public class CommunicationActivity extends AppCompatActivity {

    @Bind(R.id.btLayout)
    RelativeLayout btLayout;
    @Bind(R.id.usbLayout)
    RelativeLayout usbLayout;
    @Bind(R.id.tcpLayout)
    RelativeLayout tcpLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comm);
        ButterKnife.bind(this);

        initView();
    }

    private void initView() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(getResources().getString(R.string.title_comm));
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @OnClick({R.id.btLayout, R.id.usbLayout, R.id.tcpLayout})
    protected void onClick(View v) {
        switch (v.getId()) {
            case R.id.btLayout:
                startNewActivity(BluetoothActivity.class);
                break;
            case R.id.usbLayout:
                startNewActivity(UsbActivity.class);
                break;
            case R.id.tcpLayout:
                startNewActivity(TcpActivity.class);
                break;
            default:
                break;
        }
    }

    private void startNewActivity(Class<?> cls) {
        Intent intent = new Intent(CommunicationActivity.this, cls);
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
