package com.pax.easylink.test.setup.comm;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.easylink.R;
import com.pax.easylink.test.app.FinancialApplication;
import com.pax.easylink.test.event.ResultEvent;
import com.pax.easylink.test.utils.Dialog;
import com.pax.easylink.test.utils.Snackbar;
import com.pax.easylink.test.utils.view.GifImageView;
import com.paxsz.easylink.api.ResponseCode;
import com.paxsz.easylink.device.DeviceInfo;
import com.paxsz.easylink.listener.SearchDeviceListener;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static android.content.ContentValues.TAG;

/**
 * Created by lixc
 * search bt devices, display the list of devices, connect a device
 */
public class BluetoothActivity extends AppCompatActivity {

    @Bind(R.id.pairedDeviceLayout)
    LinearLayout pairedDeviceLayout;
    @Bind(R.id.pairedDeviceTitle)
    TextView pairedDeviceTitle;
    @Bind(R.id.gif)
    GifImageView gif;
    @Bind(R.id.availableDevicesList)
    ListView availableDevicesList;
    @Bind(R.id.bottomScanImage)
    ImageView bottomScanImage;
    @Bind(R.id.bottomScanText)
    TextView bottomScanText;
    @Bind(R.id.bottomScanLayout)
    LinearLayout bottomScanLayout;
    @Bind(R.id.container)
    CoordinatorLayout container;

    private static final String DEVICE_NAME = "DEVICE_NAME";
    private static final String DEVICE_MAC = "DEVICE_MAC";

    private String pairedDeviceName;
    private String pairedDeviceMac;
    //the list of the bt devices
    private ArrayList<HashMap<String, String>> deviceList = new ArrayList<>();
    private AlertDialog alertDialog;
    private boolean isStopBtn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);
        ButterKnife.bind(this);
        FinancialApplication.getApp().register(this);

        initView();
        setListener();
    }

    private void initView() {
        checkPermission();
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(getResources().getString(R.string.title_bluetooth));
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        gif.setMovieResource(R.drawable.gif_searching);
        resetPairedDeviceUI();
        resetBottomUI(R.drawable.btn_search, R.string.search, false);
    }

    private void setListener() {
        availableDevicesList.setOnItemClickListener((parent, arg1, pos, id) -> onItemClick(pos));
    }

    @OnClick(R.id.bottomScanLayout)
    protected void onBottomLayout(View v) {
        if (isStopBtn) {
            resetBottomUI(R.drawable.btn_search, R.string.search, false);
            FinancialApplication.getEasyLinkSdkManager().stopSearchingDevice();
            return;
        }
        deviceList.clear();
        updateBluetoothList();
        resetBottomUI(R.drawable.btn_stop_search, R.string.stop_searching, true);
        FinancialApplication.getEasyLinkSdkManager().searchDevices(new CustomDeviceSearchListener(), 10000);
    }

    @SuppressWarnings("unused")
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(ResultEvent event) {
        switch ((ResultEvent.Status) event.getStatus()) {
            case DISCOVER_ONE:
                addDevice((DeviceInfo) event.getData());
                break;
            case SEARCH_COMPLETE:
                resetBottomUI(R.drawable.btn_search, R.string.search, false);
                break;
            case CONNECT_SUCCESS:
                dialogDismiss();
                resetPairedDeviceUI();
                updateBluetoothList();
                break;
            case CONNECT_FAILED:
                dialogDismiss();
                resetPairedDeviceUI();
                updateBluetoothList();
                Snackbar.showSnackBar(container, ResponseCode.getRespCodeMsg((int) event.getData()));
                break;
            default:
                break;
        }
    }

    private void resetBottomUI(int drawable, int text, boolean isStop) {
        bottomScanImage.setImageDrawable(ContextCompat.getDrawable(this, drawable));
        bottomScanText.setText(text);
        isStopBtn = isStop;
        gif.setVisibility(isStop ? View.VISIBLE : View.INVISIBLE);
    }

    private void resetPairedDeviceUI() {
        if (!FinancialApplication.getEasyLinkSdkManager().isConnected(DeviceInfo.CommType.BLUETOOTH)) {
            pairedDeviceLayout.setVisibility(View.GONE);
            if (pairedDeviceName != null && pairedDeviceMac != null) {
                HashMap<String, String> map = new HashMap<>();
                map.put(DEVICE_NAME, pairedDeviceName);
                map.put(DEVICE_MAC, pairedDeviceMac);
                deviceList.add(map);
                pairedDeviceName = "";
                pairedDeviceMac = "";
            }
            return;
        }
        pairedDeviceName = FinancialApplication.getEasyLinkSdkManager().getConnectedDevice().getDeviceName();
        pairedDeviceMac = FinancialApplication.getEasyLinkSdkManager().getConnectedDevice().getIdentifier();
        pairedDeviceLayout.setVisibility(View.VISIBLE);
        pairedDeviceTitle.setText(pairedDeviceName);

        //remove paired device from available devices list
        for (int i = 0; i < deviceList.size(); i++) {
            if (pairedDeviceName.equals(deviceList.get(i).get(DEVICE_NAME))
                    && pairedDeviceMac.equals(deviceList.get(i).get(DEVICE_MAC))) {
                deviceList.remove(i);
                break;
            }
        }
    }

    private void updateBluetoothList() {
        final BluetoothAdapter adapter = new BluetoothAdapter(this);
        availableDevicesList.setAdapter(adapter);
        availableDevicesList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
    }

    private void onItemClick(int pos) {
        alertDialog = new AlertDialog.Builder(this).create();
        Dialog.showProgressDialog(this, alertDialog, getString(R.string.prompt_connecting),
                getString(R.string.prompt_wait), false);

        String currentName = deviceList.get(pos).get(DEVICE_NAME);
        String currentMac = deviceList.get(pos).get(DEVICE_MAC);
        FinancialApplication.getEasyLinkSdkManager().stopSearchingDevice();
        FinancialApplication.getApp().runInBackground(() -> connectDevice(currentName, currentMac));
    }

    private void connectDevice(String deviceName, String deviceMac) {
        DeviceInfo deviceInfo = new DeviceInfo(DeviceInfo.CommType.BLUETOOTH, deviceName, deviceMac);
        int ret = FinancialApplication.getEasyLinkSdkManager().connect(deviceInfo);
        if (isDestroyed()) {
            return;
        }
        if (ret == ResponseCode.EL_RET_OK) {
            Log.i("log", "connect success");
            FinancialApplication.getApp().doEvent(new ResultEvent(ResultEvent.Status.CONNECT_SUCCESS));
        } else {
            FinancialApplication.getApp().doEvent(new ResultEvent(ResultEvent.Status.CONNECT_FAILED, ret));
        }
    }

    private static class CustomDeviceSearchListener implements SearchDeviceListener {
        public void discoverOneDevice(DeviceInfo deviceInfo) {
            FinancialApplication.getApp().doEvent(new ResultEvent(ResultEvent.Status.DISCOVER_ONE, deviceInfo));
        }

        public void discoverComplete() {
            FinancialApplication.getApp().doEvent(new ResultEvent(ResultEvent.Status.SEARCH_COMPLETE));
            Log.d(">>>", "call discoverComplete");
        }
    }

    private void addDevice(DeviceInfo deviceInfo) {
        //avoid add the same device
        if (deviceInfo.getDeviceName().equals(pairedDeviceName)
                && deviceInfo.getIdentifier().equals(pairedDeviceMac)) {
            return;
        }
        for (int i = 0; i < deviceList.size(); i++) {
            if (deviceInfo.getDeviceName().equals(deviceList.get(i).get(DEVICE_NAME))
                    && deviceInfo.getIdentifier().equals(deviceList.get(i).get(DEVICE_MAC))) {
                return;
            }
        }

        HashMap<String, String> map = new HashMap<>();
        map.put(DEVICE_NAME, deviceInfo.getDeviceName());
        map.put(DEVICE_MAC, deviceInfo.getIdentifier());
        deviceList.add(map);
        updateBluetoothList();
    }

    private class BluetoothAdapter extends BaseAdapter {

        private Context context;

        private BluetoothAdapter(Context context) {
            this.context = context;
        }

        @Override
        public int getCount() {
            return deviceList.size();
        }

        @Override
        public Object getItem(int position) {
            return deviceList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view;
            if (convertView == null) {
                view = LayoutInflater.from(context).inflate(R.layout.device_list_items, parent, false);
            } else {
                view = convertView;
            }
            TextView tv = (TextView) view.findViewById(R.id.title);// display text
            ImageView imageView = (ImageView) view.findViewById(R.id.image);
            tv.setText(deviceList.get(position).get(DEVICE_NAME));
            imageView.setImageResource(R.drawable.icn_bluetooth);
            return view;
        }
    }

    private void dialogDismiss() {
        if (alertDialog != null && alertDialog.isShowing()) {
            alertDialog.dismiss();
            alertDialog = null;
        }
    }

    private void checkPermission() {

        Log.d(TAG, "checkPermission");

        int currentapiVersion = Build.VERSION.SDK_INT;
        Log.d(TAG, "currentapiVersion=" + currentapiVersion);

        if (currentapiVersion >= Build.VERSION_CODES.M) {//API LEVEL 18
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_DENIED) {
                Log.d(TAG, "checkPermission - requestPermissions");
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1001);
            } else {
                Log.d(TAG, "checkPermission - no need requestPermissions");
            }
        } else {
            Log.d(TAG, "checkPermission - SDK Vesion < 23");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1001) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //TODO 请求权限成功
                Log.d(TAG, "requestPermissions success");
            } else {
                //TODO 提示权限已经被禁用
                Log.d(TAG, "requestPermissions fail");
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        FinancialApplication.getApp().unregister(this);
    }
}
