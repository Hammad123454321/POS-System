package com.pax.easylink.test.tab.fragment;

import android.content.Intent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.easylink.R;
import com.pax.easylink.test.setup.comm.CommunicationActivity;
import com.pax.easylink.test.setup.file.FileDownloadActivity;
import com.pax.easylink.test.setup.param.SetParamActivity;
import com.pax.easylink.test.setup.terminfo.TerminalInformationActivity;

import butterknife.Bind;
import butterknife.OnClick;

/**
 * Created by lixc on 2017/6/22.
 */

public class SetupFragment extends BaseFragment {

    @Bind(R.id.title)
    TextView title;
    @Bind(R.id.commLayout)
    RelativeLayout commLayout;
    @Bind(R.id.terminalLayout)
    RelativeLayout terminalLayout;
    @Bind(R.id.fileDownloadLayout)
    RelativeLayout fileDownloadLayout;
    @Bind(R.id.setParamLayout)
    RelativeLayout setParamLayout;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_setup;
    }

    @Override
    protected void initData() {
        //do nothing
    }

    @Override
    protected void initView(View view) {
        title.setText(getString(R.string.title_setup));
    }

    @OnClick({R.id.commLayout, R.id.terminalLayout, R.id.fileDownloadLayout,R.id.setParamLayout})
    protected void onClick(View v) {
        switch (v.getId()) {
            case R.id.commLayout:
                startNewActivity(CommunicationActivity.class);
                break;
            case R.id.terminalLayout:
                startNewActivity(TerminalInformationActivity.class);
                break;
            case R.id.fileDownloadLayout:
                startNewActivity(FileDownloadActivity.class);
                break;
            case R.id.setParamLayout:
                startNewActivity(SetParamActivity.class);
                break;
            default:
                break;
        }
    }

    private void startNewActivity(Class<?> cls) {
        Intent intent = new Intent(getContext(), cls);
        startActivity(intent);
    }
}
