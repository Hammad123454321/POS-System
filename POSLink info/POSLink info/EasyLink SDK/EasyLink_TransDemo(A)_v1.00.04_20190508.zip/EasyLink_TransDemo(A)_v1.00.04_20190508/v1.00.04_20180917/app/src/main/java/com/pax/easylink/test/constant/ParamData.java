package com.pax.easylink.test.constant;

import com.example.easylink.R;

/**
 * Created by lixc
 * commodity parameter data
 */

public final class ParamData {

    private int image;
    private String title;
    private String subTitle;
    private double money;

    public static final String SHOP_NAME = "Exclusive shop";

    private static final ParamData[] PARAM_DATAS = {
            new ParamData(R.drawable.good_image1, "Diamond Ring 0", "new product 0", 1099.00),
            new ParamData(R.drawable.good_image2, "Diamond Ring 1", "new product 1", 1199.00),
            new ParamData(R.drawable.good_image3, "Pendant 2", "new product 2", 1299.00),
            new ParamData(R.drawable.good_image4, "Ear Stud 3", "new product 3", 1399.00),
            new ParamData(R.drawable.good_image5, "Pendant 4", "new product 4", 1499.00),
            new ParamData(R.drawable.good_image5, "Pendant 5", "new product 5", 1499.00),
            new ParamData(R.drawable.good_image4, "Ear Stud 6", "new product 6", 1399.00),
            new ParamData(R.drawable.good_image3, "Pendant 7", "new product 7", 1299.00),
            new ParamData(R.drawable.good_image2, "Diamond Ring 8", "new product 8", 1199.00),
            new ParamData(R.drawable.good_image1, "Diamond Ring 9", "new product 9", 1099.00)
    };

    private ParamData(int image, String title, String subTitle, double money) {
        this.image = image;
        this.title = title;
        this.subTitle = subTitle;
        this.money = money;
    }

    public int getImage() {
        return image;
    }

    public String getTitle() {
        return title;
    }

    public String getSubTitle() {
        return subTitle;
    }

    public double getMoney() {
        return money;
    }

    public static ParamData[] getParamDatas() {
        return PARAM_DATAS;
    }
}
