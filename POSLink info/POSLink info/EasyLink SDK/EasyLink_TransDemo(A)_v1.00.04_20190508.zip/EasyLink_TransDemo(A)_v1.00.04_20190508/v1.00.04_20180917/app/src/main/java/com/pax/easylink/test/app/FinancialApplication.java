package com.pax.easylink.test.app;

import android.app.Application;
import android.os.Handler;

import com.pax.easylink.test.event.ResultEvent;
import com.paxsz.easylink.api.EasyLinkSdkManager;

import org.greenrobot.eventbus.EventBus;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by lixc on 2017/6/28.
 */

public class FinancialApplication extends Application {

    private static FinancialApplication financialApplication;
    private static EasyLinkSdkManager easyLinkSdkManager;

    private Handler handler;

    private ExecutorService backgroundExecutor;

    @Override
    public void onCreate() {
        super.onCreate();
        init();
        handler = new Handler();
        backgroundExecutor = Executors.newFixedThreadPool(10, runnable -> {
            Thread thread = new Thread(runnable, "Background executor service");
            thread.setPriority(Thread.MIN_PRIORITY);
            thread.setDaemon(true);
            return thread;
        });
    }

    private void init() {
        FinancialApplication.financialApplication = this;
        easyLinkSdkManager = EasyLinkSdkManager.getInstance(financialApplication);
    }

    public static FinancialApplication getApp() {
        return financialApplication;
    }

    public static EasyLinkSdkManager getEasyLinkSdkManager() {
        return easyLinkSdkManager;
    }

    public void register(Object obj) {
        if (!EventBus.getDefault().isRegistered(obj)) {
            EventBus.getDefault().register(obj);
        }
    }

    public void unregister(Object obj) {
        if (EventBus.getDefault().isRegistered(obj)) {
            EventBus.getDefault().unregister(obj);
        }
    }

    public void doEvent(ResultEvent event) {
        EventBus.getDefault().post(event);
    }

    public void runInBackground(final Runnable runnable) {
        backgroundExecutor.submit(runnable);
    }

    public void runOnUiThread(final Runnable runnable) {
        handler.post(runnable);
    }
}
