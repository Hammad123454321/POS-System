package com.pax.easylink.test.sale;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.easylink.R;
import com.pax.easylink.test.app.FinancialApplication;
import com.pax.easylink.test.event.ResultEvent;
import com.pax.easylink.test.utils.Dialog;
import com.paxsz.easylink.api.ResponseCode;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by lixc
 * choose card UI
 */

public class ChooseCardActivity extends Activity {

    @Bind(R.id.imagePrompt)
    ImageView imagePrompt;
    @Bind(R.id.titlePrompt)
    TextView titlePrompt;

    public static ChooseCardActivity instance = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prompt);
        ButterKnife.bind(this);
        instance = this;
        FinancialApplication.getApp().register(this);
        imagePrompt.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.img_2));
        titlePrompt.setText(getString(R.string.choosecard));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        FinancialApplication.getApp().unregister(this);
    }

    @SuppressWarnings("unused")
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onReportEvent(ResultEvent event) {
        switch ((ResultEvent.Status) event.getStatus()) {
            case RECV_REPORT:
                Log.d("huangwp","onReportEvent (String) event.getData()" + (String) event.getData());
                titlePrompt.setText((String) event.getData());
                break;
            default:
                break;
        }
    }
}
