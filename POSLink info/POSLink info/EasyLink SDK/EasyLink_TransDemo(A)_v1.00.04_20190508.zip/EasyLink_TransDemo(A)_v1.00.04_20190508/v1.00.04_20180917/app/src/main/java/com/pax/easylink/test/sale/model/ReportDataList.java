package com.pax.easylink.test.sale.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lixc
 * 已完成交易的商品列表
 */

public class ReportDataList {

    private static ReportDataList instance = null;
    private List<CommodityParam> dataList = null;

    private ReportDataList() {
        dataList = new ArrayList<>();
    }

    public static ReportDataList getInstance() {
        if (instance == null) {
            instance = new ReportDataList();
        }
        return instance;
    }

    public CommodityParam getData(int index) {
        return dataList.get(index);
    }

    public int getCount() {
        return dataList.size();
    }

    public void addData(CommodityParam commodityParam) {
        dataList.add(commodityParam);
    }
}
