package com.pax.easylink.test.setup.terminfo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.easylink.R;
import com.pax.easylink.test.app.FinancialApplication;
import com.pax.easylink.test.utils.Convert;
import com.paxsz.easylink.api.ResponseCode;
import com.paxsz.easylink.model.DataModel;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by lixc
 * display the terminal information
 */
public class TerminalInformationActivity extends AppCompatActivity {

    @Bind(R.id.list1)
    ListView list1;

    private static final String TITLE_LEFT = "TITLE_LEFT";
    private static final String TITLE_RIGHT = "TITLE_RIGHT";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.terminal_information_list);
        ButterKnife.bind(this);

        initView();

        getTermInfo();

        List<Map<String, Object>> listItems = new ArrayList<>();
        for (int i = 0; i < TerminalInformation.getInformation().length; i++) {
            Map<String, Object> mapItem = new HashMap<>();
            mapItem.put(TITLE_LEFT, TerminalInformation.getInformation()[i][0]);
            mapItem.put(TITLE_RIGHT, TerminalInformation.getInformation()[i][1]);
            listItems.add(mapItem);
        }
        SimpleAdapter simpleAdapter = new SimpleAdapter(this, listItems, R.layout.activity_terminal_info,
                new String[]{TITLE_LEFT, TITLE_RIGHT}, new int[]{R.id.terminalInfoLeft, R.id.terminalInfoRight});
        list1.setAdapter(simpleAdapter);
    }

    private void initView() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(getResources().getString(R.string.title_terminal_infor));
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    private void getTermInfo() {
        for (int i = 0; i < TerminalInformation.getTerminalTag().length; i++) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            int ret = FinancialApplication.getEasyLinkSdkManager().getData(DataModel.DataType.CONFIGURATION_DATA, TerminalInformation.getTerminalTag()[i], byteArrayOutputStream);
            if (ret != ResponseCode.EL_RET_OK) {
                return;
            }

            String termType = "Unknown terminal";
            if (byteArrayOutputStream != null && byteArrayOutputStream.toByteArray().length > 4) {

                if (byteArrayOutputStream.toByteArray()[4] != 0) {
                    if (byteArrayOutputStream.toByteArray()[4] == 0x01 && byteArrayOutputStream.toByteArray()[5] == 0x23) {
                        termType =  "D180";
                    } else {
                        termType = Convert.byte2Str(byteArrayOutputStream.toByteArray(), 5);
                    }
                }
            }
            TerminalInformation.setInformation(i, termType);

        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
